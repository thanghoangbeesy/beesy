# Beesy Class – Web lớp tiền tiểu học 🌈

Web cho lớp tiền tiểu học: bé ôn bài ở nhà, làm bài tập và chơi game.
- **Trang chủ**: banner, danh sách lớp học, lối vào Trò chơi / Tài liệu
- **Trang lớp**: bài học (tìm kiếm + lọc theo Tập đọc / Tập viết / Phát âm / Đọc từ / Bài tập), danh sách học sinh
- **Trò chơi** (chơi trực tiếp trên web, có giọng đọc tiếng Việt):
  - 🔊 Nghe và chọn – luyện phát âm
  - 🃏 Thẻ từ vựng – đọc từ
  - 🔤 Đố chữ cái đầu – đánh vần
  - ✏️ Tập viết chữ – tô theo chữ mẫu bằng ngón tay
- **Tài liệu**: phiếu bài tập, video, link Drive…
- **Trang /quan-tri**: quản lý toàn bộ nội dung trên điện thoại

Dữ liệu lưu trên **Firebase Firestore** (gói miễn phí). Code trên **GitHub**.

---

## Cách 1 – 100% trên điện thoại (khuyên dùng)

### Bước 1: Tạo project Firebase
1. Vào [console.firebase.google.com](https://console.firebase.google.com) → **Add project** → đặt tên (VD: `beesy-class`) → tắt Google Analytics cho nhanh → **Create project**.
2. Trong project → **Build → Firestore Database** → **Create database** → chọn **Start in production mode** → chọn region `asia-southeast1` → Enable.
3. **Build → Authentication** → **Sign-in method** → bật **Email/Password**.
4. Vào **Project settings** (bánh răng) → **Your apps** → **Add app → Web** (biểu tượng `</>`) → đặt nickname → **Register app** → copy 6 giá trị config (apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId).

### Bước 2: Tạo repo GitHub
1. Tạo repo mới trên GitHub (VD: `beesy-class`), để **Public** hoặc Private đều được.
2. Upload 2 file: **app.zip** (giải nén ra source, hoặc upload nguyên file zip) và **.github/workflows/deploy.yml** vào repo.
   - Cách nhanh trên điện thoại: dùng app GitHub → Add file → Upload files → chọn app.zip và deploy.yml.
3. Vào repo → **Settings → Secrets and variables → Actions → New repository secret**, thêm từng secret:
   - `VITE_FIREBASE_API_KEY`, `VITE_FIREBASE_AUTH_DOMAIN`, `VITE_FIREBASE_PROJECT_ID`, `VITE_FIREBASE_STORAGE_BUCKET`, `VITE_FIREBASE_MESSAGING_SENDER_ID`, `VITE_FIREBASE_APP_ID` (6 giá trị copy ở Bước 1)
   - `VITE_SETUP_KEY`: chuỗi bí mật tự đặt (VD: `lop-be-2026`) – dùng để tạo tài khoản quản trị lần đầu
   - `FIREBASE_SERVICE_ACCOUNT`: JSON key của service account (Firebase Console → Project settings → Service accounts → Generate new private key)
   - `FIREBASE_PROJECT_ID`: project ID (giống VITE_FIREBASE_PROJECT_ID)

### Bước 3: Deploy
1. Mỗi lần upload app.zip mới lên nhánh `main`, GitHub Actions tự build và deploy lên Firebase Hosting.
2. Web chạy ở địa chỉ: `https://<project-id>.web.app`

### Bước 4: Cấu hình Firestore Rules
1. Firebase Console → **Firestore Database → Rules** → xóa hết, dán nội dung file **firestore.rules** trong source → **Publish**.
   (Cho phép mọi người đọc, chỉ tài khoản đăng nhập mới được ghi.)

### Bước 5: Tạo tài khoản quản trị + nạp dữ liệu mẫu
1. Mở `https://<project-id>.web.app/quan-tri`
2. Bấm **"Chưa có tài khoản? Tạo mới"** → nhập email, mật khẩu, khóa cài đặt (VITE_SETUP_KEY) → **Tạo tài khoản** → đăng nhập.
3. Trong trang quản trị, bấm **"Nạp dữ liệu mẫu"** → web có ngay 4 lớp, học sinh, bài học, từ vựng mẫu.
4. Sửa tên lớp, thêm bài học, từ vựng, tài liệu tùy ý – tất cả lưu lên Firestore, web tự cập nhật.

---

## Cách 2 – Chạy trên máy tính

```bash
npm install
cp .env.example .env   # điền các khóa Firebase vào .env
npm run dev             # chạy thử ở localhost
npm run build           # build ra thư mục dist/
```

Deploy thủ công: `npx firebase-tools deploy --only hosting` (cần đăng nhập firebase login trước).

---

## Ghi chú
- Game phát âm dùng giọng đọc tiếng Việt có sẵn trên điện thoại/máy tính (Web Speech API). Trên iPhone cần mở bằng Safari để nghe được giọng Việt.
- Gói Firebase Spark miễn phí đủ dùng cho 1 lớp học (50k lượt đọc/ngày).
