import { useEffect, useState } from 'react'
// icons: emoji 3D
import { GameBack, shuffle, speak, stopSpeak, useWords, warmUpVoice } from './shared'
import { recordGameScore } from '../lib/progress'
import { WordDoc } from '../types'

interface Card {
  uid: number
  wordId: string
  kind: 'emoji' | 'word'
  text: string
  emoji: string
}

const PAIR_COUNT = 6

export default function Memory() {
  const words = useWords()
  const [cards, setCards] = useState<Card[]>([])
  const [flipped, setFlipped] = useState<number[]>([])
  const [matched, setMatched] = useState<string[]>([])
  const [moves, setMoves] = useState(0)
  const [lock, setLock] = useState(false)
  const [won, setWon] = useState(false)

  const deal = (list: WordDoc[]) => {
    stopSpeak()
    const picked = shuffle(list).slice(0, PAIR_COUNT)
    const deck: Card[] = []
    picked.forEach((w, i) => {
      deck.push({ uid: i * 2, wordId: w.id, kind: 'emoji', text: w.text, emoji: w.emoji })
      deck.push({ uid: i * 2 + 1, wordId: w.id, kind: 'word', text: w.text, emoji: w.emoji })
    })
    setCards(shuffle(deck))
    setFlipped([])
    setMatched([])
    setMoves(0)
    setLock(false)
    setWon(false)
  }

  useEffect(() => {
    warmUpVoice()
    if (words.length >= PAIR_COUNT) deal(words)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [words.length])

  // Thắng 1 ván → ghi nhận (6/6 cặp)
  useEffect(() => {
    if (won) recordGameScore('tri-nho', '🧠 Trí nhớ siêu phàm', PAIR_COUNT, PAIR_COUNT)
  }, [won])

  const flip = (c: Card) => {
    if (lock || won) return
    if (flipped.includes(c.uid) || matched.includes(c.wordId)) return
    if (c.kind === 'word') speak(c.text, true)
    const next = [...flipped, c.uid]
    setFlipped(next)
    if (next.length === 2) {
      setMoves((m) => m + 1)
      const [a, b] = next.map((uid) => cards.find((k) => k.uid === uid)!)
      if (a.wordId === b.wordId) {
        const newMatched = [...matched, a.wordId]
        setMatched(newMatched)
        setFlipped([])
        if (newMatched.length === PAIR_COUNT) {
          setWon(true)
          speak('Tuyệt vời! Bé nhớ giỏi quá!', true)
        } else {
          speak('Đúng rồi!', true)
        }
      } else {
        setLock(true)
        setTimeout(() => {
          setFlipped([])
          setLock(false)
        }, 900)
      }
    }
  }

  const faceUp = (c: Card) => flipped.includes(c.uid) || matched.includes(c.wordId)

  return (
    <div className="wrap">
      <div className="game-stage" style={{ maxWidth: 660 }}>
        <GameBack title="🧠 Trí nhớ siêu phàm" />
        <p style={{ color: '#62708a' }}>Lật 2 thẻ: tìm cặp hình và từ giống nhau nhé!</p>
        <div className="score-bar">
          <div className="score-pill">🎯 {matched.length}/{PAIR_COUNT} cặp</div>
          <div className="score-pill">👆 {moves} lượt lật</div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 18 }}>
          {cards.map((c) => {
            const up = faceUp(c)
            const isMatched = matched.includes(c.wordId)
            return (
              <button
                key={c.uid}
                onClick={() => flip(c)}
                className="pick-card"
                style={{
                  minHeight: 104,
                  borderColor: isMatched ? '#22c55e' : undefined,
                  background: isMatched ? '#f0fdf4' : up ? '#fff' : '#e5f6ff',
                }}
              >
                {up ? (
                  c.kind === 'emoji' ? (
                    <span className="big" style={{ fontSize: 44 }}>{c.emoji}</span>
                  ) : (
                    <span style={{ fontSize: 20 }}>{c.text}</span>
                  )
                ) : (
                  <span style={{ fontSize: 34 }}>❓</span>
                )}
              </button>
            )
          })}
        </div>
        {won && <div className="game-msg">🎉 Bé tìm hết các cặp rồi, giỏi quá!</div>}
        <button className="btn-soft" onClick={() => deal(words)}>
          <span class="e3d">🔄</span> Chơi ván mới
        </button>
      </div>
    </div>
  )
}
