import { useEffect, useRef, useState } from 'react'
// icons: emoji 3D
import { GameBack } from './shared'
import { recordGameScore } from '../lib/progress'

const LETTERS = 'aăâbcdđeêghiklmnoôơpqrstuưvxy'.split('')

export default function TraceLetter() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const drawing = useRef(false)
  const [letter, setLetter] = useState('a')
  // Đếm số chữ bé đã luyện (ghi nhận khi rời game)
  const practiced = useRef(1)
  useEffect(() => () => {
    recordGameScore('tap-viet', '✏️ Tập viết chữ', practiced.current, practiced.current)
  }, [])

  const drawGuide = () => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const w = (canvas.width = canvas.offsetWidth * 2)
    const h = (canvas.height = 340 * 2)
    ctx.clearRect(0, 0, w, h)
    ctx.font = `700 ${h * 0.62}px "Baloo 2", "Arial Rounded MT Bold", Arial, sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    // chữ mẫu nét đứt màu nhạt
    ctx.strokeStyle = '#e8b4c8'
    ctx.lineWidth = 5
    ctx.setLineDash([16, 12])
    ctx.strokeText(letter, w / 2, h / 2 + h * 0.03)
    ctx.setLineDash([])
  }

  useEffect(() => {
    drawGuide()
    // Vẽ lại khi font web tải xong để chữ mẫu dùng đúng font Baloo 2
    if (document.fonts?.ready) {
      document.fonts.ready.then(() => drawGuide()).catch(() => {})
    }
    const onResize = () => drawGuide()
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [letter])

  const pos = (e: React.PointerEvent) => {
    const canvas = canvasRef.current!
    const r = canvas.getBoundingClientRect()
    return { x: ((e.clientX - r.left) / r.width) * canvas.width, y: ((e.clientY - r.top) / r.height) * canvas.height }
  }

  const start = (e: React.PointerEvent) => {
    drawing.current = true
    const canvas = canvasRef.current!
    canvas.setPointerCapture(e.pointerId)
    const ctx = canvas.getContext('2d')!
    const p = pos(e)
    ctx.beginPath()
    ctx.moveTo(p.x, p.y)
  }

  const move = (e: React.PointerEvent) => {
    if (!drawing.current) return
    const canvas = canvasRef.current!
    const ctx = canvas.getContext('2d')!
    const p = pos(e)
    ctx.lineWidth = 14
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    ctx.strokeStyle = '#152b58'
    ctx.lineTo(p.x, p.y)
    ctx.stroke()
    ctx.beginPath()
    ctx.moveTo(p.x, p.y)
  }

  const stop = () => { drawing.current = false }

  return (
    <div className="wrap">
      <div className="game-stage">
        <GameBack title="✏️ Tập viết chữ" />
        <p style={{ color: '#62708a' }}>Dùng ngón tay (hoặc chuột) tô theo chữ mẫu nhé. Viết chậm, viết đẹp nào!</p>
        <div className="trace-letter-big">Chữ cần viết: <span style={{ color: '#c44e7c', fontSize: 30 }}>{letter}</span></div>
        <div className="trace-wrap">
          <canvas
            ref={canvasRef}
            className="trace"
            onPointerDown={start}
            onPointerMove={move}
            onPointerUp={stop}
            onPointerLeave={stop}
          />
        </div>
        <div className="row-center">
          <button className="btn-soft" onClick={drawGuide}><span class="e3d">🧽</span> Xóa viết lại</button>
          <button className="btn-soft" onClick={() => { practiced.current += 1; setLetter(LETTERS[Math.floor(Math.random() * LETTERS.length)]) }}>
            <span class="e3d">🔀</span> Chữ khác
          </button>
        </div>
      </div>
    </div>
  )
}
