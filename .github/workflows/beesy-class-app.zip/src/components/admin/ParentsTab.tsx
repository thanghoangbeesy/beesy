import { useEffect, useState } from 'react'
import {
  collection, deleteDoc, doc, getDocs, orderBy, query,
} from 'firebase/firestore'
import { db } from '../../firebase'
import { ClassDoc, ParentDoc, StudentDoc } from '../../types'
import { createParentAccount, deleteParentDoc, updateParentStudents } from '../../lib/parentAuth'

export default function ParentsTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [parents, setParents] = useState<ParentDoc[]>([])
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [students, setStudents] = useState<StudentDoc[]>([])
  const [f, setF] = useState({ email: '', pass: '', name: '', phone: '' })
  const [picked, setPicked] = useState<string[]>([])
  const [busy, setBusy] = useState(false)
  const [editing, setEditing] = useState<ParentDoc | null>(null)
  const [editPicked, setEditPicked] = useState<string[]>([])

  const load = () => {
    getDocs(collection(db, 'parents'))
      .then((s) =>
        setParents(
          s.docs
            .map((d) => d.data() as ParentDoc)
            .sort((a, b) => b.createdAt - a.createdAt),
        ),
      )
      .catch(() => {})
  }

  useEffect(() => {
    load()
    getDocs(query(collection(db, 'classes'), orderBy('order'))).then((s) =>
      setClasses(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) }))),
    )
    getDocs(collection(db, 'students')).then((s) =>
      setStudents(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudentDoc, 'id'>) }))),
    )
  }, [])

  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '(đã xóa)'

  const toggle = (list: string[], set: (v: string[]) => void, id: string) =>
    set(list.includes(id) ? list.filter((x) => x !== id) : [...list, id])

  const create = async () => {
    if (!f.email.trim() || !f.pass || !f.name.trim()) {
      onMsg('Anh nhập đủ email, mật khẩu và tên phụ huynh nhé.')
      return
    }
    if (picked.length === 0) {
      onMsg('Anh chọn ít nhất 1 bé cho tài khoản này nhé.')
      return
    }
    setBusy(true)
    try {
      await createParentAccount(f.email, f.pass, f.name, f.phone, picked)
      setF({ email: '', pass: '', name: '', phone: '' })
      setPicked([])
      load()
      onMsg('Đã tạo tài khoản phụ huynh! ✅')
    } catch (e: any) {
      const code = e?.code || ''
      if (code === 'auth/email-already-in-use') onMsg('Email này đã có tài khoản rồi.')
      else if (code === 'auth/weak-password') onMsg('Mật khẩu phải từ 6 ký tự trở lên.')
      else if (code === 'auth/invalid-email') onMsg('Email chưa đúng định dạng.')
      else onMsg('Lỗi: ' + code)
    }
    setBusy(false)
  }

  const saveEdit = async () => {
    if (!editing) return
    setBusy(true)
    try {
      await updateParentStudents(editing.uid, editPicked)
      setEditing(null)
      load()
      onMsg('Đã cập nhật danh sách bé! ✅')
    } catch {
      onMsg('Có lỗi, anh thử lại nhé.')
    }
    setBusy(false)
  }

  const remove = async (p: ParentDoc) => {
    if (!confirm(`Xóa tài khoản phụ huynh "${p.name}"?`)) return
    await deleteParentDoc(p.uid)
    load()
    onMsg('Đã xóa. Lưu ý: tài khoản đăng nhập (Auth) vẫn tồn tại, chỉ xóa liên kết bé.')
  }

  return (
    <>
      <div className="admin-box">
        <h2>👨‍👩‍👧 Tài khoản phụ huynh ({parents.length})</h2>
        {parents.length === 0 && <div className="empty">Chưa có tài khoản phụ huynh nào.</div>}
        {parents.map((p) => (
          <div className="admin-row" key={p.uid}>
            <div>
              <b>{p.name}</b> <span style={{ color: '#5d7590', fontSize: 13 }}>{p.email}{p.phone ? ` · ${p.phone}` : ''}</span>
              <div style={{ fontSize: 13, color: '#5d7590', marginTop: 4 }}>
                🧒 {p.studentIds.length} bé: {p.studentIds.map(studentName).join(', ') || '—'}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
              <button
                className="btn-small"
                onClick={() => { setEditing(p); setEditPicked(p.studentIds) }}
              >
                Sửa bé liên kết
              </button>
              <button className="btn-danger" onClick={() => remove(p)}>Xóa</button>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <div className="admin-box">
          <h2>🔗 Bé liên kết với {editing.name}</h2>
          {classes.map((c) => {
            const list = students.filter((s) => s.classId === c.id)
            if (list.length === 0) return null
            return (
              <div key={c.id} style={{ marginBottom: 10 }}>
                <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 6 }}>{c.name}</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {list.map((s) => (
                    <label key={s.id} className={`chip${editPicked.includes(s.id) ? ' on' : ''}`} style={{ cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={editPicked.includes(s.id)}
                        onChange={() => toggle(editPicked, setEditPicked, s.id)}
                        style={{ marginRight: 6 }}
                      />
                      {s.name}
                    </label>
                  ))}
                </div>
              </div>
            )
          })}
          <div className="row-center" style={{ justifyContent: 'flex-start' }}>
            <button className="btn-primary" disabled={busy} onClick={saveEdit}>Lưu</button>
            <button className="btn-soft" onClick={() => setEditing(null)}>Hủy</button>
          </div>
        </div>
      )}

      <div className="admin-box">
        <h2>➕ Tạo tài khoản phụ huynh</h2>
        <div className="field"><label>Email đăng nhập *</label><input value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} placeholder="phuhuynh@vidu.com" inputMode="email" /></div>
        <div className="field"><label>Mật khẩu * (từ 6 ký tự)</label><input type="password" value={f.pass} onChange={(e) => setF({ ...f, pass: e.target.value })} /></div>
        <div className="field"><label>Tên phụ huynh *</label><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="VD: Mẹ Minh Anh" /></div>
        <div className="field"><label>SĐT</label><input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} placeholder="VD: 0901 234 567" inputMode="tel" /></div>
        <div className="field">
          <label>Các bé của phụ huynh này *</label>
          {classes.map((c) => {
            const list = students.filter((s) => s.classId === c.id)
            if (list.length === 0) return null
            return (
              <div key={c.id} style={{ marginBottom: 10 }}>
                <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 6 }}>{c.name}</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {list.map((s) => (
                    <label key={s.id} className={`chip${picked.includes(s.id) ? ' on' : ''}`} style={{ cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={picked.includes(s.id)}
                        onChange={() => toggle(picked, setPicked, s.id)}
                        style={{ marginRight: 6 }}
                      />
                      {s.name}
                    </label>
                  ))}
                </div>
              </div>
            )
          })}
        </div>
        <button className="btn-primary" disabled={busy} onClick={create}>
          {busy ? 'Đang tạo…' : 'Tạo tài khoản'}
        </button>
      </div>
    </>
  )
}
