import { useEffect, useMemo, useState } from 'react'
import {
  addDoc, collection, deleteDoc, doc, getDocs, orderBy, query, updateDoc, where, writeBatch,
} from 'firebase/firestore'
import { db } from '../../firebase'
import { ClassDoc, StudentDoc, TuitionRecord } from '../../types'

function defaultPeriod() {
  const d = new Date()
  return `${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`
}

const fmtVND = (n: number) => n.toLocaleString('vi-VN') + 'đ'

function statusOf(r: TuitionRecord): { label: string; color: string } {
  if (r.amount > 0 && r.paid >= r.amount) return { label: 'Đã đóng ✅', color: '#15803d' }
  if (r.paid > 0) return { label: 'Đóng một phần 🟡', color: '#b45309' }
  return { label: 'Chưa đóng 🔴', color: '#b91c1c' }
}

export default function TuitionTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [classId, setClassId] = useState('')
  const [period, setPeriod] = useState(defaultPeriod())
  const [students, setStudents] = useState<StudentDoc[]>([])
  const [records, setRecords] = useState<TuitionRecord[]>([])
  const [busy, setBusy] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editAmount, setEditAmount] = useState('')
  const [editNote, setEditNote] = useState('')

  useEffect(() => {
    getDocs(query(collection(db, 'classes'), orderBy('order'))).then((s) => {
      const cs = s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) }))
      setClasses(cs)
      if (cs[0]) setClassId((cur) => cur || cs[0].id)
    })
  }, [])

  const load = async (cid: string, per: string) => {
    if (!cid || !per.trim()) return
    const stSnap = await getDocs(query(collection(db, 'students'), where('classId', '==', cid)))
    const sts = stSnap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudentDoc, 'id'>) }))
    setStudents(sts)
    const recSnap = await getDocs(
      query(collection(db, 'tuition_records'), where('period', '==', per.trim())),
    )
    const ids = new Set(sts.map((s) => s.id))
    const recs = recSnap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<TuitionRecord, 'id'>) }))
      .filter((r) => ids.has(r.studentId))
      .sort((a, b) => a.createdAt - b.createdAt)
    setRecords(recs)
  }

  useEffect(() => { load(classId, period) }, [classId, period])

  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '(đã xóa)'

  /** Tạo đợt thu cho cả lớp: bé nào chưa có record kỳ này thì tạo mới (số tiền mặc định 0). */
  const createBatch = async () => {
    if (students.length === 0) {
      onMsg('Lớp này chưa có học sinh.')
      return
    }
    if (!confirm(`Tạo đợt thu kỳ ${period} cho ${students.length} bé?`)) return
    setBusy(true)
    try {
      const existing = new Set(records.map((r) => r.studentId))
      const batch = writeBatch(db)
      let n = 0
      for (const s of students) {
        if (existing.has(s.id)) continue
        const ref = doc(collection(db, 'tuition_records'))
        batch.set(ref, {
          studentId: s.id,
          period: period.trim(),
          amount: 0,
          paid: 0,
          createdAt: Date.now(),
        })
        n++
      }
      await batch.commit()
      await load(classId, period)
      onMsg(n > 0 ? `Đã tạo ${n} phiếu thu. Anh bấm "Sửa" để nhập số tiền từng bé nhé.` : 'Cả lớp đã có phiếu thu kỳ này rồi.')
    } catch {
      onMsg('Có lỗi, anh thử lại nhé.')
    }
    setBusy(false)
  }

  const collect = async (r: TuitionRecord) => {
    const v = prompt(`Thu tiền học phí kỳ ${r.period} — bé ${studentName(r.studentId)}\nCòn lại: ${fmtVND(Math.max(0, r.amount - r.paid))}`, '')
    if (v === null) return
    const n = Number(v.replace(/[^\d]/g, ''))
    if (!n || n <= 0) {
      onMsg('Số tiền chưa hợp lệ.')
      return
    }
    await updateDoc(doc(db, 'tuition_records', r.id), {
      paid: r.paid + n,
      paidAt: Date.now(),
    })
    await load(classId, period)
    onMsg(`Đã thu ${fmtVND(n)} ✅`)
  }

  const startEdit = (r: TuitionRecord) => {
    setEditingId(r.id)
    setEditAmount(String(r.amount))
    setEditNote(r.note || '')
  }

  const saveEdit = async (r: TuitionRecord) => {
    const amount = Number(String(editAmount).replace(/[^\d]/g, '')) || 0
    await updateDoc(doc(db, 'tuition_records', r.id), { amount, note: editNote.trim() })
    setEditingId(null)
    await load(classId, period)
    onMsg('Đã lưu! ✅')
  }

  const remove = async (r: TuitionRecord) => {
    if (!confirm(`Xóa phiếu thu kỳ ${r.period} của bé ${studentName(r.studentId)}?`)) return
    await deleteDoc(doc(db, 'tuition_records', r.id))
    await load(classId, period)
    onMsg('Đã xóa.')
  }

  const stats = useMemo(() => {
    const total = records.reduce((s, r) => s + r.amount, 0)
    const paid = records.reduce((s, r) => s + r.paid, 0)
    return { total, paid, remain: Math.max(0, total - paid) }
  }, [records])

  return (
    <>
      <div className="admin-box">
        <h2>💰 Quản lý học phí</h2>
        <div className="form-inline" style={{ marginTop: 0 }}>
          <div className="field" style={{ flex: 1, minWidth: 140, marginBottom: 0 }}>
            <label>Kỳ thu (MM/YYYY)</label>
            <input value={period} onChange={(e) => setPeriod(e.target.value)} placeholder="10/2026" />
          </div>
          <div className="field" style={{ flex: 2, minWidth: 180, marginBottom: 0 }}>
            <label>Lớp</label>
            <select value={classId} onChange={(e) => setClassId(e.target.value)}>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        </div>
        <div style={{ marginTop: 14 }}>
          <button className="btn-primary" disabled={busy} onClick={createBatch}>
            {busy ? 'Đang tạo…' : '🧾 Tạo đợt thu cho cả lớp'}
          </button>
        </div>
      </div>

      <div className="admin-box">
        <h2>📋 Phiếu thu — kỳ {period} ({records.length})</h2>
        <div className="admin-row" style={{ fontWeight: 800 }}>
          <div>Tổng phải thu: <b style={{ color: '#1d3a5f' }}>{fmtVND(stats.total)}</b></div>
          <div>Đã thu: <b style={{ color: '#15803d' }}>{fmtVND(stats.paid)}</b></div>
          <div>Còn lại: <b style={{ color: '#b91c1c' }}>{fmtVND(stats.remain)}</b></div>
        </div>
        {records.length === 0 && (
          <div className="empty">Chưa có phiếu thu nào. Anh bấm "Tạo đợt thu cho cả lớp" nhé.</div>
        )}
        {records.map((r) => {
          const st = statusOf(r)
          const remain = Math.max(0, r.amount - r.paid)
          return (
            <div className="admin-row" key={r.id}>
              <div style={{ flex: 1 }}>
                <b>{studentName(r.studentId)}</b>{' '}
                <span style={{ fontWeight: 800, color: st.color, fontSize: 13 }}>{st.label}</span>
                <div style={{ fontSize: 13, color: '#5d7590', marginTop: 4 }}>
                  Phải đóng: <b>{fmtVND(r.amount)}</b> · Đã đóng: <b>{fmtVND(r.paid)}</b> · Còn lại: <b>{fmtVND(remain)}</b>
                  {r.note && <span> · 📝 {r.note}</span>}
                </div>
                {editingId === r.id && (
                  <div className="form-inline">
                    <input
                      value={editAmount}
                      onChange={(e) => setEditAmount(e.target.value)}
                      placeholder="Số tiền phải đóng"
                      inputMode="numeric"
                      style={{ maxWidth: 160 }}
                    />
                    <input
                      value={editNote}
                      onChange={(e) => setEditNote(e.target.value)}
                      placeholder="Ghi chú"
                      style={{ maxWidth: 220 }}
                    />
                    <button className="btn-small" onClick={() => saveEdit(r)}>Lưu</button>
                    <button className="btn-small" onClick={() => setEditingId(null)}>Hủy</button>
                  </div>
                )}
              </div>
              {editingId !== r.id && (
                <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                  <button className="btn-small" onClick={() => collect(r)}>💵 Thu tiền</button>
                  <button className="btn-small" onClick={() => startEdit(r)}>Sửa</button>
                  <button className="btn-danger" onClick={() => remove(r)}>Xóa</button>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </>
  )
}
