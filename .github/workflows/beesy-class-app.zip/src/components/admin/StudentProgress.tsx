import { useMemo } from 'react'
import { formatProgressTime, useStudentProgress } from '../../lib/progress'

/** Khối thống kê tiến trình học tập của 1 bé — nhúng trong tab Học sinh của trang quản trị. */
export default function StudentProgress({ studentId, studentName }: { studentId: string; studentName: string }) {
  const { items, loading } = useStudentProgress(studentId)

  const stats = useMemo(() => {
    const games = items.filter((i) => i.type === 'game')
    const lessons = items.filter((i) => i.type === 'lesson')
    const best = new Map<string, { label: string; score: number; total?: number }>()
    for (const g of games) {
      const s = g.score ?? 0
      const cur = best.get(g.refId)
      if (!cur || s > cur.score) best.set(g.refId, { label: g.label, score: s, total: g.total })
    }
    return {
      total: items.length,
      gameCount: games.length,
      lessonCount: lessons.length,
      best: [...best.values()].sort((a, b) => b.score - a.score),
      recent: items.slice(0, 10),
    }
  }, [items])

  if (loading) return <div className="loading">Đang tải tiến trình…</div>

  return (
    <div style={{ marginTop: 18, borderTop: '1px dashed #ead9bd', paddingTop: 14 }}>
      <h3 style={{ margin: '0 0 10px' }}>📈 Tiến trình của bé {studentName}</h3>
      {stats.total === 0 ? (
        <div className="empty" style={{ padding: '20px' }}>
          Bé chưa có hoạt động nào được ghi nhận. Ba mẹ cho bé chọn tên ở trang Trò chơi rồi chơi nhé! 🎮
        </div>
      ) : (
        <>
          <div className="form-inline" style={{ marginTop: 0 }}>
            <div className="admin-box" style={{ flex: 1, minWidth: 140, textAlign: 'center', marginBottom: 0 }}>
              <div style={{ fontSize: 26, fontWeight: 800 }}>{stats.total}</div>
              <div style={{ fontSize: 13, color: '#5d7590' }}>hoạt động</div>
            </div>
            <div className="admin-box" style={{ flex: 1, minWidth: 140, textAlign: 'center', marginBottom: 0 }}>
              <div style={{ fontSize: 26, fontWeight: 800 }}>{stats.lessonCount}</div>
              <div style={{ fontSize: 13, color: '#5d7590' }}>bài học đã xong</div>
            </div>
            <div className="admin-box" style={{ flex: 1, minWidth: 140, textAlign: 'center', marginBottom: 0 }}>
              <div style={{ fontSize: 26, fontWeight: 800 }}>{stats.gameCount}</div>
              <div style={{ fontSize: 13, color: '#5d7590' }}>lượt chơi game</div>
            </div>
          </div>

          {stats.best.length > 0 && (
            <>
              <h4 style={{ margin: '16px 0 6px' }}>🏅 Điểm cao nhất mỗi game</h4>
              {stats.best.map((b, i) => (
                <div className="admin-row" key={i}>
                  <span>{b.label}</span>
                  <b>{b.score}{b.total ? `/${b.total}` : ''}</b>
                </div>
              ))}
            </>
          )}

          <h4 style={{ margin: '16px 0 6px' }}>🕘 10 hoạt động gần nhất</h4>
          {stats.recent.map((r) => (
            <div className="admin-row" key={r.id}>
              <span>
                {r.type === 'game' ? '🎮' : '📖'} {r.label}
                {r.score !== undefined && <b> — {r.score}{r.total ? `/${r.total}` : ''}</b>}
              </span>
              <span style={{ fontSize: 12, color: '#5d7590', whiteSpace: 'nowrap' }}>{formatProgressTime(r.createdAt)}</span>
            </div>
          ))}
        </>
      )}
    </div>
  )
}
