import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { doc, getDoc } from 'firebase/firestore'
import { db } from '../firebase'
import { LessonDoc, LESSON_KINDS } from '../types'

function youtubeEmbed(url: string): string | null {
  const m = url.match(/(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{6,})/)
  return m ? `https://www.youtube.com/embed/${m[1]}` : null
}

function QuizPlayer({ lesson }: { lesson: LessonDoc }) {
  const questions = lesson.questions || []
  const [idx, setIdx] = useState(0)
  const [picked, setPicked] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [done, setDone] = useState(false)
  const [saved, setSaved] = useState(false)
  const q = questions[idx]

  useEffect(() => {
    if (done && !saved) {
      setSaved(true)
      import('../lib/progress').then(({ saveProgress }) => {
        try {
          const raw = localStorage.getItem('bvh_student')
          const st = raw ? JSON.parse(raw) : null
          if (st?.id) saveProgress({ studentId: st.id, type: 'lesson', refId: lesson.id, label: lesson.title, score, total: questions.length })
        } catch { /* bỏ qua */ }
      })
    }
  }, [done])

  if (questions.length === 0) return <div className="empty">Bài trắc nghiệm chưa có câu hỏi.</div>
  if (done) {
    const good = score >= Math.ceil(questions.length * 0.7)
    return (
      <div className="game-stage">
        <div style={{ fontSize: 72 }}>{good ? '🎉' : '💪'}</div>
        <h1>
          Bé đúng {score}/{questions.length} câu!
        </h1>
        <p style={{ color: '#5d7590', fontWeight: 700 }}>
          {good ? 'Giỏi quá, bé làm rất tốt! 🌟' : 'Bé làm lại một lần nữa nhé!'}
        </p>
        <div className="row-center">
          <button className="btn-soft" onClick={() => { setIdx(0); setPicked(null); setScore(0); setDone(false); setSaved(false) }}>
            <span className="e3d">🔄</span> Làm lại
          </button>
          <Link to="/tro-choi">
            <button className="btn-primary"><span className="e3d">🎮</span> Chơi game ôn bài</button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="game-stage">
      <div className="score-bar">
        <span className="score-pill">Câu {idx + 1}/{questions.length}</span>
        <span className="score-pill">⭐ {score} điểm</span>
      </div>
      <h1 style={{ fontSize: 24 }}>{q.q}</h1>
      <div className="pick-grid">
        {q.options.map((op, i) => {
          let cls = 'pick-card'
          if (picked !== null) {
            if (i === q.answer) cls += ' correct'
            else if (i === picked) cls += ' wrong'
          }
          return (
            <button
              key={i}
              className={cls}
              disabled={picked !== null}
              onClick={() => {
                setPicked(i)
                if (i === q.answer) setScore((s) => s + 1)
              }}
            >
              {op}
            </button>
          )
        })}
      </div>
      <div className="game-msg">
        {picked !== null && (picked === q.answer ? '🎉 Đúng rồi, giỏi quá!' : '💪 Sai rồi, đáp án đúng được tô xanh nhé!')}
      </div>
      {picked !== null && (
        <button
          className="btn-primary"
          onClick={() => {
            if (idx + 1 >= questions.length) setDone(true)
            else { setIdx(idx + 1); setPicked(null) }
          }}
        >
          {idx + 1 >= questions.length ? 'Xem kết quả →' : 'Câu tiếp theo →'}
        </button>
      )}
    </div>
  )
}

export default function LessonDetail() {
  const { id } = useParams()
  const [lesson, setLesson] = useState<LessonDoc | null>(null)
  const [zoom, setZoom] = useState<string | null>(null)
  const [showPicker, setShowPicker] = useState(false)
  const [PickerComp, setPickerComp] = useState<any>(null)
  const [marked, setMarked] = useState(false)

  useEffect(() => {
    if (!id) return
    getDoc(doc(db, 'lessons', id))
      .then((d) => d.exists() && setLesson({ id: d.id, ...(d.data() as Omit<LessonDoc, 'id'>) }))
      .catch(() => {})
  }, [id])

  if (!lesson) return <div className="wrap"><div className="loading">Đang tải bài học…</div></div>

  const kind = lesson.kind || 'doc'
  const kindLabel = LESSON_KINDS.find((k) => k.id === kind)?.label || ''
  const embed = kind === 'video' && lesson.mediaUrl ? youtubeEmbed(lesson.mediaUrl) : null

  const markDone = async () => {
    const { saveProgress } = await import('../lib/progress')
    let st: any = null
    try { st = JSON.parse(localStorage.getItem('bvh_student') || 'null') } catch { /* bỏ qua */ }
    if (!st?.id) {
      const mod = await import('../lib/progress')
      setPickerComp(() => mod.StudentPicker)
      setShowPicker(true)
      return
    }
    await saveProgress({ studentId: st.id, type: 'lesson', refId: lesson.id, label: lesson.title })
    setMarked(true)
  }

  return (
    <div className="wrap">
      <Link to={`/lop/${lesson.classId}`} className="back-link">← Về lớp học</Link>
      <div className="lesson-hero">
        <span className="lesson-cat">{lesson.category}</span>{' '}
        <span className="lesson-cat" style={{ background: '#e3f2ff', color: '#2b6cb0' }}>{kindLabel}</span>
        <h1 style={{ marginTop: 10 }}>{lesson.title}</h1>
        <div className="lesson-date">{lesson.date}</div>
      </div>

      {kind === 'video' && (
        <div className="lesson-body" style={{ padding: 16 }}>
          {embed ? (
            <div style={{ position: 'relative', paddingBottom: '56.25%', height: 0, borderRadius: 16, overflow: 'hidden' }}>
              <iframe src={embed} title={lesson.title} allowFullScreen style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', border: 'none' }} />
            </div>
          ) : (
            <a href={lesson.mediaUrl} target="_blank" rel="noreferrer"><button className="btn-primary"><span className="e3d">🎬</span> Mở video</button></a>
          )}
          {lesson.content && <p style={{ marginTop: 16 }}>{lesson.content}</p>}
        </div>
      )}

      {kind === 'audio' && (
        <div className="lesson-body" style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 64, marginBottom: 12 }}><span className="e3d">🎧</span></div>
          {lesson.mediaUrl ? (
            <audio controls src={lesson.mediaUrl} style={{ width: '100%', maxWidth: 480 }} />
          ) : (
            <div className="empty">Chưa có file âm thanh.</div>
          )}
          {lesson.content && <p style={{ marginTop: 16, textAlign: 'left' }}>{lesson.content}</p>}
        </div>
      )}

      {kind === 'doc' && lesson.content && <div className="lesson-body">{lesson.content}</div>}

      {kind === 'quiz' && (
        <>
          {lesson.content && <div className="lesson-body" style={{ marginBottom: 18 }}>{lesson.content}</div>}
          <QuizPlayer lesson={lesson} />
        </>
      )}

      {lesson.images && lesson.images.length > 0 && (
        <>
          <h3 style={{ margin: '18px 0 4px' }}>📷 Ảnh bài học</h3>
          <div className="lesson-gallery">
            {lesson.images.map((u) => (
              <img key={u} src={u} alt="Ảnh bài học" loading="lazy" onClick={() => setZoom(u)} />
            ))}
          </div>
        </>
      )}

      {showPicker && PickerComp && (
        <div className="admin-box" style={{ marginBottom: 18 }}>
          <h3>👧 Bé là ai?</h3>
          <p style={{ color: '#5d7590', fontSize: 14 }}>Chọn tên bé để lưu tiến trình học tập nhé!</p>
          <PickerComp onPick={(sid: string, name: string) => {
            setShowPicker(false)
            import('../lib/progress').then(({ saveProgress }) =>
              saveProgress({ studentId: sid, type: 'lesson', refId: lesson.id, label: lesson.title }).then(() => setMarked(true))
            )
          }} />
        </div>
      )}

      <div className="row-center" style={{ marginBottom: 60 }}>
        {kind !== 'quiz' && (
          marked ? (
            <div className="notice" style={{ margin: 0 }}>✅ Đã lưu vào tiến trình học tập của bé!</div>
          ) : (
            <button className="btn-sun" onClick={markDone}><span className="e3d">✅</span> Bé đã học xong bài này</button>
          )
        )}
        {lesson.link && (
          <a href={lesson.link} target="_blank" rel="noreferrer">
            <button className="btn-soft"><span className="e3d">🔗</span> Mở tài liệu đính kèm</button>
          </a>
        )}
        <Link to="/tro-choi">
          <button className="btn-primary"><span className="e3d">🎮</span> Chơi game ôn bài</button>
        </Link>
      </div>
      {zoom && (
        <div className="lightbox" onClick={() => setZoom(null)}>
          <button className="lightbox-close" onClick={() => setZoom(null)} aria-label="Đóng">
            ✕
          </button>
          <img src={zoom} alt="Ảnh phóng to" onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </div>
  )
}
