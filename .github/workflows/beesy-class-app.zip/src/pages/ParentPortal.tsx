import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { signInWithEmailAndPassword, signOut } from 'firebase/auth'
import {
  collection, doc, documentId, getDoc, getDocs, limit, orderBy, query, where,
} from 'firebase/firestore'
import { auth, db, isConfigured } from '../firebase'
import { ClassDoc, ParentDoc, ProgressDoc, StudentDoc, TuitionRecord } from '../types'
import { useParent } from '../lib/parentAuth'

const fmtVND = (n: number) => n.toLocaleString('vi-VN') + 'đ'
const fmtDay = (ts: number) => new Date(ts).toLocaleDateString('vi-VN')

function friendlyAuthError(code: string): string {
  if (code === 'auth/invalid-credential' || code === 'auth/user-not-found' || code === 'auth/wrong-password')
    return 'Sai email hoặc mật khẩu.'
  if (code === 'auth/invalid-email') return 'Email chưa đúng định dạng.'
  if (code === 'auth/network-request-failed') return 'Lỗi mạng, anh/chị kiểm tra internet rồi thử lại.'
  return 'Có lỗi xảy ra (' + code + ').'
}

export default function ParentPortal() {
  const { parent, authUser, loading } = useParent()

  if (!isConfigured) {
    return (
      <div className="wrap"><div className="admin">
        <div className="notice">Web chưa có cấu hình Firebase.</div>
        <Link to="/">← Về trang chủ</Link>
      </div></div>
    )
  }

  return (
    <div className="wrap"><div className="admin">
      <Link to="/" className="back-link">← Về trang chủ</Link>
      <h1>👨‍👩‍👧 Góc phụ huynh</h1>
      {loading && <div className="loading">Đang tải…</div>}
      {!loading && !authUser && <LoginBox />}
      {!loading && authUser && !parent && <NotParentBox />}
      {!loading && parent && <Dashboard parent={parent} />}
    </div></div>
  )
}

function LoginBox() {
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)

  const login = async () => {
    setMsg('')
    if (!email.trim() || !pass) {
      setMsg('Anh/chị nhập email và mật khẩu nhé.')
      return
    }
    setBusy(true)
    try {
      await signInWithEmailAndPassword(auth, email.trim(), pass)
    } catch (e: any) {
      setMsg(friendlyAuthError(e?.code || ''))
    }
    setBusy(false)
  }

  return (
    <div className="admin-box" style={{ maxWidth: 440 }}>
      <h2>Đăng nhập</h2>
      <p style={{ color: '#5d7590', fontSize: 14 }}>
        Dùng email và mật khẩu do cô giáo cấp để xem tình hình học tập của bé.
      </p>
      {msg && <div className="notice">{msg}</div>}
      <div className="field"><label>Email</label><input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@vidu.com" inputMode="email" /></div>
      <div className="field"><label>Mật khẩu</label><input type="password" value={pass} onChange={(e) => setPass(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && login()} /></div>
      <button className="btn-primary" disabled={busy} onClick={login}>
        {busy ? 'Đang đăng nhập…' : 'Đăng nhập'}
      </button>
    </div>
  )
}

function NotParentBox() {
  return (
    <div className="admin-box" style={{ maxWidth: 440 }}>
      <h2>⚠️ Không phải tài khoản phụ huynh</h2>
      <p style={{ color: '#5d7590' }}>Tài khoản này không liên kết với bé nào. Đây có thể là tài khoản quản trị.</p>
      <button className="btn-soft" onClick={() => signOut(auth)}>Đăng xuất</button>
    </div>
  )
}

function Dashboard({ parent }: { parent: ParentDoc }) {
  return (
    <>
      <div className="admin-box" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>Xin chào, <b>{parent.name}</b> 👋</div>
        <button className="btn-small" onClick={() => signOut(auth)}>Đăng xuất</button>
      </div>
      {parent.studentIds.length === 0 && (
        <div className="notice">Tài khoản chưa liên kết với bé nào. Anh/chị liên hệ cô giáo nhé.</div>
      )}
      {parent.studentIds.map((sid) => (
        <ChildCard key={sid} studentId={sid} />
      ))}
    </>
  )
}

function ChildCard({ studentId }: { studentId: string }) {
  const [student, setStudent] = useState<StudentDoc | null>(null)
  const [className, setClassName] = useState('')
  const [att, setAtt] = useState<{ present: number; absent: number } | null>(null)
  const [tuition, setTuition] = useState<TuitionRecord[]>([])
  const [progress, setProgress] = useState<ProgressDoc[]>([])
  const [err, setErr] = useState('')

  useEffect(() => {
    let alive = true
    const run = async () => {
      try {
        const sSnap = await getDoc(doc(db, 'students', studentId))
        if (!sSnap.exists()) {
          if (alive) setErr('Không tìm thấy thông tin bé.')
          return
        }
        const s = { id: sSnap.id, ...(sSnap.data() as Omit<StudentDoc, 'id'>) }
        if (alive) setStudent(s)

        const cSnap = await getDoc(doc(db, 'classes', s.classId))
        if (alive && cSnap.exists()) setClassName((cSnap.data() as ClassDoc).name)

        // Điểm danh 30 buổi gần nhất của lớp
        const prefix = `${s.classId}_`
        const attSnap = await getDocs(
          query(
            collection(db, 'attendance'),
            where(documentId(), '>=', prefix),
            where(documentId(), '<=', prefix + '\uf8ff'),
            orderBy(documentId(), 'desc'),
            limit(30),
          ),
        )
        let present = 0
        let absent = 0
        attSnap.forEach((d) => {
          const records = (d.data() as { records?: Record<string, string> }).records || {}
          if (records[studentId] === 'absent') absent++
          else present++
        })
        if (alive) setAtt({ present, absent })

        // Học phí của bé (sắp xếp mới nhất trước)
        const tSnap = await getDocs(
          query(collection(db, 'tuition_records'), where('studentId', '==', studentId)),
        )
        const trecs = tSnap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<TuitionRecord, 'id'>) }))
          .sort((a, b) => b.createdAt - a.createdAt)
        if (alive) setTuition(trecs)

        // 5 hoạt động học tập gần nhất
        const pSnap = await getDocs(
          query(collection(db, 'progress'), where('studentId', '==', studentId)),
        )
        const progs = pSnap.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<ProgressDoc, 'id'>) }))
          .sort((a, b) => b.createdAt - a.createdAt)
          .slice(0, 5)
        if (alive) setProgress(progs)
      } catch {
        if (alive) setErr('Không tải được dữ liệu. Anh/chị thử tải lại trang nhé.')
      }
    }
    run()
    return () => { alive = false }
  }, [studentId])

  if (err) return <div className="announce-card"><p>{err}</p></div>
  if (!student) return <div className="loading">Đang tải thông tin bé…</div>

  return (
    <div className="announce-card">
      <div className="announce-head">
        <h3>🧒 {student.name}{className && <span className="lesson-cat">{className}</span>}</h3>
      </div>

      <p style={{ marginTop: 12 }}>
        <b>📋 Điểm danh 30 buổi gần nhất:</b>{' '}
        {att ? (
          <>đi học <b style={{ color: '#15803d' }}>{att.present}</b> buổi · vắng <b style={{ color: '#b91c1c' }}>{att.absent}</b> buổi</>
        ) : 'đang tải…'}
      </p>

      <p>
        <b>💰 Học phí:</b>{' '}
        {tuition.length === 0 ? (
          'chưa có phiếu thu nào'
        ) : (
          <ul style={{ margin: '6px 0 0', paddingLeft: 20 }}>
            {tuition.map((t) => {
              const done = t.amount > 0 && t.paid >= t.amount
              const remain = Math.max(0, t.amount - t.paid)
              return (
                <li key={t.id}>
                  Kỳ {t.period}: phải đóng {fmtVND(t.amount)}, đã đóng {fmtVND(t.paid)}
                  {done ? ' ✅' : remain > 0 ? ` — còn lại ${fmtVND(remain)}` : ''}
                </li>
              )
            })}
          </ul>
        )}
      </p>

      <p>
        <b>🌟 Hoạt động học tập gần đây:</b>{' '}
        {progress.length === 0 ? (
          'chưa có'
        ) : (
          <ul style={{ margin: '6px 0 0', paddingLeft: 20 }}>
            {progress.map((p) => (
              <li key={p.id}>
                {p.label}
                {p.score !== undefined && p.total ? ` — ${p.score}/${p.total}` : ''}
                {' '}· <span style={{ color: '#5d7590' }}>{fmtDay(p.createdAt)}</span>
              </li>
            ))}
          </ul>
        )}
      </p>
    </div>
  )
}
