import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { collection, getDocs, orderBy, query } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { AlbumDoc } from '../types'
import { videoPoster } from '../lib/cloudinary'

export default function Albums() {
  const [list, setList] = useState<AlbumDoc[]>([])

  useEffect(() => {
    if (!isConfigured) return
    getDocs(query(collection(db, 'albums'), orderBy('createdAt', 'desc')))
      .then((s) => setList(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<AlbumDoc, 'id'>) }))))
      .catch(() => {})
  }, [])

  return (
    <div className="wrap">
      <section className="section">
        <div className="section-head">
          <div>
            <h2>🖼️ Thư viện ảnh</h2>
            <p>Những khoảnh khắc đáng yêu của các bé</p>
          </div>
        </div>
        {list.length === 0 ? (
          <div className="empty">Chưa có album nào. Bé quay lại sau nhé! 🌈</div>
        ) : (
          <div className="class-grid">
            {list.map((a) => (
              <Link key={a.id} to={`/thu-vien-anh/${a.id}`} className="class-card">
                <div
                  style={{
                    height: 200,
                    background: a.coverUrl ? `url(${a.coverUrl.includes('/video/upload/') ? videoPoster(a.coverUrl) : a.coverUrl}) center/cover` : '#f6f1e7',
                  }}
                />
                <div className="class-body">
                  <h3 className="class-name" style={{ fontSize: 22 }}>{a.title}</h3>
                  <div className="class-meta"><span className="meta-ic">📅</span> {a.date}</div>
                  <div className="class-meta"><span className="meta-ic">📷</span> {(a.photos || []).filter((p) => p.kind !== 'video').length} ảnh{(a.photos || []).some((p) => p.kind === 'video') ? ` · 🎬 ${(a.photos || []).filter((p) => p.kind === 'video').length} video` : ''}</div>
                  <span className="link-go">Xem album →</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
