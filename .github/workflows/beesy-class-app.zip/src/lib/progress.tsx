import { useCallback, useEffect, useState } from 'react'
import { addDoc, collection, getDocs, orderBy, query, where } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { ClassDoc, ProgressDoc, StudentDoc } from '../types'

const KEY = 'bvh_student'

/** Bé đang chơi (lưu ở máy này). Dùng cho trang game để biết lưu điểm cho ai. */
export function useCurrentStudent(): {
  id: string | null
  name: string | null
  set: (id: string, name: string) => void
  clear: () => void
} {
  const [cur, setCur] = useState<{ id: string; name: string } | null>(() => {
    try {
      const raw = localStorage.getItem(KEY)
      return raw ? (JSON.parse(raw) as { id: string; name: string }) : null
    } catch {
      return null
    }
  })
  const set = useCallback((id: string, name: string) => {
    const v = { id, name }
    try {
      localStorage.setItem(KEY, JSON.stringify(v))
    } catch {
      /* bỏ qua */
    }
    setCur(v)
  }, [])
  const clear = useCallback(() => {
    try {
      localStorage.removeItem(KEY)
    } catch {
      /* bỏ qua */
    }
    setCur(null)
  }, [])
  return { id: cur?.id ?? null, name: cur?.name ?? null, set, clear }
}

/** Chọn "bé nào đang chơi" — danh sách học sinh nhóm theo lớp. */
export function StudentPicker({ onPick }: { onPick: (id: string, name: string) => void }) {
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [students, setStudents] = useState<StudentDoc[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isConfigured) {
      setLoading(false)
      return
    }
    Promise.all([
      getDocs(query(collection(db, 'classes'), orderBy('order'))),
      getDocs(collection(db, 'students')),
    ])
      .then(([cs, ss]) => {
        setClasses(cs.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) })))
        setStudents(ss.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudentDoc, 'id'>) })))
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="loading">Đang tải danh sách bé…</div>
  if (classes.length === 0) return <div className="empty">Chưa có lớp học nào.</div>

  return (
    <div>
      {classes.map((c) => {
        const list = students.filter((s) => s.classId === c.id).sort((a, b) => a.name.localeCompare(b.name))
        if (list.length === 0) return null
        return (
          <div key={c.id} style={{ marginBottom: 16 }}>
            <div style={{ fontWeight: 800, marginBottom: 8 }}>
              <span className="e3d">{c.mascot}</span> {c.name}
            </div>
            <div className="student-chips">
              {list.map((s) => (
                <button key={s.id} type="button" className="student-chip" onClick={() => onPick(s.id, s.name)}>
                  {s.name}
                </button>
              ))}
            </div>
          </div>
        )
      })}
    </div>
  )
}

/** Ghi 1 dòng tiến trình. Đọc bé hiện tại trực tiếp từ localStorage (không stale). Lỗi thì bỏ qua, không gián đoạn game. */
export async function saveProgress(p: Omit<ProgressDoc, 'id' | 'createdAt'>): Promise<void> {
  if (!isConfigured) return
  try {
    await addDoc(collection(db, 'progress'), { ...p, createdAt: Date.now() })
  } catch {
    /* bỏ qua — không làm gián đoạn game */
  }
}

/** Ghi điểm game cho bé đang chơi (nếu có). Bỏ qua nếu chưa chọn bé hoặc điểm = 0. */
export function recordGameScore(refId: string, label: string, score?: number, total?: number): void {
  try {
    const raw = localStorage.getItem(KEY)
    const cur = raw ? (JSON.parse(raw) as { id: string }) : null
    if (!cur?.id) return
    if ((score ?? 0) === 0 && (total ?? 0) === 0) return
    void saveProgress({ studentId: cur.id, type: 'game', refId, label, score, total })
  } catch {
    /* bỏ qua */
  }
}

/** Lịch sử tiến trình của 1 bé (mới nhất trước, tối đa 50). Sắp xếp ở client để khỏi cần composite index. */
export function useStudentProgress(studentId: string | null): { items: ProgressDoc[]; loading: boolean } {
  const [items, setItems] = useState<ProgressDoc[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!studentId || !isConfigured) {
      setItems([])
      return
    }
    setLoading(true)
    getDocs(query(collection(db, 'progress'), where('studentId', '==', studentId)))
      .then((s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ProgressDoc, 'id'>) }))
        list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
        setItems(list.slice(0, 50))
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [studentId])

  return { items, loading }
}

/** Định dạng thời gian hiển thị: "10/10/2026 08:30". */
export function formatProgressTime(ts: number): string {
  try {
    const d = new Date(ts)
    const date = d.toLocaleDateString('vi-VN')
    const time = d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
    return `${date} ${time}`
  } catch {
    return ''
  }
}
