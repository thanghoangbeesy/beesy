import { doc, getDoc } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { MediaSettings } from '../types'
import { compressImage } from './images'

/** Đọc cấu hình Cloudinary từ settings/media. Trả null nếu chưa cấu hình. */
export async function getMediaSettings(): Promise<MediaSettings | null> {
  if (!isConfigured) return null
  try {
    const s = await getDoc(doc(db, 'settings', 'media'))
    if (!s.exists()) return null
    const d = s.data() as Partial<MediaSettings>
    if (!d.cloudName?.trim() || !d.uploadPreset?.trim()) return null
    return { cloudName: d.cloudName.trim(), uploadPreset: d.uploadPreset.trim() }
  } catch {
    return null
  }
}

/**
 * Nén ảnh (cạnh dài nhất 1600px, JPEG 0.8) rồi tải lên Cloudinary (unsigned).
 * Trả về secure_url. Throw Error('MEDIA_NOT_CONFIGURED') nếu chưa cấu hình.
 */
export async function uploadImageToCloudinary(file: File): Promise<string> {
  const settings = await getMediaSettings()
  if (!settings) throw new Error('MEDIA_NOT_CONFIGURED')
  const blob = await compressImage(file, 1600, 0.8)
  const form = new FormData()
  form.append('file', blob, 'photo.jpg')
  form.append('upload_preset', settings.uploadPreset)
  let res: Response
  try {
    res = await fetch(`https://api.cloudinary.com/v1_1/${settings.cloudName}/image/upload`, {
      method: 'POST',
      body: form,
    })
  } catch {
    throw new Error('Không kết nối được Cloudinary. Anh kiểm tra mạng rồi thử lại nhé.')
  }
  const json = (await res.json().catch(() => null)) as { secure_url?: string; error?: { message?: string } } | null
  if (!res.ok || !json?.secure_url) {
    const msg = json?.error?.message || ''
    throw new Error(
      msg
        ? `Cloudinary báo lỗi: ${msg}`
        : 'Tải ảnh lên Cloudinary thất bại. Anh kiểm tra lại Cloud name và Upload preset nhé.',
    )
  }
  return json.secure_url
}

const MAX_VIDEO_BYTES = 100 * 1024 * 1024 // gói miễn phí Cloudinary: tối đa 100MB/video

/**
 * Tải video lên Cloudinary (unsigned). Không nén (trình duyệt không nén được video),
 * nên file gốc phải <= 100MB. Trả về secure_url. Throw Error với thông báo thân thiện.
 */
export async function uploadVideoToCloudinary(file: File): Promise<string> {
  const settings = await getMediaSettings()
  if (!settings) throw new Error('MEDIA_NOT_CONFIGURED')
  if (file.size > MAX_VIDEO_BYTES) {
    throw new Error(`Video "${file.name}" nặng quá (${(file.size / 1048576).toFixed(0)}MB). Gói miễn phí chỉ cho video tối đa 100MB — anh quay ngắn lại hoặc giảm chất lượng rồi tải lại nhé.`)
  }
  const form = new FormData()
  form.append('file', file, file.name || 'video.mp4')
  form.append('upload_preset', settings.uploadPreset)
  let res: Response
  try {
    res = await fetch(`https://api.cloudinary.com/v1_1/${settings.cloudName}/video/upload`, {
      method: 'POST',
      body: form,
    })
  } catch {
    throw new Error('Không kết nối được Cloudinary. Anh kiểm tra mạng rồi thử lại nhé.')
  }
  const json = (await res.json().catch(() => null)) as { secure_url?: string; error?: { message?: string } } | null
  if (!res.ok || !json?.secure_url) {
    const msg = json?.error?.message || ''
    throw new Error(
      msg
        ? `Cloudinary báo lỗi: ${msg}`
        : 'Tải video lên Cloudinary thất bại. Anh kiểm tra lại Cloud name và Upload preset nhé.',
    )
  }
  return json.secure_url
}

/** Lấy ảnh poster (khung hình đầu) của 1 video Cloudinary để làm thumbnail/bìa. */
export function videoPoster(videoUrl: string): string {
  try {
    const u = videoUrl.replace('/video/upload/', '/video/upload/so_0/')
    return u.replace(/\.(mp4|mov|webm|mkv|avi)(\?.*)?$/i, '.jpg$2')
  } catch {
    return videoUrl
  }
}
