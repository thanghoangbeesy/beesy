import { useEffect, useState } from 'react'
import { getApps, initializeApp } from 'firebase/app'
import {
  createUserWithEmailAndPassword,
  getAuth,
  onAuthStateChanged,
  signOut,
  User,
} from 'firebase/auth'
import { deleteDoc, doc, getDoc, setDoc, updateDoc } from 'firebase/firestore'
import { auth, db, firebaseConfig } from '../firebase'
import { ParentDoc } from '../types'

/**
 * Auth phụ trên app phụ — tạo tài khoản phụ huynh mà KHÔNG đăng xuất
 * tài khoản quản trị đang dùng ở app chính.
 */
function secondaryAuth() {
  const existing = getApps().find((a) => a.name === 'parent-signup')
  const app = existing ?? initializeApp(firebaseConfig, 'parent-signup')
  return getAuth(app)
}

/** Tạo tài khoản đăng nhập cho phụ huynh + lưu hồ sơ vào collection `parents`. Trả về uid. */
export async function createParentAccount(
  email: string,
  password: string,
  name: string,
  phone: string,
  studentIds: string[],
): Promise<string> {
  const sAuth = secondaryAuth()
  try {
    const cred = await createUserWithEmailAndPassword(sAuth, email.trim(), password)
    const uid = cred.user.uid
    const data: Record<string, unknown> = {
      uid,
      email: email.trim().toLowerCase(),
      name: name.trim(),
      studentIds,
      createdAt: Date.now(),
    }
    if (phone.trim()) data.phone = phone.trim()
    await setDoc(doc(db, 'parents', uid), data)
    return uid
  } finally {
    // Luôn đăng xuất app phụ để không ảnh hưởng phiên admin
    await signOut(sAuth).catch(() => {})
  }
}

/** Hook: theo dõi đăng nhập + hồ sơ phụ huynh. parent=null khi là tài khoản quản trị. */
export function useParent() {
  const [authUser, setAuthUser] = useState<User | null>(null)
  const [parent, setParent] = useState<ParentDoc | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    return onAuthStateChanged(auth, async (u) => {
      setAuthUser(u)
      if (!u) {
        setParent(null)
        setLoading(false)
        return
      }
      try {
        const snap = await getDoc(doc(db, 'parents', u.uid))
        setParent(snap.exists() ? (snap.data() as ParentDoc) : null)
      } catch {
        setParent(null)
      }
      setLoading(false)
    })
  }, [])

  return { parent, authUser, loading }
}

/** Cập nhật danh sách bé liên kết với phụ huynh. */
export function updateParentStudents(uid: string, studentIds: string[]) {
  return updateDoc(doc(db, 'parents', uid), { studentIds })
}

/**
 * Xóa hồ sơ phụ huynh trong Firestore.
 * Lưu ý: tài khoản đăng nhập (Firebase Auth) vẫn tồn tại — chỉ xóa liên kết,
 * muốn xóa hẳn tài khoản thì xóa trong Firebase Console → Authentication.
 */
export function deleteParentDoc(uid: string) {
  return deleteDoc(doc(db, 'parents', uid))
}
