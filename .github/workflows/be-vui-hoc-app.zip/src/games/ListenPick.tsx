import { useEffect, useState } from 'react'
import { Volume2, RotateCcw } from 'lucide-react'
import { GameBack, shuffle, speak, useWords } from './shared'
import { WordDoc } from '../types'

export default function ListenPick() {
  const words = useWords()
  const [options, setOptions] = useState<WordDoc[]>([])
  const [target, setTarget] = useState<WordDoc | null>(null)
  const [picked, setPicked] = useState<string | null>(null)
  const [score, setScore] = useState(0)
  const [round, setRound] = useState(0)

  const newRound = (list: WordDoc[]) => {
    const opts = shuffle(list).slice(0, 4)
    const t = opts[Math.floor(Math.random() * opts.length)]
    setOptions(opts)
    setTarget(t)
    setPicked(null)
    setTimeout(() => speak(t.text), 400)
  }

  useEffect(() => {
    if (words.length >= 4) newRound(words)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [words.length])

  const pick = (w: WordDoc) => {
    if (picked || !target) return
    setPicked(w.id)
    if (w.id === target.id) {
      setScore((s) => s + 1)
      speak('Đúng rồi! Giỏi lắm!')
      setTimeout(() => {
        setRound((r) => r + 1)
        newRound(words)
      }, 1400)
    } else {
      speak('Chưa đúng, bé thử lại nhé!')
    }
  }

  return (
    <div className="wrap">
      <div className="game-stage">
        <GameBack title="🔊 Nghe và chọn" />
        <p style={{ color: '#62708a' }}>Nghe cô đọc, rồi chạm vào hình đúng nhé!</p>
        <div className="score-bar">
          <div className="score-pill">⭐ Điểm: {score}</div>
          <div className="score-pill">🎲 Ván: {round + 1}</div>
        </div>
        <button className="speak-btn" onClick={() => target && speak(target.text)} aria-label="Nghe lại">
          <Volume2 size={44} />
        </button>
        <div style={{ color: '#62708a', fontSize: 13, marginBottom: 14 }}>Chạm vào loa để nghe lại</div>
        <div className="pick-grid">
          {options.map((w) => (
            <button
              key={w.id}
              className={`pick-card${picked === w.id ? (w.id === target?.id ? ' correct' : ' wrong') : ''}`}
              onClick={() => pick(w)}
            >
              <span className="big">{w.emoji}</span>
              <span>{picked ? w.text : '?'}</span>
            </button>
          ))}
        </div>
        <div className="game-msg">
          {picked && target && (picked === target.id ? '🎉 Đúng rồi, giỏi quá!' : '💪 Sai rồi, nghe kỹ rồi chọn lại nhé!')}
        </div>
        <button className="btn-soft" onClick={() => { setScore(0); setRound(0); newRound(words) }}>
          <RotateCcw size={15} /> Chơi lại từ đầu
        </button>
      </div>
    </div>
  )
}
