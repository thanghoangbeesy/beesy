import { useEffect, useState } from 'react'
import { Volume2, Eraser, ArrowRight } from 'lucide-react'
import { GameBack, shuffle, speak, useWords, warmUpVoice } from './shared'
import { WordDoc } from '../types'

interface Tile {
  ch: string
  idx: number
}

export default function SpellWord() {
  const words = useWords()
  const [word, setWord] = useState<WordDoc | null>(null)
  const [tiles, setTiles] = useState<Tile[]>([])
  const [picked, setPicked] = useState<number[]>([])
  const [wrong, setWrong] = useState<number | null>(null)
  const [score, setScore] = useState(0)
  const [done, setDone] = useState(false)

  const newWord = (list: WordDoc[], avoidId?: string) => {
    const pool = list.filter((w) => w.text && w.text.length >= 2 && w.id !== avoidId)
    if (!pool.length) return
    const w = pool[Math.floor(Math.random() * pool.length)]
    setWord(w)
    setTiles(shuffle(w.text.split('').map((ch, idx) => ({ ch, idx }))))
    setPicked([])
    setDone(false)
    setWrong(null)
  }

  useEffect(() => {
    warmUpVoice()
    if (words.length >= 4 && !word) newWord(words)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [words.length])

  if (!word) return <div className="wrap"><div className="loading">Đang chuẩn bị…</div></div>

  const answer = picked.map((i) => tiles.find((t) => t.idx === i)!.ch).join('')

  const tap = (t: Tile) => {
    if (done || picked.includes(t.idx)) return
    const expected = word.text[answer.length]
    if (t.ch === expected) {
      const np = [...picked, t.idx]
      setPicked(np)
      speak(t.ch, true)
      if (np.length === word.text.length) {
        setDone(true)
        setScore((s) => s + 1)
        speak(`Đúng rồi! Từ ${word.text}`, true)
      }
    } else {
      setWrong(t.idx)
      setTimeout(() => setWrong(null), 500)
    }
  }

  const remaining = tiles.filter((t) => !picked.includes(t.idx))

  return (
    <div className="wrap">
      <div className="game-stage">
        <GameBack title="🧩 Xếp chữ thành từ" />
        <p style={{ color: '#62708a' }}>Nhìn hình, nghe từ rồi chạm các chữ cái theo đúng thứ tự nhé!</p>
        <div className="score-bar">
          <div className="score-pill">⭐ Điểm: {score}</div>
        </div>
        <div style={{ fontSize: 90, margin: '6px 0' }}>{word.emoji}</div>
        <button className="btn-soft" onClick={() => speak(word.text, true)} style={{ marginBottom: 16 }}>
          <Volume2 size={16} /> Nghe từ
        </button>
        <div className="flash-card" style={{ minHeight: 110, cursor: 'default', padding: 18 }}>
          {answer ? (
            <div className="word" style={{ letterSpacing: 4 }}>{answer}</div>
          ) : (
            <div className="tap-hint">Chạm các chữ cái ở dưới 👇</div>
          )}
          {done && <div className="game-msg" style={{ margin: '10px 0 0' }}>🎉 Đúng rồi, giỏi quá!</div>}
        </div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 16 }}>
          {remaining.map((t) => (
            <button
              key={t.idx}
              className="pick-card"
              style={{
                minWidth: 58,
                padding: '14px 10px',
                fontSize: 28,
                borderColor: wrong === t.idx ? '#ef4444' : undefined,
                background: wrong === t.idx ? '#fef2f2' : undefined,
              }}
              onClick={() => tap(t)}
            >
              {t.ch}
            </button>
          ))}
        </div>
        <div className="row-center">
          <button className="btn-soft" onClick={() => { setPicked([]); setWrong(null) }}>
            <Eraser size={15} /> Xếp lại
          </button>
          <button className="btn-soft" onClick={() => newWord(words, word.id)}>
            Từ tiếp theo <ArrowRight size={15} />
          </button>
        </div>
      </div>
    </div>
  )
}
