import { useEffect, useState } from 'react'
import { collection, getDocs } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { WordDoc } from '../types'

// ---------- Giọng đọc tiếng Việt ----------
// Tự chọn giọng nữ miền Bắc (ưu tiên Microsoft HoaiMy, Google Tiếng Việt...),
// tốc độ bình thường, các câu thoại xếp hàng chờ nhau — không đè, không cắt.
type QItem = { text: string }
let queue: QItem[] = []
let speaking = false
let cachedVoice: SpeechSynthesisVoice | null = null
let voicesLoaded = false
let interruptToken = 0

function pickVoice(): SpeechSynthesisVoice | null {
  try {
    const voices = window.speechSynthesis.getVoices()
    if (!voices.length) return null
    const vi = voices.filter((v) => v.lang && v.lang.toLowerCase().startsWith('vi'))
    const pool = vi.length ? vi : voices
    const score = (v: SpeechSynthesisVoice) => {
      const n = ((v.name || '') + ' ' + ((v as any).voiceURI || '')).toLowerCase()
      const lang = (v.lang || '').toLowerCase()
      let s = 0
      if (lang === 'vi-vn') s += 10
      else if (lang.startsWith('vi')) s += 5
      if (n.includes('hoaimy')) s += 20 // Microsoft HoaiMy: nữ, miền Bắc
      if (n.includes('google') && n.includes('viet')) s += 12 // Google Tiếng Việt: nữ
      if (n.includes('linh')) s += 8
      if (n.includes('female') || n.includes('nữ')) s += 6
      if (n.includes('namminh')) s -= 20 // Microsoft NamMinh: nam
      if (/\bmale\b/.test(n) && !n.includes('female')) s -= 6
      return s
    }
    return pool.slice().sort((a, b) => score(b) - score(a))[0] || null
  } catch {
    return null
  }
}

function ensureVoices() {
  try {
    const vs = window.speechSynthesis.getVoices()
    if (vs.length) {
      cachedVoice = pickVoice()
      voicesLoaded = true
    } else if (!voicesLoaded) {
      window.speechSynthesis.addEventListener(
        'voiceschanged',
        () => {
          cachedVoice = pickVoice()
          voicesLoaded = true
        },
        { once: true },
      )
    }
  } catch {}
}

export function warmUpVoice() {
  ensureVoices()
}

function speakNow(text: string) {
  const u = new SpeechSynthesisUtterance(text)
  u.lang = 'vi-VN'
  u.rate = 1 // tốc độ bình thường, không kéo dài
  u.pitch = 1
  u.volume = 1
  if (cachedVoice) u.voice = cachedVoice
  speaking = true
  const done = () => {
    speaking = false
    pump()
  }
  u.onend = done
  u.onerror = done
  window.speechSynthesis.speak(u)
}

function pump() {
  if (speaking) return
  const next = queue.shift()
  if (next) speakNow(next.text)
}

/**
 * Đọc một câu tiếng Việt.
 * @param interrupt=true: ngắt câu đang đọc, đọc ngay (nút "nghe lại", phản hồi đúng/sai)
 * @param interrupt=false: xếp hàng chờ câu hiện tại đọc xong (không đè, không cắt)
 */
export function speak(text: string, interrupt = true) {
  try {
    ensureVoices()
    if (interrupt) {
      const my = ++interruptToken
      window.speechSynthesis.cancel()
      queue = []
      speaking = false
      // Chrome cần một nhịp nghỉ sau cancel(), nếu không câu mới có thể bị nuốt
      setTimeout(() => {
        if (my === interruptToken) speakNow(text)
      }, 80)
    } else {
      queue.push({ text })
      pump()
    }
  } catch {}
}

export function stopSpeak() {
  try {
    interruptToken++
    window.speechSynthesis.cancel()
    queue = []
    speaking = false
  } catch {}
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

const FALLBACK_WORDS: WordDoc[] = [
  { id: 'f1', text: 'ba', emoji: '👨' }, { id: 'f2', text: 'mẹ', emoji: '👩' },
  { id: 'f3', text: 'cá', emoji: '🐟' }, { id: 'f4', text: 'gà', emoji: '🐔' },
  { id: 'f5', text: 'chó', emoji: '🐶' }, { id: 'f6', text: 'mèo', emoji: '🐱' },
  { id: 'f7', text: 'hoa', emoji: '🌸' }, { id: 'f8', text: 'nhà', emoji: '🏠' },
  { id: 'f9', text: 'xe', emoji: '🚗' }, { id: 'f10', text: 'bóng', emoji: '⚽' },
  { id: 'f11', text: 'sách', emoji: '📖' }, { id: 'f12', text: 'cam', emoji: '🍊' },
]

export function useWords() {
  const [words, setWords] = useState<WordDoc[]>(FALLBACK_WORDS)
  useEffect(() => {
    if (!isConfigured) return
    getDocs(collection(db, 'words'))
      .then((s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<WordDoc, 'id'>) }))
        if (list.length >= 4) setWords(list)
      })
      .catch(() => {})
  }, [])
  return words
}

export function GameBack({ title }: { title: string }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <a href="/tro-choi" className="back-link">← Tất cả trò chơi</a>
      <h1 style={{ margin: '4px 0 0' }}>{title}</h1>
    </div>
  )
}
