import { useEffect, useState } from 'react'
import { collection, getDocs } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { WordDoc } from '../types'

// Đọc từ tiếng Việt bằng giọng máy có sẵn trên điện thoại/máy tính
export function speak(text: string) {
  try {
    window.speechSynthesis.cancel()
    const u = new SpeechSynthesisUtterance(text)
    u.lang = 'vi-VN'
    u.rate = 0.8
    window.speechSynthesis.speak(u)
  } catch {}
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

const FALLBACK_WORDS: WordDoc[] = [
  { id: 'f1', text: 'ba', emoji: '👨' }, { id: 'f2', text: 'mẹ', emoji: '👩' },
  { id: 'f3', text: 'cá', emoji: '🐟' }, { id: 'f4', text: 'gà', emoji: '🐔' },
  { id: 'f5', text: 'chó', emoji: '🐶' }, { id: 'f6', text: 'mèo', emoji: '🐱' },
  { id: 'f7', text: 'hoa', emoji: '🌸' }, { id: 'f8', text: 'nhà', emoji: '🏠' },
  { id: 'f9', text: 'xe', emoji: '🚗' }, { id: 'f10', text: 'bóng', emoji: '⚽' },
  { id: 'f11', text: 'sách', emoji: '📖' }, { id: 'f12', text: 'cam', emoji: '🍊' },
]

export function useWords() {
  const [words, setWords] = useState<WordDoc[]>(FALLBACK_WORDS)
  useEffect(() => {
    if (!isConfigured) return
    getDocs(collection(db, 'words'))
      .then((s) => {
        const list = s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<WordDoc, 'id'>) }))
        if (list.length >= 4) setWords(list)
      })
      .catch(() => {})
  }, [])
  return words
}

export function GameBack({ title }: { title: string }) {
  return (
    <div style={{ marginBottom: 8 }}>
      <a href="/tro-choi" className="back-link">← Tất cả trò chơi</a>
      <h1 style={{ margin: '4px 0 0' }}>{title}</h1>
    </div>
  )
}
