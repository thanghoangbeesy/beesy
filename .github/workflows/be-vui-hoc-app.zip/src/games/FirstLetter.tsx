import { useEffect, useState } from 'react'
import { RotateCcw } from 'lucide-react'
import { GameBack, shuffle, speak, useWords } from './shared'
import { WordDoc } from '../types'

interface Round {
  word: WordDoc
  options: string[]
}

function makeRound(words: WordDoc[]): Round | null {
  if (words.length < 4) return null
  const word = words[Math.floor(Math.random() * words.length)]
  const first = word.text.charAt(0)
  const others = shuffle(words.map((w) => w.text.charAt(0)).filter((c) => c !== first && c.trim() !== ''))
  const options = shuffle([first, ...others.slice(0, 3)])
  return { word, options }
}

export default function FirstLetter() {
  const words = useWords()
  const [round, setRound] = useState<Round | null>(null)
  const [picked, setPicked] = useState<string | null>(null)
  const [score, setScore] = useState(0)

  useEffect(() => {
    setRound(makeRound(words))
  }, [words])

  const next = () => {
    setPicked(null)
    setRound(makeRound(words))
  }

  const pick = (c: string) => {
    if (picked || !round) return
    setPicked(c)
    if (c === round.word.text.charAt(0)) {
      setScore((s) => s + 1)
      speak(`Đúng rồi! Chữ ${c}, từ ${round.word.text}!`)
      setTimeout(next, 1500)
    } else {
      speak('Chưa đúng, bé thử lại nhé!')
    }
  }

  if (!round) return <div className="wrap"><div className="loading">Đang chuẩn bị…</div></div>

  const rest = round.word.text.slice(1)

  return (
    <div className="wrap">
      <div className="game-stage">
        <GameBack title="🔤 Đố chữ cái đầu" />
        <p style={{ color: '#62708a' }}>Từ còn thiếu chữ cái đầu tiên. Bé đoán xem là chữ gì?</p>
        <div className="score-bar">
          <div className="score-pill">⭐ Điểm: {score}</div>
        </div>
        <div className="flash-card" style={{ minHeight: 220, cursor: 'default' }}>
          <div className="big" style={{ fontSize: 84 }}>{round.word.emoji}</div>
          <div className="word" style={{ letterSpacing: 6 }}>
            <span style={{ color: '#c44e7c' }}>{picked ? round.word.text.charAt(0) : '_'}</span>
            {rest}
          </div>
        </div>
        <div className="pick-grid">
          {round.options.map((c) => (
            <button
              key={c}
              className={`pick-card${picked === c ? (c === round.word.text.charAt(0) ? ' correct' : ' wrong') : ''}`}
              style={{ fontSize: 34, padding: '20px 12px' }}
              onClick={() => pick(c)}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="game-msg">
          {picked && (picked === round.word.text.charAt(0) ? '🎉 Đúng rồi, giỏi quá!' : '💪 Sai rồi, thử chữ khác nhé!')}
        </div>
        <button className="btn-soft" onClick={() => { setScore(0); next() }}>
          <RotateCcw size={15} /> Chơi lại từ đầu
        </button>
      </div>
    </div>
  )
}
