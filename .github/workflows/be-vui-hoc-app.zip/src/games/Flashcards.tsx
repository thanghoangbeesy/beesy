import { useEffect, useMemo, useState } from 'react'
// icons: emoji 3D
import { GameBack, shuffle, speak, useWords, warmUpVoice } from './shared'

export default function Flashcards() {
  const words = useWords()
  const [order, setOrder] = useState<number[]>([])
  const [idx, setIdx] = useState(0)
  const [flipped, setFlipped] = useState(false)

  useEffect(() => { warmUpVoice() }, [])

  const deck = useMemo(() => {
    if (order.length === 0 && words.length > 0) {
      const o = shuffle(words.map((_, i) => i))
      setOrder(o)
      return o.map((i) => words[i])
    }
    return order.map((i) => words[i]).filter(Boolean)
  }, [order, words])

  const card = deck[idx]
  const go = (d: number) => {
    setFlipped(false)
    setIdx((i) => (i + d + deck.length) % deck.length)
  }

  if (!card) return <div className="wrap"><div className="loading">Đang chuẩn bị thẻ…</div></div>

  return (
    <div className="wrap">
      <div className="game-stage">
        <GameBack title="🃏 Thẻ từ vựng" />
        <p style={{ color: '#62708a' }}>Chạm vào thẻ để lật xem từ, rồi đọc to lên nhé!</p>
        <div className="score-bar">
          <div className="score-pill">Thẻ {idx + 1} / {deck.length}</div>
        </div>
        <div className="flash-card" onClick={() => setFlipped((f) => !f)}>
          {flipped ? (
            <>
              <div className="word">{card.text}</div>
              <div className="big" style={{ fontSize: 64 }}>{card.emoji}</div>
            </>
          ) : (
            <>
              <div className="big">{card.emoji}</div>
              <div className="tap-hint">Chạm để xem từ 👆</div>
            </>
          )}
        </div>
        <div className="row-center">
          <button className="btn-soft" onClick={() => go(-1)}>◀️</button>
          <button className="btn-soft" onClick={() => speak(card.text)}><span class="e3d">🔊</span> Nghe đọc</button>
          <button className="btn-soft" onClick={() => go(1)}>▶️</button>
          <button className="btn-soft" onClick={() => { setOrder(shuffle(words.map((_, i) => i))); setIdx(0); setFlipped(false) }}>
            <span class="e3d">🔀</span> Xáo thẻ
          </button>
        </div>
      </div>
    </div>
  )
}
