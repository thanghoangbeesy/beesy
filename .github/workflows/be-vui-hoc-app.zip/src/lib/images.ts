import { deleteObject, getDownloadURL, ref, uploadBytes } from 'firebase/storage'
import { storage } from '../firebase'

/** Nén ảnh về JPEG, cạnh dài nhất tối đa `maxEdge` px để nhẹ băng thông. */
export async function compressImage(file: File, maxEdge = 1280, quality = 0.82): Promise<Blob> {
  const bitmap = await createImageBitmap(file)
  try {
    const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height))
    const w = Math.max(1, Math.round(bitmap.width * scale))
    const h = Math.max(1, Math.round(bitmap.height * scale))
    const canvas = document.createElement('canvas')
    canvas.width = w
    canvas.height = h
    const ctx = canvas.getContext('2d')
    if (!ctx) throw new Error('no 2d context')
    ctx.drawImage(bitmap, 0, 0, w, h)
    return await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob(
        (b) => (b ? resolve(b) : reject(new Error('compress failed'))),
        'image/jpeg',
        quality,
      )
    })
  } finally {
    bitmap.close()
  }
}

/** Nén logo về tối đa 256px, trả về data URL (base64) để lưu thẳng vào Firestore — không cần Storage. */
export async function compressLogoToDataUrl(file: File, maxEdge = 256): Promise<string> {
  const bitmap = await createImageBitmap(file)
  try {
    const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height))
    const w = Math.max(1, Math.round(bitmap.width * scale))
    const h = Math.max(1, Math.round(bitmap.height * scale))
    const canvas = document.createElement('canvas')
    canvas.width = w
    canvas.height = h
    const ctx = canvas.getContext('2d')
    if (!ctx) throw new Error('no 2d context')
    ctx.drawImage(bitmap, 0, 0, w, h)
    const isPng = file.type === 'image/png'
    return canvas.toDataURL(isPng ? 'image/png' : 'image/jpeg', 0.85)
  } finally {
    bitmap.close()
  }
}

/** Nén rồi tải 1 ảnh lên Storage, trả về download URL. */
export async function uploadLessonImage(file: File, lessonId: string): Promise<string> {
  const blob = await compressImage(file)
  const name = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.jpg`
  const r = ref(storage, `lessons/${lessonId}/${name}`)
  await uploadBytes(r, blob, { contentType: 'image/jpeg' })
  return getDownloadURL(r)
}

/** Xóa ảnh khỏi Storage bằng download URL (bỏ qua lỗi). */
export async function deleteImageByUrl(url: string): Promise<void> {
  try {
    const m = url.match(/\/o\/([^?]+)/)
    if (!m) return
    await deleteObject(ref(storage, decodeURIComponent(m[1])))
  } catch {
    /* bỏ qua */
  }
}
