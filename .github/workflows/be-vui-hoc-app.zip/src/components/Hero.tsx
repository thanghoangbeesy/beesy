import { Link } from 'react-router-dom'
import { useBrand } from './Header'

export default function Hero() {
  const brand = useBrand()
  const parts = brand.heroSubtitle
    .split('•')
    .map((p) => p.trim())
    .filter(Boolean)
  return (
    <section className="hero">
      <div className="blob b1" />
      <div className="blob b2" />
      <div className="blob b3" />
      <div className="blob b4" />
      <span className="star" style={{ top: 70, left: '12%' }}>
        ✦
      </span>
      <span className="star" style={{ top: 120, right: '14%', color: '#f0a500' }}>
        ✦
      </span>
      <span className="star" style={{ bottom: 70, left: '22%', color: '#ff6b8a', fontSize: 22 }}>
        ✦
      </span>
      <span className="hero-badge">🌟 {brand.heroTitle}</span>
      <h1>
        Bé <span className="hl">vui học</span>
        <br />
        <span className="hl2">mỗi ngày!</span>
      </h1>
      <p className="tagline">
        Cùng bé{' '}
        {parts.map((p, i) => (
          <span key={i}>
            <b>{p}</b>
            {i < parts.length - 1 && ' • '}
          </span>
        ))}{' '}
        qua bài học và trò chơi sinh động — ba mẹ đồng hành cùng con ở nhà thật dễ dàng.
      </p>
      <div className="cta-row">
        <a className="btn-primary" href="#lop-hoc">
          Vào lớp học →
        </a>
        <Link className="btn-soft" to="/tro-choi">
          🎮 Chơi game
        </Link>
      </div>
    </section>
  )
}
