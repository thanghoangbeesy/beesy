import { Heart, Star, Send } from 'lucide-react'
import { useBrand } from './Header'

export default function Hero() {
  const brand = useBrand()
  return (
    <section className="hero">
      <div className="deco sun" />
      <div className="deco cloud c1" />
      <div className="deco cloud c2" />
      <div className="deco grass g1" />
      <div className="deco grass g2" />
      <Send className="deco plane" size={30} />
      <Heart className="deco heart-d" size={26} />
      <Star className="deco star-d" size={24} />
      <div className="hello">Chào mừng bé đến với</div>
      <h1>{brand.name}!</h1>
      <div className="tagline">
        {brand.heroSubtitle.split('•').map((p, i, arr) => (
          <span key={i}>
            {p.trim()} {i < arr.length - 1 && <b> • </b>}
          </span>
        ))}
      </div>
    </section>
  )
}
