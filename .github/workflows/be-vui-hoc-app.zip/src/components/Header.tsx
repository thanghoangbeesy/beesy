import { useEffect, useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Home, Gamepad2, BookOpen } from 'lucide-react'
import { doc, getDoc } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { BrandDoc } from '../types'

const DEFAULT_BRAND: BrandDoc = {
  name: 'Bé Vui Học',
  slogan: 'Học mà chơi – Chơi mà học',
  heroTitle: 'Lớp tiền tiểu học',
  heroSubtitle: 'Tập đọc • Tập viết • Phát âm • Đọc từ',
  logo: '🌈',
}

export function useBrand() {
  const [brand, setBrand] = useState<BrandDoc>(DEFAULT_BRAND)
  useEffect(() => {
    if (!isConfigured) return
    getDoc(doc(db, 'settings', 'brand')).then((s) => {
      if (s.exists()) setBrand({ ...DEFAULT_BRAND, ...(s.data() as Partial<BrandDoc>) })
    }).catch(() => {})
  }, [])
  return brand
}

export default function Header() {
  const brand = useBrand()
  return (
    <header className="header">
      <div className="header-inner">
        <Link to="/" className="brand">
          {brand.logoUrl ? (
            <img className="brand-logo-img" src={brand.logoUrl} alt={brand.name} />
          ) : (
            <div className="brand-emoji">{brand.logo || '🌈'}</div>
          )}
          <div>
            <div className="brand-name">{brand.name}</div>
            <div className="brand-slogan">{brand.slogan}</div>
          </div>
        </Link>
        <nav className="nav">
          <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
            <Home size={18} /><span className="label">Trang chủ</span>
          </NavLink>
          <NavLink to="/tro-choi" className={({ isActive }) => (isActive ? 'active' : '')}>
            <Gamepad2 size={18} /><span className="label">Trò chơi</span>
          </NavLink>
          <NavLink to="/tai-lieu" className={({ isActive }) => (isActive ? 'active' : '')}>
            <BookOpen size={18} /><span className="label">Tài liệu</span>
          </NavLink>
        </nav>
      </div>
    </header>
  )
}
