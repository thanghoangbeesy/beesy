import { useEffect, useState } from 'react'
import { collection, deleteDoc, doc, getDoc, getDocs, orderBy, query, setDoc } from 'firebase/firestore'
import { db } from '../../firebase'
import { AlbumDoc, AlbumPhoto, MediaSettings } from '../../types'

const todayStr = () => new Date().toISOString().slice(0, 10)

export default function AlbumsTab({ onMsg }: { onMsg: (m: string) => void }) {
  // --- Cấu hình Cloudinary (settings/media) ---
  const [media, setMedia] = useState<MediaSettings>({ cloudName: '', uploadPreset: '' })
  const [mediaOk, setMediaOk] = useState(false)

  // --- Danh sách album ---
  const [albums, setAlbums] = useState<AlbumDoc[]>([])

  // --- Form album ---
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingCreatedAt, setEditingCreatedAt] = useState(0)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [date, setDate] = useState(todayStr())
  const [photos, setPhotos] = useState<AlbumPhoto[]>([])
  const [coverUrl, setCoverUrl] = useState('')
  const [uploading, setUploading] = useState('')

  const loadAlbums = () => {
    getDocs(query(collection(db, 'albums'), orderBy('createdAt', 'desc')))
      .then((s) => setAlbums(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<AlbumDoc, 'id'>) }))))
      .catch(() => {})
  }

  useEffect(() => {
    getDoc(doc(db, 'settings', 'media'))
      .then((s) => {
        if (s.exists()) {
          const d = s.data() as Partial<MediaSettings>
          setMedia({ cloudName: d.cloudName || '', uploadPreset: d.uploadPreset || '' })
          setMediaOk(!!(d.cloudName && d.uploadPreset))
        }
      })
      .catch(() => {})
    loadAlbums()
  }, [])

  const saveMedia = async () => {
    if (!media.cloudName.trim() || !media.uploadPreset.trim()) {
      onMsg('Anh nhập đủ Cloud name và Upload preset đã nhé.')
      return
    }
    await setDoc(doc(db, 'settings', 'media'), {
      cloudName: media.cloudName.trim(),
      uploadPreset: media.uploadPreset.trim(),
    })
    setMediaOk(true)
    onMsg('Đã lưu cấu hình Cloudinary! ✅ Giờ tải ảnh lên thoải mái nhé.')
  }

  const onFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    if (files.length === 0) return
    if (!mediaOk) {
      onMsg('Anh nhập Cloud name + Upload preset ở trên rồi bấm "Lưu cấu hình" trước nhé.')
      e.target.value = ''
      return
    }
    try {
      const { uploadImageToCloudinary } = await import('../../lib/cloudinary')
      const added: AlbumPhoto[] = []
      for (let i = 0; i < files.length; i++) {
        setUploading(`Đang tải ${i + 1}/${files.length}...`)
        const url = await uploadImageToCloudinary(files[i])
        added.push({ url })
      }
      setPhotos((p) => [...p, ...added])
      setCoverUrl((cur) => cur || added[0]?.url || '')
      onMsg(`Đã tải xong ${added.length} ảnh! ✅`)
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : ''
      onMsg(msg === 'MEDIA_NOT_CONFIGURED' ? 'Chưa cấu hình Cloudinary. Anh làm bước 1 ở trên nhé.' : msg || 'Tải ảnh thất bại, thử lại nhé.')
    } finally {
      setUploading('')
      e.target.value = ''
    }
  }

  const resetForm = () => {
    setEditingId(null)
    setEditingCreatedAt(0)
    setTitle('')
    setDescription('')
    setDate(todayStr())
    setPhotos([])
    setCoverUrl('')
  }

  const startEdit = (a: AlbumDoc) => {
    setEditingId(a.id)
    setEditingCreatedAt(a.createdAt || 0)
    setTitle(a.title || '')
    setDescription(a.description || '')
    setDate(a.date || todayStr())
    setPhotos(a.photos || [])
    setCoverUrl(a.coverUrl || a.photos?.[0]?.url || '')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const saveAlbum = async () => {
    if (!title.trim()) {
      onMsg('Nhập tiêu đề album đã anh nhé.')
      return
    }
    if (photos.length === 0) {
      onMsg('Album chưa có ảnh nào. Anh tải ít nhất 1 ảnh lên nhé.')
      return
    }
    const data = {
      title: title.trim(),
      description: description.trim(),
      date: date || todayStr(),
      coverUrl: coverUrl || photos[0].url,
      photos,
      createdAt: editingId ? editingCreatedAt || Date.now() : Date.now(),
    }
    if (editingId) {
      await setDoc(doc(db, 'albums', editingId), data, { merge: true })
      onMsg('Đã cập nhật album! ✅')
    } else {
      await setDoc(doc(collection(db, 'albums')), data)
      onMsg('Đã tạo album mới! ✅')
    }
    resetForm()
    loadAlbums()
  }

  const delAlbum = async (a: AlbumDoc) => {
    if (!confirm(`Xóa album "${a.title}"? (Ảnh trên Cloudinary vẫn còn, chỉ xóa album khỏi web)`)) return
    await deleteDoc(doc(db, 'albums', a.id))
    onMsg('Đã xóa album.')
    loadAlbums()
  }

  return (
    <>
      <div className="admin-box">
        <h2>☁️ Cấu hình Cloudinary (tải ảnh miễn phí)</h2>
        {!mediaOk && (
          <div className="notice">
            Chưa cấu hình nên chưa tải ảnh lên được. Anh làm 4 bước (miễn phí):
            <br />1. Vào <b>cloudinary.com</b> tạo tài khoản miễn phí.
            <br />2. Bấm ⚙️ <b>Settings</b> → tab <b>Upload</b> → kéo xuống <b>Upload presets</b> → <b>Add upload preset</b>.
            <br />3. Đặt tên preset tùy ý, chọn <b>Signing Mode = Unsigned</b> → Save.
            <br />4. Copy <b>Cloud name</b> (ở trang Dashboard) và tên preset vừa tạo, dán vào 2 ô dưới rồi bấm Lưu.
          </div>
        )}
        <div className="form-inline" style={{ marginTop: 0 }}>
          <input
            placeholder="Cloud name (VD: abcxyz123)"
            value={media.cloudName}
            onChange={(e) => setMedia({ ...media, cloudName: e.target.value })}
          />
          <input
            placeholder="Upload preset (VD: bevuichoc)"
            value={media.uploadPreset}
            onChange={(e) => setMedia({ ...media, uploadPreset: e.target.value })}
          />
        </div>
        <div style={{ marginTop: 12 }}>
          <button className="btn-primary" onClick={saveMedia}>Lưu cấu hình</button>
          {mediaOk && <span style={{ marginLeft: 12, color: '#16a34a', fontWeight: 800 }}>✅ Đã cấu hình xong</span>}
        </div>
      </div>

      <div className="admin-box">
        <h2>{editingId ? '✏️ Sửa album' : '➕ Album mới'}</h2>
        <div className="field"><label>Tiêu đề album *</label><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="VD: Bé vui Trung thu 2026" /></div>
        <div className="field"><label>Mô tả</label><input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="VD: Các bé rước đèn, phá cỗ cùng cô" /></div>
        <div className="field"><label>Ngày</label><input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></div>
        <div className="field">
          <label>📷 Ảnh trong album ({photos.length})</label>
          <input type="file" accept="image/*" multiple onChange={onFiles} disabled={!!uploading} />
          {uploading && <div className="notice" style={{ marginTop: 10 }}>⏳ {uploading}</div>}
          {photos.length > 0 && (
            <div className="thumb-row">
              {photos.map((p, i) => (
                <div key={i} style={{ width: 150 }}>
                  <div className="thumb" style={{ width: 150, height: 150 }}>
                    <img src={p.url} alt="" />
                    <button type="button" onClick={() => {
                      const np = photos.filter((_, j) => j !== i)
                      setPhotos(np)
                      if (coverUrl === p.url) setCoverUrl(np[0]?.url || '')
                    }}>✕</button>
                  </div>
                  {coverUrl === p.url && (
                    <div style={{ fontSize: 12, fontWeight: 800, color: '#e14d6f', marginTop: 4 }}>⭐ Ảnh bìa</div>
                  )}
                  <input
                    placeholder="Chú thích ảnh…"
                    value={p.caption || ''}
                    onChange={(e) => {
                      const np = [...photos]
                      np[i] = { ...np[i], caption: e.target.value }
                      setPhotos(np)
                    }}
                    style={{ width: '100%', marginTop: 6, padding: '8px 10px', borderRadius: 10, border: '1.5px solid #ead9bd', fontSize: 13 }}
                  />
                  {coverUrl !== p.url && (
                    <button type="button" className="btn-small" style={{ marginTop: 6 }} onClick={() => setCoverUrl(p.url)}>
                      Đặt làm bìa
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="form-inline">
          <button className="btn-primary" onClick={saveAlbum}>{editingId ? 'Lưu thay đổi' : 'Tạo album'}</button>
          {editingId && <button className="btn-soft" onClick={resetForm}>Hủy</button>}
        </div>
      </div>

      <div className="admin-box">
        <h2>🖼️ Danh sách album ({albums.length})</h2>
        {albums.length === 0 ? (
          <div className="empty">Chưa có album nào.</div>
        ) : (
          albums.map((a) => (
            <div className="admin-row" key={a.id}>
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                {a.coverUrl && <img src={a.coverUrl} alt="" style={{ width: 56, height: 56, objectFit: 'cover', borderRadius: 12 }} />}
                <div>
                  <div style={{ fontWeight: 800 }}>{a.title}</div>
                  <div style={{ fontSize: 13, color: '#5d7590' }}>📷 {a.photos?.length || 0} ảnh · 📅 {a.date}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn-small" onClick={() => startEdit(a)}>Sửa</button>
                <button className="btn-danger" onClick={() => delAlbum(a)}>Xóa</button>
              </div>
            </div>
          ))
        )}
      </div>
    </>
  )
}
