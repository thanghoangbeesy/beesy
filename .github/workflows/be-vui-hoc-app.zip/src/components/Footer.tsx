import { useBrand } from './Header'

export default function Footer() {
  const brand = useBrand()
  return <footer className="footer">{brand.slogan} 💛</footer>
}
