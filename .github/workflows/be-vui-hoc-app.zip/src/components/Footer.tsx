import { useBrand } from './Header'

function zaloUrl(zalo: string): string {
  const z = zalo.trim()
  if (/^https?:\/\//i.test(z)) return z
  return `https://zalo.me/${z.replace(/\D/g, '')}`
}

export default function Footer() {
  const brand = useBrand()
  return (
    <footer className="footer">
      <div className="foot-inner">
        <h3>
          {brand.name} 💛
        </h3>
        {(brand.phone || brand.address) && (
          <div className="foot-contact">
            {brand.phone && <span>📞 {brand.phone}</span>}
            {brand.phone && brand.address && <span> &nbsp;·&nbsp; </span>}
            {brand.address && <span>📍 {brand.address}</span>}
          </div>
        )}
        {brand.zalo && (
          <a href={zaloUrl(brand.zalo)} target="_blank" rel="noreferrer" className="zalo-btn">
            💬 Chat Zalo với cô
          </a>
        )}
        <div className="foot-note">{brand.slogan} 🌈</div>
      </div>
    </footer>
  )
}
