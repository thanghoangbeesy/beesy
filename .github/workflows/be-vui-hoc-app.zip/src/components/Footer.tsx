import { useBrand } from './Header'

export default function Footer() {
  const brand = useBrand()
  return (
    <footer className="footer">
      <div>{brand.slogan} 💛</div>
      {(brand.phone || brand.address) && (
        <div style={{ marginTop: 6, fontSize: 14 }}>
          {brand.phone && <span>📞 {brand.phone}</span>}
          {brand.phone && brand.address && <span> · </span>}
          {brand.address && <span>📍 {brand.address}</span>}
        </div>
      )}
    </footer>
  )
}
