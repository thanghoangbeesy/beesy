import { useBrand } from './Header'

function zaloUrl(zalo: string): string {
  const z = zalo.trim()
  if (/^https?:\/\//i.test(z)) return z
  return `https://zalo.me/${z.replace(/\D/g, '')}`
}

export default function Footer() {
  const brand = useBrand()
  return (
    <footer className="footer">
      <div>{brand.slogan} 💛</div>
      {(brand.phone || brand.address) && (
        <div style={{ marginTop: 6, fontSize: 14 }}>
          {brand.phone && <span>📞 {brand.phone}</span>}
          {brand.phone && brand.address && <span> · </span>}
          {brand.address && <span>📍 {brand.address}</span>}
        </div>
      )}
      {brand.zalo && (
        <div style={{ marginTop: 10 }}>
          <a href={zaloUrl(brand.zalo)} target="_blank" rel="noreferrer" className="zalo-btn">
            💬 Chat Zalo với cô
          </a>
        </div>
      )}
    </footer>
  )
}
