import { Link } from 'react-router-dom'
import { Users, CalendarDays } from 'lucide-react'
import { ClassDoc } from '../types'

export default function ClassCard({ cls, studentCount }: { cls: ClassDoc; studentCount: number }) {
  return (
    <div className="class-card">
      <div className="class-art" style={{ background: cls.bg }}>
        {cls.imageUrl ? (
          <img className="mascot-img" src={cls.imageUrl} alt={cls.name} />
        ) : (
          <div className="mascot">{cls.mascot}</div>
        )}
        <h3 className="class-name">{cls.name}</h3>
        <span className="level-tag">{cls.level}</span>
      </div>
      <div className="class-body">
        {cls.schedule.length > 0 && (
          <div className="class-meta">
            <CalendarDays size={15} /> {cls.schedule.join(' · ')}
          </div>
        )}
        <div className="class-meta">
          <Users size={15} /> {studentCount} bé đang học
        </div>
        <Link to={`/lop/${cls.id}`} className="link-go" style={{ color: cls.accent }}>
          Vào lớp →
        </Link>
      </div>
    </div>
  )
}
