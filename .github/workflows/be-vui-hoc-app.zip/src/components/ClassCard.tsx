import { Link } from 'react-router-dom'
import { Users, CalendarDays } from 'lucide-react'
import { ClassDoc } from '../types'

export default function ClassCard({ cls, studentCount }: { cls: ClassDoc; studentCount: number }) {
  return (
    <div className="class-card" style={{ background: cls.bg }}>
      <div className="class-top">
        {cls.imageUrl ? (
          <img className="mascot-img" src={cls.imageUrl} alt={cls.name} />
        ) : (
          <div className="mascot">{cls.mascot}</div>
        )}
        <div>
          <h3 className="class-name">{cls.name}</h3>
          <span className="level-tag" style={{ background: cls.bg, color: cls.accent, border: `1.5px solid ${cls.accent}55` }}>
            {cls.level}
          </span>
          <div className="class-meta">
            <Users size={15} /> {studentCount} bé
          </div>
          {cls.schedule.length > 0 && (
            <div className="class-meta">
              <CalendarDays size={15} /> {cls.schedule.join(' · ')}
            </div>
          )}
        </div>
      </div>
      <Link to={`/lop/${cls.id}`}>
        <button className="btn-view" style={{ background: cls.accent }}>
          Xem lớp học
        </button>
      </Link>
    </div>
  )
}
