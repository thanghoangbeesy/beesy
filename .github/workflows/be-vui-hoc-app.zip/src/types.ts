export interface ClassDoc {
  id: string
  name: string
  level: string
  mascot: string
  accent: string
  bg: string
  schedule: string[]
  imageUrl?: string
  order: number
}

export interface StudentDoc {
  id: string
  classId: string
  name: string
  dob?: string
  parentName?: string
  parentPhone?: string
}

export interface LessonDoc {
  id: string
  classId: string
  title: string
  date: string
  category: string
  content: string
  link?: string
  images?: string[]
}

export interface WordDoc {
  id: string
  text: string
  emoji: string
}

export interface ResourceDoc {
  id: string
  title: string
  category: string
  description: string
  url: string
  published: boolean
}

export interface BrandDoc {
  name: string
  slogan: string
  heroTitle: string
  heroSubtitle: string
  phone?: string
  address?: string
  zalo?: string
}

export interface AnnouncementDoc {
  id: string
  title: string
  content: string
  date: string
  pinned?: boolean
}

export interface TrialRequestDoc {
  id: string
  childName: string
  parentName?: string
  phone: string
  classId?: string
  note?: string
  createdAt: string
  done?: boolean
}

export interface SpotlightDoc {
  name: string
  note: string
  enabled: boolean
}

export const LESSON_CATEGORIES = ['Tập đọc', 'Tập viết', 'Phát âm', 'Đọc từ', 'Bài tập']
export const RESOURCE_CATEGORIES = ['Phiếu bài tập', 'Video', 'Trò chơi in', 'Tài liệu khác']
