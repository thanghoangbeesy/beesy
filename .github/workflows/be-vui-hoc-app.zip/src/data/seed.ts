import { collection, doc, setDoc, writeBatch } from 'firebase/firestore'
import { db } from '../firebase'

const CLASSES = [
  { id: 'cao-con', name: 'Lớp Cáo Con', level: 'Tập đọc sớm', mascot: '🦊', accent: '#ae3d49', bg: '#fff0e9', schedule: ['Thứ 3 17:30–19:00', 'Thứ 7 07:30–09:00'], order: 1 },
  { id: 'ong-vang', name: 'Lớp Ong Vàng', level: 'Tập viết', mascot: '🐝', accent: '#7a540b', bg: '#fff8df', schedule: ['Thứ 4 17:45–19:15', 'Thứ 7 09:30–11:00'], order: 2 },
  { id: 'khung-long', name: 'Lớp Khủng Long', level: 'Phát âm', mascot: '🦕', accent: '#237253', bg: '#eaf8ef', schedule: ['Thứ 2 17:45–19:15', 'Thứ 6 17:45–19:15'], order: 3 },
  { id: 'canh-cut', name: 'Lớp Cánh Cụt', level: 'Đọc từ', mascot: '🐧', accent: '#63569d', bg: '#f2effc', schedule: ['Thứ 5 17:30–19:00', 'Chủ nhật 17:30–19:00'], order: 4 },
]

const STUDENTS: Record<string, string[]> = {
  'cao-con': ['Bé An', 'Bé Bình', 'Bé Chi', 'Bé Dũng', 'Bé Hà', 'Bé Khánh'],
  'ong-vang': ['Bé Linh', 'Bé Minh', 'Bé Ngọc', 'Bé Phúc', 'Bé Quân'],
  'khung-long': ['Bé Sơn', 'Bé Tâm', 'Bé Uyên', 'Bé Vy', 'Bé Xuân', 'Bé Yến', 'Bé Bảo'],
  'canh-cut': ['Bé Đạt', 'Bé Hân', 'Bé Kiệt', 'Bé Lam'],
}

const LESSONS = [
  { classId: 'cao-con', title: 'Bài 1 – Làm quen chữ a, ă, â', date: '2026-10-12', category: 'Tập đọc', content: 'Hôm nay bé học 3 chữ cái đầu tiên: a – ă – â.\n\n1. Nhìn chữ, đọc to: a! ă! â!\n2. Tìm chữ a trong các từ: ba, má, cá.\n3. Bài tập về nhà: đọc lại 3 chữ 5 lần cho ba mẹ nghe nhé!' },
  { classId: 'cao-con', title: 'Bài 2 – Đánh vần ba, bà, bá', date: '2026-10-14', category: 'Tập đọc', content: 'Bé tập đánh vần với dấu thanh:\n\n- ba (không dấu)\n- bà (dấu huyền)\n- bá (dấu sắc)\n\nMẹo: đọc dấu huyền giọng trầm xuống, dấu sắc giọng vút lên!' },
  { classId: 'ong-vang', title: 'Bài 1 – Nét thẳng, nét cong', date: '2026-10-12', category: 'Tập viết', content: 'Bé tập viết các nét cơ bản:\n\n1. Nét thẳng đứng: | | |\n2. Nét cong: ( ( (\n3. Tô theo dòng kẻ, viết chậm và đều tay.\n\nBài tập về nhà: viết mỗi nét 1 dòng vào vở.' },
  { classId: 'khung-long', title: 'Bài 1 – Phát âm b, c, d', date: '2026-10-12', category: 'Phát âm', content: 'Bé nghe và đọc theo:\n\n- b: "bờ" – như từ "ba"\n- c: "cờ" – như từ "cá"\n- d: "dờ" – như từ "đi"\n\nMở game "Nghe và chọn" để luyện thêm nhé!' },
  { classId: 'canh-cut', title: 'Bài 1 – Từ về gia đình', date: '2026-10-12', category: 'Đọc từ', content: 'Bé đọc các từ về gia đình:\n\nba – mẹ – bà – ông – bé\n\nMở "Thẻ từ" trong mục Trò chơi để ôn lại nhé!' },
]

const WORDS = [
  { text: 'ba', emoji: '👨' }, { text: 'mẹ', emoji: '👩' }, { text: 'bà', emoji: '👵' },
  { text: 'ông', emoji: '👴' }, { text: 'bé', emoji: '👶' }, { text: 'cô', emoji: '👩‍🏫' },
  { text: 'cá', emoji: '🐟' }, { text: 'gà', emoji: '🐔' }, { text: 'chó', emoji: '🐶' },
  { text: 'mèo', emoji: '🐱' }, { text: 'chim', emoji: '🐦' }, { text: 'thỏ', emoji: '🐰' },
  { text: 'gấu', emoji: '🐻' }, { text: 'hoa', emoji: '🌸' }, { text: 'lá', emoji: '🍃' },
  { text: 'nhà', emoji: '🏠' }, { text: 'xe', emoji: '🚗' }, { text: 'bóng', emoji: '⚽' },
  { text: 'sách', emoji: '📖' }, { text: 'bút', emoji: '✏️' }, { text: 'bàn', emoji: '🪑' },
  { text: 'cam', emoji: '🍊' }, { text: 'táo', emoji: '🍎' }, { text: 'chuối', emoji: '🍌' },
]

const RESOURCES = [
  { title: 'Phiếu tập viết chữ a, ă, â', category: 'Phiếu bài tập', description: 'Phiếu PDF cho bé tô và tập viết 3 chữ cái đầu tiên.', url: '', published: true },
  { title: 'Video: bài hát chữ cái tiếng Việt', category: 'Video', description: 'Video ca nhạc giúp bé nhớ chữ cái thật vui.', url: '', published: true },
]

export async function seedDatabase(): Promise<void> {
  const batch = writeBatch(db)
  batch.set(doc(db, 'settings', 'brand'), {
    name: 'Bé Vui Học',
    slogan: 'Học mà chơi – Chơi mà học',
    heroTitle: 'Lớp tiền tiểu học',
    heroSubtitle: 'Tập đọc • Tập viết • Phát âm • Đọc từ',
    logo: '🌈',
  })
  for (const c of CLASSES) batch.set(doc(db, 'classes', c.id), c)
  for (const [classId, names] of Object.entries(STUDENTS)) {
    names.forEach((name, i) => {
      batch.set(doc(collection(db, 'students')), { classId, name, order: i })
    })
  }
  LESSONS.forEach((l) => batch.set(doc(collection(db, 'lessons')), l))
  WORDS.forEach((w, i) => batch.set(doc(collection(db, 'words')), { ...w, order: i }))
  RESOURCES.forEach((r) => batch.set(doc(collection(db, 'resources')), r))
  await batch.commit()
}
