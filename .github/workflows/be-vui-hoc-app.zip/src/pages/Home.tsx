import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { addDoc, collection, doc, getDoc, getDocs, orderBy, query } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { AnnouncementDoc, ClassDoc, SpotlightDoc, StudentDoc } from '../types'
import Hero from '../components/Hero'
import ClassCard from '../components/ClassCard'

export default function Home() {
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [counts, setCounts] = useState<Record<string, number>>({})
  const [news, setNews] = useState<AnnouncementDoc[]>([])
  const [spot, setSpot] = useState<SpotlightDoc | null>(null)

  const [childName, setChildName] = useState('')
  const [parentName, setParentName] = useState('')
  const [phone, setPhone] = useState('')
  const [trialClass, setTrialClass] = useState('')
  const [note, setNote] = useState('')
  const [sending, setSending] = useState(false)
  const [sent, setSent] = useState(false)
  const [formErr, setFormErr] = useState('')

  useEffect(() => {
    if (!isConfigured) return
    ;(async () => {
      const cs = await getDocs(query(collection(db, 'classes'), orderBy('order')))
      const cls = cs.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) }))
      setClasses(cls)
      if (cls[0]) setTrialClass(cls[0].id)
      const ss = await getDocs(collection(db, 'students'))
      const c: Record<string, number> = {}
      ss.docs.forEach((d) => {
        const s = d.data() as StudentDoc
        c[s.classId] = (c[s.classId] || 0) + 1
      })
      setCounts(c)
      const ns = await getDocs(collection(db, 'announcements'))
      setNews(
        ns.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<AnnouncementDoc, 'id'>) }))
          .sort(
            (a, b) =>
              Number(b.pinned || false) - Number(a.pinned || false) ||
              b.date.localeCompare(a.date),
          )
          .slice(0, 3),
      )
      const sp = await getDoc(doc(db, 'settings', 'spotlight'))
      if (sp.exists()) setSpot(sp.data() as SpotlightDoc)
    })().catch(() => {})
  }, [])

  const submitTrial = async () => {
    setFormErr('')
    const digits = phone.replace(/\D/g, '')
    if (!childName.trim()) { setFormErr('Nhập tên bé giúp cô nhé.'); return }
    if (digits.length < 9) { setFormErr('Số điện thoại chưa đúng, kiểm tra lại giúp cô nhé.'); return }
    setSending(true)
    try {
      await addDoc(collection(db, 'trial_requests'), {
        childName: childName.trim(),
        parentName: parentName.trim(),
        phone: digits,
        classId: trialClass,
        note: note.trim(),
        createdAt: new Date().toISOString(),
        done: false,
      })
      setSent(true)
      setChildName(''); setParentName(''); setPhone(''); setNote('')
    } catch {
      setFormErr('Gửi chưa thành công, thử lại giúp cô nhé.')
    }
    setSending(false)
  }

  return (
    <>
      <Hero />
      <div className="wrap">
        {news.length > 0 && (
          <section className="section">
            <div className="section-head">
              <h2>📢 Thông báo</h2>
            </div>
            {news.map((a) => (
              <div className="announce-card" key={a.id}>
                <div className="announce-head">
                  <h3>{a.pinned ? '📌 ' : ''}{a.title}</h3>
                  <span className="lesson-date">{a.date}</span>
                </div>
                {a.content && <p style={{ whiteSpace: 'pre-line', margin: '8px 0 0' }}>{a.content}</p>}
              </div>
            ))}
          </section>
        )}

        {spot && spot.enabled && spot.name && (
          <div className="spotlight-banner">
            <div className="spotlight-trophy">🏆</div>
            <div>
              <div className="eyebrow" style={{ color: '#b45309' }}>BÉ NGOAN TUẦN NÀY</div>
              <h2 style={{ margin: '4px 0' }}>{spot.name}</h2>
              {spot.note && <p style={{ margin: 0, color: '#7c5a1e' }}>{spot.note}</p>}
            </div>
          </div>
        )}

        <section className="section" id="lop-hoc">
          <div className="section-head">
            <h2>Lớp học của bé</h2>
            <p>Chọn lớp để xem bài học và ôn bài ở nhà nhé!</p>
          </div>
          {!isConfigured ? (
            <div className="notice">Web chưa kết nối Firebase. Anh vào trang <b>/quan-tri</b> sau khi cấu hình để nạp dữ liệu mẫu nhé.</div>
          ) : classes.length === 0 ? (
            <div className="empty">Chưa có lớp học nào. Anh vào trang Quản trị để thêm nhé.</div>
          ) : (
            <div className="class-grid">
              {classes.map((c) => (
                <ClassCard key={c.id} cls={c} studentCount={counts[c.id] || 0} />
              ))}
            </div>
          )}
        </section>

        <div className="duo">
          <Link to="/tro-choi" className="duo-card">
            <div className="duo-icon" style={{ backgroundColor: '#e6f2ff' }}>
              🎮
            </div>
            <div>
              <h3>Trò chơi</h3>
              <p>Nghe và chọn, thẻ từ, đố chữ cái, tập viết – vừa học vừa chơi!</p>
              <span className="link-more">Chơi ngay →</span>
            </div>
          </Link>
          <Link to="/tai-lieu" className="duo-card">
            <div className="duo-icon" style={{ backgroundColor: '#f5e9f8' }}>
              📚
            </div>
            <div>
              <h3>Tài liệu</h3>
              <p>Phiếu bài tập, video và tài liệu cho bé ôn ở nhà.</p>
              <span className="link-more">Xem tài liệu →</span>
            </div>
          </Link>
        </div>

        <section className="section" id="dang-ky">
          <div className="section-head">
            <h2>📝 Đăng ký học thử</h2>
            <p>Để lại thông tin, cô sẽ gọi lại tư vấn cho bé nhé!</p>
          </div>
          <div className="admin-box trial-box">
            {sent ? (
              <div className="game-msg">🎉 Cảm ơn phụ huynh! Cô đã nhận thông tin và sẽ gọi lại sớm nhé.</div>
            ) : (
              <>
                <div className="form-inline" style={{ marginTop: 0 }}>
                  <input placeholder="Tên bé *" value={childName} onChange={(e) => setChildName(e.target.value)} />
                  <input placeholder="Số điện thoại phụ huynh *" value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" />
                </div>
                <div className="form-inline">
                  <input placeholder="Tên phụ huynh" value={parentName} onChange={(e) => setParentName(e.target.value)} />
                  <select value={trialClass} onChange={(e) => setTrialClass(e.target.value)} aria-label="Lớp quan tâm">
                    {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div className="field" style={{ marginTop: 10 }}>
                  <input placeholder="Ghi chú (không bắt buộc)" value={note} onChange={(e) => setNote(e.target.value)} />
                </div>
                {formErr && <div className="notice" style={{ background: '#fef2f2', borderColor: '#fecaca' }}>{formErr}</div>}
                <button className="btn-primary" disabled={sending} onClick={submitTrial}>
                  <span className="e3d">📨</span> {sending ? 'Đang gửi…' : 'Gửi đăng ký'}
                </button>
              </>
            )}
          </div>
        </section>
      </div>
    </>
  )
}
