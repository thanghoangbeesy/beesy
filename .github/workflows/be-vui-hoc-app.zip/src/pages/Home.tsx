import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { collection, getDocs, orderBy, query } from 'firebase/firestore'
import { Gamepad2, BookOpen } from 'lucide-react'
import { db, isConfigured } from '../firebase'
import { ClassDoc, StudentDoc } from '../types'
import Hero from '../components/Hero'
import ClassCard from '../components/ClassCard'

export default function Home() {
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [counts, setCounts] = useState<Record<string, number>>({})

  useEffect(() => {
    if (!isConfigured) return
    ;(async () => {
      const cs = await getDocs(query(collection(db, 'classes'), orderBy('order')))
      setClasses(cs.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) })))
      const ss = await getDocs(collection(db, 'students'))
      const c: Record<string, number> = {}
      ss.docs.forEach((d) => {
        const s = d.data() as StudentDoc
        c[s.classId] = (c[s.classId] || 0) + 1
      })
      setCounts(c)
    })().catch(() => {})
  }, [])

  return (
    <>
      <Hero />
      <div className="wrap">
        <section className="section" id="lop-hoc">
          <div className="section-head">
            <h2>Lớp học của bé</h2>
            <p>Chọn lớp để xem bài học và ôn bài ở nhà nhé!</p>
          </div>
          {!isConfigured ? (
            <div className="notice">Web chưa kết nối Firebase. Anh vào trang <b>/quan-tri</b> sau khi cấu hình để nạp dữ liệu mẫu nhé.</div>
          ) : classes.length === 0 ? (
            <div className="empty">Chưa có lớp học nào. Anh vào trang Quản trị để thêm nhé.</div>
          ) : (
            <div className="class-grid">
              {classes.map((c) => (
                <ClassCard key={c.id} cls={c} studentCount={counts[c.id] || 0} />
              ))}
            </div>
          )}
        </section>

        <div className="duo">
          <Link to="/tro-choi" className="duo-card">
            <div className="duo-icon" style={{ background: '#e6f2ff' }}>
              <Gamepad2 size={30} color="#2b6cb0" />
            </div>
            <div>
              <h3>Trò chơi</h3>
              <p>Nghe và chọn, thẻ từ, đố chữ cái, tập viết – vừa học vừa chơi!</p>
              <span className="link-more">Chơi ngay →</span>
            </div>
          </Link>
          <Link to="/tai-lieu" className="duo-card">
            <div className="duo-icon" style={{ background: '#f5e9f8' }}>
              <BookOpen size={30} color="#8b4fa8" />
            </div>
            <div>
              <h3>Tài liệu</h3>
              <p>Phiếu bài tập, video và tài liệu cho bé ôn ở nhà.</p>
              <span className="link-more">Xem tài liệu →</span>
            </div>
          </Link>
        </div>
      </div>
    </>
  )
}
