import { useEffect, useMemo, useState } from 'react'
import { collection, getDocs, query, where } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { ResourceDoc, RESOURCE_CATEGORIES } from '../types'

export default function Resources() {
  const [items, setItems] = useState<ResourceDoc[]>([])
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('Tất cả')

  useEffect(() => {
    if (!isConfigured) return
    getDocs(query(collection(db, 'resources'), where('published', '==', true)))
      .then((s) => setItems(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ResourceDoc, 'id'>) }))))
      .catch(() => {})
  }, [])

  const filtered = useMemo(
    () =>
      items.filter(
        (r) =>
          (cat === 'Tất cả' || r.category === cat) &&
          (r.title + r.description).toLowerCase().includes(q.toLowerCase()),
      ),
    [items, q, cat],
  )

  return (
    <div className="wrap">
      <section className="section">
        <div className="section-head">
          <h2>📚 Tài liệu</h2>
          <p>Phiếu bài tập và tài liệu cho bé ôn ở nhà.</p>
        </div>
        <div className="chips-row">
          {['Tất cả', ...RESOURCE_CATEGORIES].map((c) => (
            <button key={c} className={`chip${cat === c ? ' on' : ''}`} onClick={() => setCat(c)}>
              {c}
            </button>
          ))}
        </div>
        <input
          className="search"
          placeholder="Tìm tài liệu…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        {filtered.length === 0 ? (
          <div className="empty">Chưa có tài liệu nào. Bé quay lại sau nhé! 🌈</div>
        ) : (
          filtered.map((r) => (
            <div className="res-card" key={r.id}>
              <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
                <div className="duo-icon" style={{ backgroundColor: '#fff8df', width: 52, height: 52, fontSize: 28 }}>
                  📄
                </div>
                <div>
                  <h4>{r.title} <span className="lesson-cat">{r.category}</span></h4>
                  <p>{r.description}</p>
                </div>
              </div>
              {r.url && (
                <a href={r.url} target="_blank" rel="noreferrer">
                  <button className="btn-lesson"><span className="e3d">🔗</span> Mở</button>
                </a>
              )}
            </div>
          ))
        )}
        <div style={{ height: 50 }} />
      </section>
    </div>
  )
}
