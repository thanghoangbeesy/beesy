import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { doc, getDoc } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { AlbumDoc } from '../types'

export default function AlbumDetail() {
  const { id } = useParams()
  const [album, setAlbum] = useState<AlbumDoc | null>(null)
  const [zoom, setZoom] = useState<string | null>(null)

  useEffect(() => {
    if (!isConfigured || !id) return
    getDoc(doc(db, 'albums', id))
      .then((s) => {
        if (s.exists()) setAlbum({ id: s.id, ...(s.data() as Omit<AlbumDoc, 'id'>) })
      })
      .catch(() => {})
  }, [id])

  if (!album) {
    return (
      <div className="wrap">
        <section className="section"><div className="loading">Đang tải album…</div></section>
      </div>
    )
  }

  return (
    <div className="wrap">
      <Link to="/thu-vien-anh" className="back-link">← Thư viện ảnh</Link>
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="section-head">
          <div>
            <h2>{album.title}</h2>
            <p>📅 {album.date} · 📷 {album.photos?.length || 0} ảnh</p>
          </div>
        </div>
        {album.description && <p style={{ color: '#5d7590', fontWeight: 600 }}>{album.description}</p>}
        {!album.photos?.length ? (
          <div className="empty">Album chưa có ảnh nào.</div>
        ) : (
          <div className="lesson-gallery">
            {album.photos.map((p, i) => (
              <div key={i}>
                <img src={p.url} alt={p.caption || `Ảnh ${i + 1}`} onClick={() => setZoom(p.url)} loading="lazy" />
                {p.caption && <div style={{ fontSize: 13, color: '#5d7590', marginTop: 4, textAlign: 'center' }}>{p.caption}</div>}
              </div>
            ))}
          </div>
        )}
      </section>
      {zoom && (
        <div className="lightbox" onClick={() => setZoom(null)}>
          <button className="lightbox-close" onClick={() => setZoom(null)} aria-label="Đóng">✕</button>
          <img src={zoom} alt="Ảnh phóng to" onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </div>
  )
}
