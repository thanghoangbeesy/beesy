import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { doc, getDoc } from 'firebase/firestore'
import { ExternalLink, Gamepad2, X } from 'lucide-react'
import { db } from '../firebase'
import { LessonDoc } from '../types'

export default function LessonDetail() {
  const { id } = useParams()
  const [lesson, setLesson] = useState<LessonDoc | null>(null)
  const [zoom, setZoom] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return
    getDoc(doc(db, 'lessons', id))
      .then((d) => d.exists() && setLesson({ id: d.id, ...(d.data() as Omit<LessonDoc, 'id'>) }))
      .catch(() => {})
  }, [id])

  if (!lesson) return <div className="wrap"><div className="loading">Đang tải bài học…</div></div>

  return (
    <div className="wrap">
      <Link to={`/lop/${lesson.classId}`} className="back-link">← Về lớp học</Link>
      <div className="lesson-hero">
        <span className="lesson-cat">{lesson.category}</span>
        <h1 style={{ marginTop: 10 }}>{lesson.title}</h1>
        <div className="lesson-date">{lesson.date}</div>
      </div>
      <div className="lesson-body">{lesson.content}</div>
      {lesson.images && lesson.images.length > 0 && (
        <>
          <h3 style={{ margin: '18px 0 4px' }}>📷 Ảnh hoạt động của bé</h3>
          <div className="lesson-gallery">
            {lesson.images.map((u) => (
              <img key={u} src={u} alt="Ảnh hoạt động" loading="lazy" onClick={() => setZoom(u)} />
            ))}
          </div>
        </>
      )}
      <div className="row-center" style={{ marginBottom: 60 }}>
        {lesson.link && (
          <a href={lesson.link} target="_blank" rel="noreferrer">
            <button className="btn-soft"><ExternalLink size={16} /> Mở tài liệu đính kèm</button>
          </a>
        )}
        <Link to="/tro-choi">
          <button className="btn-primary"><Gamepad2 size={18} /> Chơi game ôn bài</button>
        </Link>
      </div>
      {zoom && (
        <div className="lightbox" onClick={() => setZoom(null)}>
          <button className="lightbox-close" onClick={() => setZoom(null)} aria-label="Đóng">
            <X size={22} />
          </button>
          <img src={zoom} alt="Ảnh phóng to" onClick={(e) => e.stopPropagation()} />
        </div>
      )}
    </div>
  )
}
