import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { collection, doc, getDoc, getDocs, query, where } from 'firebase/firestore'
import { BookOpen, Users, CalendarDays, Search } from 'lucide-react'
import { db } from '../firebase'
import { ClassDoc, LessonDoc, StudentDoc, LESSON_CATEGORIES } from '../types'

export default function ClassDetail() {
  const { id } = useParams()
  const [cls, setCls] = useState<ClassDoc | null>(null)
  const [lessons, setLessons] = useState<LessonDoc[]>([])
  const [students, setStudents] = useState<StudentDoc[]>([])
  const [q, setQ] = useState('')
  const [cat, setCat] = useState('Tất cả')

  useEffect(() => {
    if (!id) return
    ;(async () => {
      const c = await getDoc(doc(db, 'classes', id))
      if (c.exists()) setCls({ id: c.id, ...(c.data() as Omit<ClassDoc, 'id'>) })
      const ls = await getDocs(query(collection(db, 'lessons'), where('classId', '==', id)))
      setLessons(
        ls.docs
          .map((d) => ({ id: d.id, ...(d.data() as Omit<LessonDoc, 'id'>) }))
          .sort((a, b) => b.date.localeCompare(a.date)),
      )
      const ss = await getDocs(query(collection(db, 'students'), where('classId', '==', id)))
      setStudents(ss.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudentDoc, 'id'>) })))
    })().catch(() => {})
  }, [id])

  const filtered = useMemo(
    () =>
      lessons.filter(
        (l) =>
          (cat === 'Tất cả' || l.category === cat) &&
          l.title.toLowerCase().includes(q.toLowerCase()),
      ),
    [lessons, q, cat],
  )

  if (!cls) return <div className="wrap"><div className="loading">Đang tải lớp học…</div></div>

  return (
    <div className="wrap">
      <Link to="/" className="back-link">← Tất cả lớp học</Link>
      <div className="class-banner" style={{ background: cls.bg }}>
        {cls.imageUrl ? (
          <img className="mascot-img" src={cls.imageUrl} alt={cls.name} />
        ) : (
          <div className="mascot">{cls.mascot}</div>
        )}
        <div>
          <h1>{cls.name}</h1>
          <span className="level-tag" style={{ background: '#fff', color: cls.accent }}>
            {cls.level}
          </span>
          {cls.schedule.length > 0 && (
            <div className="banner-sched">
              <CalendarDays size={17} /> {cls.schedule.join(' · ')}
            </div>
          )}
        </div>
      </div>

      <div className="two-col">
        <div>
          <h2 className="panel-title"><BookOpen size={22} color={cls.accent} /> Bài học</h2>
          <div style={{ position: 'relative' }}>
            <input
              className="search"
              placeholder="Tìm bài học…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
          <div className="chips-row">
            {['Tất cả', ...LESSON_CATEGORIES].map((c) => (
              <button key={c} className={`chip${cat === c ? ' on' : ''}`} onClick={() => setCat(c)}>
                {c}
              </button>
            ))}
          </div>
          {filtered.length === 0 ? (
            <div className="empty">Chưa có bài học nào. Bé quay lại sau nhé! 🌈</div>
          ) : (
            filtered.map((l) => (
              <div className="lesson-card" key={l.id}>
                <div>
                  <h4>
                    {l.title}
                    <span className="lesson-cat">{l.category}</span>
                  </h4>
                  <div className="lesson-date">{l.date}</div>
                </div>
                <Link to={`/bai-hoc/${l.id}`}>
                  <button className="btn-lesson">Xem bài</button>
                </Link>
              </div>
            ))
          )}
        </div>
        <div className="students-panel" style={{ background: cls.bg }}>
          <div className="eyebrow" style={{ color: cls.accent }}>LỚP CỦA BÉ</div>
          <h3><Users size={22} color={cls.accent} /> Các bạn trong lớp</h3>
          <div style={{ color: '#62708a', fontSize: 14 }}>{students.length} bé</div>
          <div className="student-chips">
            {students.map((s) => (
              <span className="student-chip" key={s.id}>{s.name}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
