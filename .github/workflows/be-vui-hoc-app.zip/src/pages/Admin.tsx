import { useEffect, useState } from 'react'
import {
  collection, deleteDoc, doc, documentId, getDoc, getDocs, orderBy, query, setDoc, where,
} from 'firebase/firestore'
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword, signOut, User,
} from 'firebase/auth'
import { auth, db, isConfigured, SETUP_KEY } from '../firebase'
import { ClassDoc, LessonDoc, ResourceDoc, StudentDoc, WordDoc, LESSON_CATEGORIES, RESOURCE_CATEGORIES, BrandDoc } from '../types'
import { seedDatabase } from '../data/seed'

type Tab = 'brand' | 'classes' | 'students' | 'lessons' | 'words' | 'resources' | 'attendance'

export default function Admin() {
  const [user, setUser] = useState<User | null>(null)
  const [tab, setTab] = useState<Tab>('classes')
  const [msg, setMsg] = useState('')

  useEffect(() => onAuthStateChanged(auth, setUser), [])

  if (!isConfigured) {
    return (
      <div className="wrap"><div className="admin">
        <div className="notice">Web chưa có cấu hình Firebase. Anh làm theo README để thêm các khóa <b>VITE_FIREBASE_*</b> vào Secrets của GitHub rồi deploy lại nhé.</div>
      </div></div>
    )
  }

  return (
    <div className="wrap"><div className="admin">
      <h1>🔧 Quản trị lớp học</h1>
      {!user ? (
        <AuthBox onMsg={setMsg} />
      ) : (
        <>
          <div className="admin-box" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>Xin chào, <b>{user.email}</b> 👋</div>
            <button className="btn-small" onClick={() => signOut(auth)}>Đăng xuất</button>
          </div>
          <div className="tabs">
            {([['brand', '⚙️ Cài đặt'], ['classes', '🏫 Lớp học'], ['students', '🧒 Học sinh'], ['attendance', '📋 Điểm danh'], ['lessons', '📖 Bài học'], ['words', '🔤 Từ vựng'], ['resources', '📚 Tài liệu']] as [Tab, string][]).map(([t, label]) => (
              <button key={t} className={`chip${tab === t ? ' on' : ''}`} onClick={() => setTab(t)}>{label}</button>
            ))}
          </div>
          {msg && <div className="notice">{msg}</div>}
          {tab === 'brand' && <BrandTab onMsg={setMsg} />}
          {tab === 'classes' && <ClassesTab onMsg={setMsg} />}
          {tab === 'students' && <StudentsTab onMsg={setMsg} />}
          {tab === 'lessons' && <LessonsTab onMsg={setMsg} />}
          {tab === 'words' && <WordsTab onMsg={setMsg} />}
          {tab === 'resources' && <ResourcesTab onMsg={setMsg} />}
          {tab === 'attendance' && <AttendanceTab onMsg={setMsg} />}
        </>
      )}
    </div></div>
  )
}

function friendlyAuthError(code: string): string {
  if (code === 'auth/email-already-in-use') return 'Email này đã có tài khoản rồi. Anh bấm "Đã có tài khoản? Đăng nhập" nhé.'
  if (code === 'auth/weak-password') return 'Mật khẩu phải từ 6 ký tự trở lên anh nhé.'
  if (code === 'auth/invalid-email') return 'Email chưa đúng định dạng.'
  if (code === 'auth/operation-not-allowed') return 'Chưa bật phương thức Email/Password: vào Firebase Console → Authentication → Sign-in method → bật Email/Password.'
  if (code === 'auth/user-not-found' || code === 'auth/wrong-password' || code === 'auth/invalid-credential') return 'Sai email hoặc mật khẩu.'
  if (code === 'auth/network-request-failed') return 'Lỗi mạng, anh kiểm tra internet rồi thử lại.'
  return 'Có lỗi xảy ra (' + code + '). Anh thử lại nhé.'
}

function AuthBox({ onMsg }: { onMsg: (m: string) => void }) {
  const [email, setEmail] = useState('')
  const [pass, setPass] = useState('')
  const [key, setKey] = useState('')
  const [mode, setMode] = useState<'login' | 'setup'>('login')
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)
  void onMsg

  const login = async () => {
    setMsg('')
    setBusy(true)
    try { await signInWithEmailAndPassword(auth, email, pass) }
    catch (e: any) { setMsg(friendlyAuthError(e?.code || '')) }
    setBusy(false)
  }
  const setup = async () => {
    setMsg('')
    if (key !== SETUP_KEY) {
      setMsg('Sai khóa cài đặt. Khóa này phải trùng với secret VITE_SETUP_KEY trên GitHub (lúc build web). Anh kiểm tra lại nhé.')
      return
    }
    setBusy(true)
    try {
      await createUserWithEmailAndPassword(auth, email, pass)
    } catch (e: any) { setMsg(friendlyAuthError(e?.code || '')) }
    setBusy(false)
  }

  return (
    <div className="admin-box">
      <h2>{mode === 'login' ? 'Đăng nhập quản trị' : 'Tạo tài khoản quản trị (lần đầu)'}</h2>
      {msg && <div className="notice">{msg}</div>}
      <div className="field"><label>Email</label><input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@vidu.com" /></div>
      <div className="field"><label>Mật khẩu</label><input type="password" value={pass} onChange={(e) => setPass(e.target.value)} /></div>
      {mode === 'setup' && (
        <div className="field"><label>Khóa cài đặt (VITE_SETUP_KEY)</label><input value={key} onChange={(e) => setKey(e.target.value)} placeholder="Nhập khóa bí mật" /></div>
      )}
      <div className="row-center" style={{ justifyContent: 'flex-start' }}>
        {mode === 'login'
          ? <button className="btn-primary" disabled={busy} onClick={login}>{busy ? 'Đang xử lý…' : 'Đăng nhập'}</button>
          : <button className="btn-primary" disabled={busy} onClick={setup}>{busy ? 'Đang xử lý…' : 'Tạo tài khoản'}</button>}
        <button className="btn-soft" onClick={() => { setMode(mode === 'login' ? 'setup' : 'login'); setMsg('') }}>
          {mode === 'login' ? 'Chưa có tài khoản? Tạo mới' : 'Đã có tài khoản? Đăng nhập'}
        </button>
      </div>
    </div>
  )
}

function BrandTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [b, setB] = useState<BrandDoc>({ name: '', slogan: '', heroTitle: '', heroSubtitle: '', phone: '', address: '' })
  const [seedBusy, setSeedBusy] = useState(false)
  useEffect(() => {
    import('firebase/firestore').then(({ getDoc }) =>
      getDoc(doc(db, 'settings', 'brand')).then((s) => {
        if (s.exists()) setB({ phone: '', address: '', ...(s.data() as BrandDoc) })
      }),
    )
  }, [])
  return (
    <>
      <div className="admin-box">
        <h2>⚙️ Tên web & khẩu hiệu</h2>
        <div className="field"><label>Tên lớp / thương hiệu</label><input value={b.name} onChange={(e) => setB({ ...b, name: e.target.value })} /></div>
        <div className="field"><label>Khẩu hiệu (dưới logo)</label><input value={b.slogan} onChange={(e) => setB({ ...b, slogan: e.target.value })} /></div>
        <div className="field"><label>Dòng phụ ở banner (cách nhau bằng •)</label><input value={b.heroSubtitle} onChange={(e) => setB({ ...b, heroSubtitle: e.target.value })} placeholder="Tập đọc • Tập viết • Phát âm • Đọc từ" /></div>
        <div className="field"><label>📞 Số điện thoại liên hệ</label><input value={b.phone || ''} onChange={(e) => setB({ ...b, phone: e.target.value })} placeholder="VD: 0901 234 567" inputMode="tel" /></div>
        <div className="field"><label>📍 Địa chỉ lớp học</label><input value={b.address || ''} onChange={(e) => setB({ ...b, address: e.target.value })} placeholder="VD: 123 đường ABC, phường XYZ" /></div>
        <button className="btn-primary" onClick={async () => { await setDoc(doc(db, 'settings', 'brand'), b); onMsg('Đã lưu! ✅') }}>Lưu</button>
      </div>
      <div className="admin-box">
        <h2>🌱 Dữ liệu mẫu</h2>
        <p style={{ color: '#62708a', fontSize: 14 }}>Nạp 4 lớp, học sinh, bài học, từ vựng và tài liệu mẫu để web có nội dung ngay. Anh sửa/xóa thoải mái sau.</p>
        <button
          className="btn-primary"
          disabled={seedBusy}
          onClick={async () => {
            if (!confirm('Nạp dữ liệu mẫu? (Nên dùng khi web còn trống — dữ liệu cũ vẫn giữ nguyên, nhưng từ vựng có thể bị trùng, anh dùng nút "Dọn từ trùng" sau.)')) return
            setSeedBusy(true)
            await seedDatabase()
            setSeedBusy(false)
            onMsg('Đã nạp dữ liệu mẫu! Ra trang chủ xem nhé 🌈')
          }}
        >
          {seedBusy ? 'Đang nạp…' : 'Nạp dữ liệu mẫu'}
        </button>
      </div>
    </>
  )
}

function ClassesTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [list, setList] = useState<ClassDoc[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const emptyForm = { name: '', level: 'Tập đọc sớm', mascot: '🦊', accent: '#ae3d49', bg: '#fff0e9', schedule: '' }
  const [f, setF] = useState(emptyForm)
  const load = () => getDocs(query(collection(db, 'classes'), orderBy('order')))
    .then((s) => setList(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) }))))
  useEffect(() => { load() }, [])
  const startEdit = (c: ClassDoc) => {
    setEditingId(c.id)
    setF({
      name: c.name,
      level: c.level,
      mascot: c.mascot || '🦊',
      accent: c.accent || '#ae3d49',
      bg: c.bg || '#fff0e9',
      schedule: (c.schedule || []).join(', '),
    })
    window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })
  }
  const cancelEdit = () => {
    setEditingId(null)
    setF(emptyForm)
  }
  const save = async () => {
    if (!f.name.trim()) { onMsg('Nhập tên lớp đã anh nhé.'); return }
    const data = {
      name: f.name.trim(),
      level: f.level,
      mascot: f.mascot || '🦊',
      accent: f.accent,
      bg: f.bg,
      schedule: f.schedule.split(',').map((s) => s.trim()).filter(Boolean),
    }
    if (editingId) {
      await setDoc(doc(db, 'classes', editingId), data, { merge: true })
      onMsg('Đã lưu thay đổi! ✅')
    } else {
      await setDoc(doc(collection(db, 'classes')), { ...data, order: list.length + 1 })
      onMsg('Đã thêm lớp! ✅')
    }
    cancelEdit()
    load()
  }
  return (
    <div className="admin-box">
      <h2>🏫 Lớp học ({list.length})</h2>
      {list.map((c) => (
        <div className="admin-row" key={c.id}>
          <span>{c.mascot} <b>{c.name}</b> – {c.level}</span>
          <span>
            <button className="btn-small" style={{ marginRight: 8 }} onClick={() => startEdit(c)}>Sửa</button>
            <button className="btn-danger" onClick={async () => { if (confirm(`Xóa lớp "${c.name}"?`)) { await deleteDoc(doc(db, 'classes', c.id)); load() } }}>Xóa</button>
          </span>
        </div>
      ))}
      <h3>{editingId ? 'Sửa lớp học' : 'Thêm lớp mới'}</h3>
      <div className="form-inline">
        <input placeholder="Tên lớp (VD: Lớp Cáo Con)" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <select value={f.level} onChange={(e) => setF({ ...f, level: e.target.value })}>
          {['Tập đọc sớm', 'Tập viết', 'Phát âm', 'Đọc từ', 'Tổng hợp'].map((l) => <option key={l}>{l}</option>)}
        </select>
        <input placeholder="Biểu tượng 🦊" value={f.mascot} onChange={(e) => setF({ ...f, mascot: e.target.value })} style={{ maxWidth: 110 }} />
        <input placeholder="Lịch học, cách nhau bằng dấu phẩy" value={f.schedule} onChange={(e) => setF({ ...f, schedule: e.target.value })} />
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 700 }}>
          Màu chữ <input type="color" value={f.accent} onChange={(e) => setF({ ...f, accent: e.target.value })} style={{ width: 44, height: 36, padding: 2 }} />
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 700 }}>
          Màu nền <input type="color" value={f.bg} onChange={(e) => setF({ ...f, bg: e.target.value })} style={{ width: 44, height: 36, padding: 2 }} />
        </label>
        <button className="btn-primary" onClick={save}>{editingId ? 'Lưu thay đổi' : 'Thêm'}</button>
        {editingId && <button className="btn-soft" onClick={cancelEdit}>Hủy</button>}
      </div>
    </div>
  )
}

function StudentsTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [classId, setClassId] = useState('')
  const [list, setList] = useState<StudentDoc[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const emptyForm = { name: '', dob: '', parentName: '', parentPhone: '' }
  const [f, setF] = useState(emptyForm)
  useEffect(() => {
    getDocs(query(collection(db, 'classes'), orderBy('order')))
      .then((s) => {
        const cs = s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) }))
        setClasses(cs)
        if (cs[0]) setClassId((cur) => cur || cs[0].id)
      })
  }, [])
  const load = (cid: string) => {
    if (!cid) return
    getDocs(query(collection(db, 'students'), where('classId', '==', cid)))
      .then((s) => setList(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudentDoc, 'id'>) }))))
  }
  useEffect(() => { load(classId) }, [classId])
  const startEdit = (s: StudentDoc) => {
    setEditingId(s.id)
    setF({
      name: s.name || '',
      dob: s.dob || '',
      parentName: s.parentName || '',
      parentPhone: s.parentPhone || '',
    })
  }
  const cancelEdit = () => {
    setEditingId(null)
    setF(emptyForm)
  }
  const save = async () => {
    if (!f.name.trim() || !classId) { onMsg('Nhập tên bé đã anh nhé.'); return }
    const data = {
      classId,
      name: f.name.trim(),
      dob: f.dob,
      parentName: f.parentName.trim(),
      parentPhone: f.parentPhone.trim(),
    }
    if (editingId) {
      await setDoc(doc(db, 'students', editingId), data, { merge: true })
      onMsg('Đã lưu thay đổi! ✅')
    } else {
      await setDoc(doc(collection(db, 'students')), data)
      onMsg('Đã thêm bé! ✅')
    }
    cancelEdit()
    load(classId)
  }
  return (
    <div className="admin-box">
      <h2>🧒 Học sinh</h2>
      <div className="field">
        <label>Lớp{editingId ? ' (đổi lớp cho bé ở đây nếu cần)' : ''}</label>
        <select value={classId} onChange={(e) => setClassId(e.target.value)}>
          {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      {list.map((s) => (
        <div className="admin-row" key={s.id}>
          <span>
            <b>{s.name}</b>
            {s.dob && (<><br /><small style={{ color: '#62708a' }}>🎂 {s.dob}</small></>)}
            {(s.parentName || s.parentPhone) && (
              <><br /><small style={{ color: '#62708a' }}>👪 {[s.parentName, s.parentPhone].filter(Boolean).join(' – ')}</small></>
            )}
          </span>
          <span style={{ whiteSpace: 'nowrap' }}>
            <button className="btn-small" style={{ marginRight: 8 }} onClick={() => startEdit(s)}>Sửa</button>
            <button className="btn-danger" onClick={async () => { if (confirm(`Xóa bé "${s.name}"?`)) { if (editingId === s.id) cancelEdit(); await deleteDoc(doc(db, 'students', s.id)); load(classId) } }}>Xóa</button>
          </span>
        </div>
      ))}
      <h3>{editingId ? 'Sửa thông tin bé' : 'Thêm bé mới'}</h3>
      <div className="form-inline">
        <input placeholder="Tên bé *" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 700 }}>
          Ngày sinh <input type="date" value={f.dob} onChange={(e) => setF({ ...f, dob: e.target.value })} style={{ minWidth: 150 }} />
        </label>
        <input placeholder="Tên phụ huynh" value={f.parentName} onChange={(e) => setF({ ...f, parentName: e.target.value })} />
        <input placeholder="SĐT phụ huynh" value={f.parentPhone} onChange={(e) => setF({ ...f, parentPhone: e.target.value })} inputMode="tel" />
        <button className="btn-primary" onClick={save}>{editingId ? 'Lưu thay đổi' : 'Thêm bé'}</button>
        {editingId && <button className="btn-soft" onClick={cancelEdit}>Hủy</button>}
      </div>
    </div>
  )
}

function LessonsTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [classId, setClassId] = useState('')
  const [list, setList] = useState<LessonDoc[]>([])
  const [f, setF] = useState({ title: '', date: new Date().toISOString().slice(0, 10), category: LESSON_CATEGORIES[0], content: '', link: '' })
  useEffect(() => {
    getDocs(query(collection(db, 'classes'), orderBy('order')))
      .then((s) => {
        const cs = s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) }))
        setClasses(cs)
        if (cs[0]) setClassId(cs[0].id)
      })
  }, [])
  const load = (cid: string) => {
    if (!cid) return
    getDocs(query(collection(db, 'lessons'), where('classId', '==', cid)))
      .then((s) => setList(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<LessonDoc, 'id'>) })).sort((a, b) => b.date.localeCompare(a.date))))
  }
  useEffect(() => { load(classId) }, [classId])
  const add = async () => {
    if (!f.title.trim() || !classId) { onMsg('Nhập tiêu đề bài học đã anh nhé.'); return }
    await setDoc(doc(collection(db, 'lessons')), { ...f, classId })
    setF({ title: '', date: new Date().toISOString().slice(0, 10), category: LESSON_CATEGORIES[0], content: '', link: '' })
    load(classId); onMsg('Đã thêm bài học! ✅')
  }
  return (
    <div className="admin-box">
      <h2>📖 Bài học</h2>
      <div className="field"><label>Lớp</label>
        <select value={classId} onChange={(e) => setClassId(e.target.value)}>
          {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      {list.map((l) => (
        <div className="admin-row" key={l.id}>
          <span><b>{l.title}</b> <span className="lesson-cat">{l.category}</span><br /><small style={{ color: '#62708a' }}>{l.date}</small></span>
          <button className="btn-danger" onClick={async () => { if (confirm('Xóa bài này?')) { await deleteDoc(doc(db, 'lessons', l.id)); load(classId) } }}>Xóa</button>
        </div>
      ))}
      <h3>Thêm bài học mới</h3>
      <div className="field"><label>Tiêu đề</label><input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="VD: Bài 3 – Vần an, at" /></div>
      <div className="form-inline">
        <input type="date" value={f.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
        <select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>
          {LESSON_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>
      <div className="field" style={{ marginTop: 10 }}><label>Nội dung bài (phụ huynh cho bé đọc/ôn ở nhà)</label>
        <textarea value={f.content} onChange={(e) => setF({ ...f, content: e.target.value })} placeholder="Viết nội dung bài học, bài tập về nhà…" />
      </div>
      <div className="field"><label>Link đính kèm (video, phiếu bài tập… – không bắt buộc)</label>
        <input value={f.link} onChange={(e) => setF({ ...f, link: e.target.value })} placeholder="https://…" />
      </div>
      <button className="btn-primary" onClick={add}>Đăng bài học</button>
    </div>
  )
}

const fmtDate = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
const todayStr = () => fmtDate(new Date())

function AttendanceTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [classId, setClassId] = useState('')
  const [view, setView] = useState<'daily' | 'report'>('daily')
  const [date, setDate] = useState(todayStr())
  const [students, setStudents] = useState<StudentDoc[]>([])
  const [records, setRecords] = useState<Record<string, 'present' | 'absent'>>({})
  const [hasRecord, setHasRecord] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    getDocs(query(collection(db, 'classes'), orderBy('order')))
      .then((s) => {
        const cs = s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) }))
        setClasses(cs)
        if (cs[0]) setClassId((cur) => cur || cs[0].id)
      })
  }, [])

  useEffect(() => {
    if (!classId) return
    getDocs(query(collection(db, 'students'), where('classId', '==', classId)))
      .then((s) => setStudents(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudentDoc, 'id'>) }))))
  }, [classId])

  useEffect(() => {
    if (!classId || !date) return
    getDoc(doc(db, 'attendance', `${classId}_${date}`)).then((snap) => {
      if (snap.exists()) {
        setRecords((snap.data() as { records?: Record<string, 'present' | 'absent'> }).records || {})
        setHasRecord(true)
      } else {
        setRecords({})
        setHasRecord(false)
      }
    })
  }, [classId, date])

  const statusOf = (sid: string): 'present' | 'absent' => records[sid] || 'present'
  const presentCount = students.filter((s) => statusOf(s.id) === 'present').length

  const save = async () => {
    if (!classId || !date || students.length === 0) return
    setBusy(true)
    const full: Record<string, 'present' | 'absent'> = {}
    students.forEach((s) => { full[s.id] = statusOf(s.id) })
    await setDoc(doc(db, 'attendance', `${classId}_${date}`), {
      classId,
      date,
      records: full,
      updatedAt: new Date().toISOString(),
    })
    setHasRecord(true)
    setBusy(false)
    onMsg(`Đã lưu điểm danh ngày ${date}! ✅`)
  }

  return (
    <div className="admin-box">
      <h2>📋 Điểm danh</h2>
      <div className="row-center" style={{ justifyContent: 'flex-start', marginBottom: 14 }}>
        <button className={`chip${view === 'daily' ? ' on' : ''}`} onClick={() => setView('daily')}>Điểm danh hằng ngày</button>
        <button className={`chip${view === 'report' ? ' on' : ''}`} onClick={() => setView('report')}>📊 Tổng kết</button>
      </div>
      {view === 'daily' ? (
        <>
          <div className="form-inline" style={{ marginBottom: 6 }}>
            <select value={classId} onChange={(e) => setClassId(e.target.value)} aria-label="Lớp">
              {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} aria-label="Ngày" />
          </div>
          <p style={{ color: '#62708a', fontSize: 14 }}>
            {hasRecord ? `Đã điểm danh ngày này.` : `Chưa điểm danh ngày này — mặc định tất cả "Có mặt", anh chỉ cần đánh dấu bé nào vắng.`}
            {' '}Sĩ số: <b>{presentCount}/{students.length}</b> có mặt.
          </p>
          {students.map((s) => {
            const st = statusOf(s.id)
            return (
              <div className="admin-row" key={s.id}>
                <span><b>{s.name}</b>{s.dob && <small style={{ color: '#62708a' }}> · 🎂 {s.dob}</small>}</span>
                <span style={{ whiteSpace: 'nowrap' }}>
                  <button
                    className="btn-small"
                    style={{
                      marginRight: 8,
                      background: st === 'present' ? '#dcfce7' : undefined,
                      borderColor: st === 'present' ? '#22c55e' : undefined,
                      color: st === 'present' ? '#15803d' : undefined,
                    }}
                    onClick={() => setRecords((r) => ({ ...r, [s.id]: 'present' }))}
                  >
                    ✓ Có mặt
                  </button>
                  <button
                    className="btn-small"
                    style={{
                      background: st === 'absent' ? '#fee2e2' : undefined,
                      borderColor: st === 'absent' ? '#ef4444' : undefined,
                      color: st === 'absent' ? '#b91c1c' : undefined,
                    }}
                    onClick={() => setRecords((r) => ({ ...r, [s.id]: 'absent' }))}
                  >
                    ✕ Vắng
                  </button>
                </span>
              </div>
            )
          })}
          {students.length === 0 && <div className="empty">Lớp này chưa có học sinh nào.</div>}
          <button className="btn-primary" disabled={busy || students.length === 0} onClick={save} style={{ marginTop: 14 }}>
            {busy ? 'Đang lưu…' : '💾 Lưu điểm danh'}
          </button>
        </>
      ) : (
        <AttendanceReport classId={classId} classes={classes} onClassChange={setClassId} students={students} />
      )}
    </div>
  )
}

interface DayRecord {
  date: string
  records: Record<string, 'present' | 'absent'>
}

function AttendanceReport({ classId, classes, onClassChange, students }: {
  classId: string
  classes: ClassDoc[]
  onClassChange: (id: string) => void
  students: StudentDoc[]
}) {
  const weekStart = () => {
    const now = new Date()
    const d = new Date(now)
    d.setDate(now.getDate() - ((now.getDay() + 6) % 7))
    return fmtDate(d)
  }
  const monthStart = () => {
    const now = new Date()
    return fmtDate(new Date(now.getFullYear(), now.getMonth(), 1))
  }
  const [preset, setPreset] = useState<'week' | 'month' | 'custom'>('week')
  const [from, setFrom] = useState(weekStart())
  const [to, setTo] = useState(todayStr())
  const [days, setDays] = useState<DayRecord[]>([])
  const [loading, setLoading] = useState(false)

  const applyPreset = (p: 'week' | 'month') => {
    setPreset(p)
    setFrom(p === 'week' ? weekStart() : monthStart())
    setTo(todayStr())
  }

  useEffect(() => {
    if (!classId || !from || !to) return
    setLoading(true)
    const q = query(
      collection(db, 'attendance'),
      where(documentId(), '>=', `${classId}_${from}`),
      where(documentId(), '<=', `${classId}_${to}`),
    )
    getDocs(q)
      .then((s) => {
        const list = s.docs
          .map((d) => {
            const data = d.data() as { date?: string; records?: Record<string, 'present' | 'absent'> }
            return { date: data.date || '', records: data.records || {} }
          })
          .filter((r) => r.date >= from && r.date <= to)
          .sort((a, b) => a.date.localeCompare(b.date))
        setDays(list)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [classId, from, to])

  const stats = students.map((s) => {
    let present = 0
    const absentDates: string[] = []
    days.forEach((d) => {
      if ((d.records[s.id] || 'present') === 'present') present++
      else absentDates.push(d.date)
    })
    return { student: s, present, absent: absentDates.length, absentDates, total: days.length }
  }).sort((a, b) => b.absent - a.absent || a.student.name.localeCompare(b.student.name))

  const totalAbsentSessions = stats.reduce((sum, s) => sum + s.absent, 0)

  return (
    <div>
      <div className="form-inline" style={{ marginBottom: 6 }}>
        <select value={classId} onChange={(e) => onClassChange(e.target.value)} aria-label="Lớp">
          {classes.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      <div className="row-center" style={{ justifyContent: 'flex-start', marginBottom: 10 }}>
        <button className={`chip${preset === 'week' ? ' on' : ''}`} onClick={() => applyPreset('week')}>Tuần này</button>
        <button className={`chip${preset === 'month' ? ' on' : ''}`} onClick={() => applyPreset('month')}>Tháng này</button>
        <button className={`chip${preset === 'custom' ? ' on' : ''}`} onClick={() => setPreset('custom')}>Tùy chọn</button>
      </div>
      {preset === 'custom' && (
        <div className="form-inline" style={{ marginBottom: 10 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 700 }}>
            Từ <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </label>
          <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 700 }}>
            Đến <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </label>
        </div>
      )}
      {loading ? (
        <div className="loading">Đang tính…</div>
      ) : days.length === 0 ? (
        <div className="empty">Chưa có dữ liệu điểm danh trong khoảng này.</div>
      ) : (
        <>
          <p style={{ color: '#62708a', fontSize: 14 }}>
            {from} → {to}: <b>{days.length}</b> buổi đã điểm danh · tổng <b>{totalAbsentSessions}</b> lượt vắng.
          </p>
          {stats.map(({ student, present, absent, absentDates, total }) => (
            <div className="admin-row" key={student.id}>
              <span>
                <b>{student.name}</b>
                <br />
                <small style={{ color: '#62708a' }}>
                  ✅ {present}/{total} buổi có mặt
                  {absent > 0 && <> · <span style={{ color: '#b91c1c' }}>❌ vắng {absent} buổi ({absentDates.join(', ')})</span></>}
                </small>
              </span>
              <span className="score-pill" style={absent > 0 ? { background: '#fee2e2', color: '#b91c1c' } : { background: '#dcfce7', color: '#15803d' }}>
                {absent === 0 ? 'Chuyên cần 💯' : `Vắng ${absent}`}
              </span>
            </div>
          ))}
        </>
      )}
    </div>
  )
}

function WordsTab({ onMsg }: { onMsg: (m: string) => void }) {  const [list, setList] = useState<WordDoc[]>([])
  const [text, setText] = useState('')
  const [emoji, setEmoji] = useState('')
  const load = () => getDocs(collection(db, 'words'))
    .then((s) => setList(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<WordDoc, 'id'>) }))))
  useEffect(() => { load() }, [])
  const add = async () => {
    if (!text.trim()) return
    await setDoc(doc(collection(db, 'words')), { text: text.trim(), emoji: emoji.trim() || '⭐' })
    setText(''); setEmoji(''); load(); onMsg('Đã thêm từ! ✅')
  }
  const dedupe = async () => {
    const s = await getDocs(collection(db, 'words'))
    const seen = new Set<string>()
    let removed = 0
    for (const d of s.docs) {
      const t = ((d.data() as WordDoc).text || '').trim().toLowerCase()
      if (!t || seen.has(t)) {
        await deleteDoc(doc(db, 'words', d.id))
        removed++
      } else {
        seen.add(t)
      }
    }
    load()
    onMsg(removed ? `Đã dọn ${removed} từ trùng! ✅` : 'Không có từ trùng nào.')
  }
  return (
    <div className="admin-box">
      <h2>🔤 Kho từ vựng cho game ({list.length} từ)</h2>
      <p style={{ color: '#62708a', fontSize: 14 }}>Các từ này dùng trong game "Nghe và chọn", "Thẻ từ vựng" và "Đố chữ cái đầu".</p>
      <button className="btn-small" onClick={dedupe} style={{ marginBottom: 12 }}>🧹 Dọn từ trùng</button>
      <div className="student-chips" style={{ marginBottom: 14 }}>
        {list.map((w) => (
          <span className="student-chip" key={w.id}>
            {w.emoji} {w.text}
            <button className="btn-danger" style={{ marginLeft: 8 }} onClick={async () => { await deleteDoc(doc(db, 'words', w.id)); load() }}>✕</button>
          </span>
        ))}
      </div>
      <div className="form-inline">
        <input placeholder="Từ (VD: quả)" value={text} onChange={(e) => setText(e.target.value)} />
        <input placeholder="Biểu tượng 🍎" value={emoji} onChange={(e) => setEmoji(e.target.value)} style={{ maxWidth: 130 }} />
        <button className="btn-primary" onClick={add}>Thêm từ</button>
      </div>
    </div>
  )
}

function ResourcesTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [list, setList] = useState<ResourceDoc[]>([])
  const [f, setF] = useState({ title: '', category: RESOURCE_CATEGORIES[0], description: '', url: '' })
  const load = () => getDocs(collection(db, 'resources'))
    .then((s) => setList(s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ResourceDoc, 'id'>) }))))
  useEffect(() => { load() }, [])
  const add = async () => {
    if (!f.title.trim()) return
    await setDoc(doc(collection(db, 'resources')), { ...f, published: true })
    setF({ title: '', category: RESOURCE_CATEGORIES[0], description: '', url: '' })
    load(); onMsg('Đã thêm tài liệu! ✅')
  }
  return (
    <div className="admin-box">
      <h2>📚 Tài liệu ({list.length})</h2>
      {list.map((r) => (
        <div className="admin-row" key={r.id}>
          <span><b>{r.title}</b> <span className="lesson-cat">{r.category}</span><br /><small style={{ color: '#62708a' }}>{r.published ? 'Đang hiển thị' : 'Đang ẩn'}</small></span>
          <span>
            <button className="btn-small" style={{ marginRight: 8 }} onClick={async () => { await setDoc(doc(db, 'resources', r.id), { published: !r.published }, { merge: true }); load() }}>
              {r.published ? 'Ẩn' : 'Hiện'}
            </button>
            <button className="btn-danger" onClick={async () => { if (confirm('Xóa tài liệu này?')) { await deleteDoc(doc(db, 'resources', r.id)); load() } }}>Xóa</button>
          </span>
        </div>
      ))}
      <h3>Thêm tài liệu</h3>
      <div className="field"><label>Tiêu đề</label><input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></div>
      <div className="field"><label>Nhóm</label>
        <select value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>
          {RESOURCE_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
        </select>
      </div>
      <div className="field"><label>Mô tả ngắn</label><input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
      <div className="field"><label>Link (Google Drive, YouTube…)</label><input value={f.url} onChange={(e) => setF({ ...f, url: e.target.value })} placeholder="https://…" /></div>
      <button className="btn-primary" onClick={add}>Thêm tài liệu</button>
    </div>
  )
}
