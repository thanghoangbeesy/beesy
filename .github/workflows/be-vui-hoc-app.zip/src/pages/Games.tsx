import { Link } from 'react-router-dom'

const GAMES = [
  { path: '/tro-choi/nghe-va-chon', emoji: '🔊', title: 'Nghe và chọn', desc: 'Nghe cô đọc từ, bé chọn đúng hình. Luyện phát âm thật vui!', tile: '#e3f2ff' },
  { path: '/tro-choi/the-tu', emoji: '🃏', title: 'Thẻ từ vựng', desc: 'Lật thẻ để học từ mới. Chạm vào thẻ để nghe đọc từ.', tile: '#fff3d1' },
  { path: '/tro-choi/chu-cai-dau', emoji: '🔤', title: 'Đố chữ cái đầu', desc: 'Từ còn thiếu chữ cái đầu, bé đoán xem là chữ gì nhé!', tile: '#e6f9e3' },
  { path: '/tro-choi/tap-viet', emoji: '✏️', title: 'Tập viết chữ', desc: 'Tô theo chữ mẫu trên bảng. Bé viết chậm, viết đẹp nào!', tile: '#f3e8ff' },
  { path: '/tro-choi/tri-nho', emoji: '🧠', title: 'Trí nhớ siêu phàm', desc: 'Lật thẻ tìm cặp hình – từ giống nhau. Rèn trí nhớ thật vui!', tile: '#ffe9f0' },
  { path: '/tro-choi/xep-chu', emoji: '🧩', title: 'Xếp chữ thành từ', desc: 'Nghe từ, nhìn hình rồi xếp các chữ cái đúng thứ tự!', tile: '#e0f2f1' },
]

export default function Games() {
  return (
    <div className="wrap">
      <section className="section">
        <div className="section-head">
          <h2>🎮 Trò chơi</h2>
          <p>Vừa học vừa chơi – bé ôn bài mỗi ngày!</p>
        </div>
        <div className="game-grid">
          {GAMES.map((g) => (
            <Link key={g.path} to={g.path} className="game-card">
              <div className="game-emoji" style={{ backgroundColor: g.tile }}>{g.emoji}</div>
              <div>
                <h3>{g.title}</h3>
                <p>{g.desc}</p>
                <span className="link-more">Chơi ngay →</span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
