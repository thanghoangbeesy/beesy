import { Link } from 'react-router-dom'

const GAMES = [
  { path: '/tro-choi/nghe-va-chon', emoji: '🔊', title: 'Nghe và chọn', desc: 'Nghe cô đọc từ, bé chọn đúng hình. Luyện phát âm thật vui!', bg: '#e5f6ff' },
  { path: '/tro-choi/the-tu', emoji: '🃏', title: 'Thẻ từ vựng', desc: 'Lật thẻ để học từ mới. Chạm vào thẻ để nghe đọc từ.', bg: '#fff8df' },
  { path: '/tro-choi/chu-cai-dau', emoji: '🔤', title: 'Đố chữ cái đầu', desc: 'Từ còn thiếu chữ cái đầu, bé đoán xem là chữ gì nhé!', bg: '#eaf8ef' },
  { path: '/tro-choi/tap-viet', emoji: '✏️', title: 'Tập viết chữ', desc: 'Tô theo chữ mẫu trên bảng. Bé viết chậm, viết đẹp nào!', bg: '#f2effc' },
  { path: '/tro-choi/tri-nho', emoji: '🧠', title: 'Trí nhớ siêu phàm', desc: 'Lật thẻ tìm cặp hình – từ giống nhau. Rèn trí nhớ thật vui!', bg: '#ffeef4' },
  { path: '/tro-choi/xep-chu', emoji: '🧩', title: 'Xếp chữ thành từ', desc: 'Nghe từ, nhìn hình rồi xếp các chữ cái đúng thứ tự!', bg: '#eef4ff' },
]

export default function Games() {
  return (
    <div className="wrap">
      <section className="section">
        <div className="section-head">
          <h2>🎮 Trò chơi</h2>
          <p>Vừa học vừa chơi – bé ôn bài mỗi ngày!</p>
        </div>
        <div className="game-grid">
          {GAMES.map((g) => (
            <Link key={g.path} to={g.path} className="game-card" style={{ background: g.bg }}>
              <div className="game-emoji">{g.emoji}</div>
              <div>
                <h3>{g.title}</h3>
                <p>{g.desc}</p>
                <span className="link-more">Chơi ngay →</span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}
