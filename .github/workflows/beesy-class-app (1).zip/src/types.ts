export interface ClassDoc {
  id: string
  name: string
  level: string
  mascot: string
  accent: string
  bg: string
  schedule: string[]
  imageUrl?: string
  order: number
}

export interface StudentDoc {
  id: string
  classId: string
  name: string
  // Các trường nhạy cảm đã tách sang collection `student_private`
  // (giữ optional để tương thích dữ liệu cũ trước khi migrate).
  dob?: string
  parentName?: string
  parentPhone?: string
}

/** Thông tin nhạy cảm của học sinh — chỉ quản trị + phụ huynh của bé được đọc. */
export interface StudentPrivateDoc {
  dob?: string
  parentName?: string
  parentPhone?: string
  /** Token bí mật cho "Trang của con" (/con/:token) — chỉ quản trị biết. */
  childToken?: string
}

export type LessonKind = 'doc' | 'video' | 'audio' | 'quiz'

export interface QuizQuestion {
  q: string
  options: string[]
  answer: number
}

export const LESSON_KINDS: { id: LessonKind; label: string }[] = [
  { id: 'doc', label: '📖 Bài đọc' },
  { id: 'video', label: '🎬 Video' },
  { id: 'audio', label: '🎧 Âm thanh' },
  { id: 'quiz', label: '📝 Trắc nghiệm' },
]

export interface LessonDoc {
  id: string
  classId: string
  title: string
  date: string
  category: string
  content: string
  link?: string
  images?: string[]
  kind?: LessonKind
  mediaUrl?: string
  questions?: QuizQuestion[]
}

export interface ParentDoc {
  uid: string
  email: string
  name: string
  phone?: string
  studentIds: string[]
  createdAt: number
}

export interface AlbumPhoto {
  url: string
  caption?: string
  kind?: 'image' | 'video'
}

export interface AlbumDoc {
  id: string
  title: string
  description?: string
  date: string
  coverUrl: string
  photos: AlbumPhoto[]
  createdAt: number
}

export interface TuitionRecord {
  id: string
  studentId: string
  period: string
  amount: number
  paid: number
  paidAt?: number
  note?: string
  createdAt: number
  /** Lần nhắc học phí gần nhất (ms epoch) + tổng số lần đã nhắc. */
  lastRemindedAt?: number
  remindCount?: number
}

/** Thông tin ngân hàng nhận học phí — lưu ở settings/payment, dùng sinh QR VietQR + mẫu tin nhắc. */
export interface PaymentSettings {
  bankBin: string
  bankName: string
  accountNo: string
  accountName: string
}

/**
 * Bản sao dữ liệu cho "Trang của con" (link bí mật /con/:token, không cần đăng nhập).
 * Doc id = token bí mật; rules chỉ cho GET đúng doc, không cho liệt kê.
 * Nội dung là bản tóm tắt do phía quản trị đồng bộ sang — KHÔNG chứa SĐT/ngày sinh.
 */
export interface ChildPageDoc {
  studentName: string
  className: string
  attendance: { date: string; status: 'present' | 'absent'; reason?: string }[]
  tuition: { period: string; amount: number; paid: number }[]
  progress: { label: string; score?: number; total?: number; at: number }[]
  updatedAt: number
}

export type ProgressType = 'game' | 'lesson'

export interface ProgressDoc {
  id: string
  studentId: string
  type: ProgressType
  refId: string
  label: string
  score?: number
  total?: number
  createdAt: number
}

export interface MediaSettings {
  cloudName: string
  uploadPreset: string
}

export interface WordDoc {
  id: string
  text: string
  emoji: string
}

export interface ResourceDoc {
  id: string
  title: string
  category: string
  description: string
  url: string
  published: boolean
}

export interface BrandDoc {
  name: string
  slogan: string
  heroTitle: string
  heroSubtitle: string
  logo?: string
  logoUrl?: string
  phone?: string
  address?: string
  zalo?: string
}

export interface AnnouncementDoc {
  id: string
  title: string
  content: string
  date: string
  pinned?: boolean
}

export interface TrialRequestDoc {
  id: string
  childName: string
  parentName?: string
  phone: string
  classId?: string
  note?: string
  createdAt: string
  done?: boolean
}

export interface SpotlightDoc {
  name: string
  note: string
  enabled: boolean
}

export const LESSON_CATEGORIES = ['Tập đọc', 'Tập viết', 'Phát âm', 'Đọc từ', 'Bài tập']
export const RESOURCE_CATEGORIES = ['Phiếu bài tập', 'Video', 'Trò chơi in', 'Tài liệu khác']
