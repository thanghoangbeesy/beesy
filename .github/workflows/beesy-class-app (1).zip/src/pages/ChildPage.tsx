import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { doc, getDoc } from 'firebase/firestore'
import { db, isConfigured } from '../firebase'
import { ChildPageDoc } from '../types'

const fmtVND = (n: number) => n.toLocaleString('vi-VN') + 'đ'
const fmtDate = (iso: string) => {
  const [y, m, d] = iso.split('-')
  return d && m && y ? `${d}/${m}/${y}` : iso
}
const fmtDay = (ts: number) => new Date(ts).toLocaleDateString('vi-VN')

/**
 * Trang của con — phụ huynh mở bằng link bí mật cô gửi qua Zalo,
 * không cần tài khoản/mật khẩu. Chỉ thấy đúng thông tin của bé nhà mình.
 */
export default function ChildPage() {
  const { token } = useParams()
  const [page, setPage] = useState<ChildPageDoc | null>(null)
  const [state, setState] = useState<'loading' | 'ok' | 'notfound' | 'error'>('loading')

  useEffect(() => {
    if (!isConfigured || !token) {
      setState('notfound')
      return
    }
    getDoc(doc(db, 'child_pages', token))
      .then((s) => {
        if (s.exists()) {
          setPage(s.data() as ChildPageDoc)
          setState('ok')
        } else {
          setState('notfound')
        }
      })
      .catch(() => setState('error'))
  }, [token])

  if (state === 'loading') {
    return (
      <div className="wrap"><section className="section"><div className="loading">Đang tải trang của bé…</div></section></div>
    )
  }

  if (state === 'notfound' || state === 'error' || !page) {
    return (
      <div className="wrap"><section className="section">
        <div className="admin-box" style={{ maxWidth: 480, margin: '0 auto' }}>
          <h2>🔗 Link chưa đúng</h2>
          <p style={{ color: '#5d7590' }}>
            {state === 'error'
              ? 'Không tải được dữ liệu. Anh/chị kiểm tra mạng rồi mở lại link nhé.'
              : 'Link này không còn hiệu lực hoặc đã được cô giáo cấp lại link mới. Anh/chị nhắn cô giáo gửi lại link mới nhất nhé.'}
          </p>
          <Link to="/">← Về trang chủ lớp</Link>
        </div>
      </section></div>
    )
  }

  const present = page.attendance.filter((a) => a.status === 'present').length
  const absentList = page.attendance.filter((a) => a.status === 'absent')

  return (
    <div className="wrap">
      <section className="section">
        <div className="section-head">
          <div>
            <h2>🧒 Trang của bé {page.studentName}</h2>
            <p>{page.className && <>Lớp {page.className} · </>}Cập nhật {fmtDay(page.updatedAt)}</p>
          </div>
        </div>

        <div className="announce-card">
          <p style={{ marginTop: 0 }}>
            <b>📋 Điểm danh {page.attendance.length} buổi gần nhất:</b>{' '}
            đi học <b style={{ color: '#15803d' }}>{present}</b> buổi · vắng <b style={{ color: '#b91c1c' }}>{absentList.length}</b> buổi
          </p>
          {absentList.length > 0 && (
            <ul style={{ margin: '6px 0 0', paddingLeft: 20 }}>
              {absentList.slice(0, 10).map((a) => (
                <li key={a.date}>
                  Vắng ngày {fmtDate(a.date)}{a.reason ? ` — ${a.reason}` : ''}
                </li>
              ))}
            </ul>
          )}
          {page.attendance.length === 0 && <p style={{ color: '#5d7590' }}>Chưa có buổi điểm danh nào.</p>}
        </div>

        <div className="announce-card">
          <p style={{ marginTop: 0 }}><b>💰 Học phí:</b></p>
          {page.tuition.length === 0 ? (
            <p style={{ color: '#5d7590' }}>Chưa có phiếu thu nào.</p>
          ) : (
            <ul style={{ margin: 0, paddingLeft: 20 }}>
              {page.tuition.map((t, i) => {
                const done = t.amount > 0 && t.paid >= t.amount
                const remain = Math.max(0, t.amount - t.paid)
                return (
                  <li key={i}>
                    Kỳ {t.period}: phải đóng {fmtVND(t.amount)}, đã đóng {fmtVND(t.paid)}
                    {done ? ' ✅' : remain > 0 ? ` — còn lại ${fmtVND(remain)}` : ''}
                  </li>
                )
              })}
            </ul>
          )}
        </div>

        <div className="announce-card">
          <p style={{ marginTop: 0 }}><b>🌟 Hoạt động học tập gần đây:</b></p>
          {page.progress.length === 0 ? (
            <p style={{ color: '#5d7590' }}>Chưa có hoạt động nào được ghi nhận.</p>
          ) : (
            <ul style={{ margin: 0, paddingLeft: 20 }}>
              {page.progress.map((p, i) => (
                <li key={i}>
                  {p.label}
                  {p.score !== undefined && p.total ? ` — ${p.score}/${p.total}` : ''}
                  {' '}· <span style={{ color: '#5d7590' }}>{fmtDay(p.at)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <p style={{ color: '#5d7590', fontSize: 13, textAlign: 'center' }}>
          Đây là trang riêng của bé {page.studentName}. Anh/chị lưu lại link này để xem bất cứ lúc nào nhé.
        </p>
      </section>
    </div>
  )
}
