import { useEffect, useMemo, useState } from 'react'
import {
  collection, deleteDoc, doc, getDoc, getDocs, orderBy, query, setDoc, updateDoc, where, writeBatch,
} from 'firebase/firestore'
import { db } from '../../firebase'
import { ClassDoc, PaymentSettings, StudentDoc, StudentPrivateDoc, TuitionRecord } from '../../types'
import { syncChildPage } from '../../lib/childPage'

function defaultPeriod() {
  const d = new Date()
  return `${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`
}

const fmtVND = (n: number) => n.toLocaleString('vi-VN') + 'đ'
const fmtDay = (ts: number) => new Date(ts).toLocaleDateString('vi-VN')

/** Bỏ dấu tiếng Việt cho nội dung chuyển khoản (ngân hàng hay cắt dấu). */
const noAccent = (s: string) =>
  s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D')

const BANKS: { bin: string; name: string }[] = [
  { bin: '970436', name: 'Vietcombank' },
  { bin: '970415', name: 'VietinBank' },
  { bin: '970418', name: 'BIDV' },
  { bin: '970405', name: 'Agribank' },
  { bin: '970407', name: 'Techcombank' },
  { bin: '970422', name: 'MB Bank' },
  { bin: '970416', name: 'ACB' },
  { bin: '970432', name: 'VPBank' },
  { bin: '970423', name: 'TPBank' },
  { bin: '970403', name: 'Sacombank' },
  { bin: '970443', name: 'SHB' },
  { bin: '970441', name: 'VIB' },
  { bin: '970437', name: 'HDBank' },
  { bin: '970426', name: 'MSB' },
  { bin: '970448', name: 'OCB' },
  { bin: '970431', name: 'Eximbank' },
  { bin: '970440', name: 'SeABank' },
]

function statusOf(r: TuitionRecord): { label: string; color: string } {
  if (r.amount > 0 && r.paid >= r.amount) return { label: 'Đã đóng ✅', color: '#15803d' }
  if (r.paid > 0) return { label: 'Đóng một phần 🟡', color: '#b45309' }
  return { label: 'Chưa đóng 🔴', color: '#b91c1c' }
}

type PrivInfo = { parentName?: string; parentPhone?: string }

export default function TuitionTab({ onMsg }: { onMsg: (m: string) => void }) {
  const [classes, setClasses] = useState<ClassDoc[]>([])
  const [classId, setClassId] = useState('')
  const [period, setPeriod] = useState(defaultPeriod())
  const [students, setStudents] = useState<StudentDoc[]>([])
  const [privates, setPrivates] = useState<Record<string, PrivInfo>>({})
  const [records, setRecords] = useState<TuitionRecord[]>([])
  const [busy, setBusy] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editAmount, setEditAmount] = useState('')
  const [editNote, setEditNote] = useState('')

  // Cài đặt ngân hàng (settings/payment) + tên thương hiệu cho mẫu tin
  const [pay, setPay] = useState<PaymentSettings>({ bankBin: '970436', bankName: 'Vietcombank', accountNo: '', accountName: '' })
  const [brandName, setBrandName] = useState('Beesy Class')

  // Panel nhắc học phí
  const [remindId, setRemindId] = useState<string | null>(null)
  const [remindLevel, setRemindLevel] = useState<1 | 2 | 3>(1)
  const [remindText, setRemindText] = useState('')

  useEffect(() => {
    getDocs(query(collection(db, 'classes'), orderBy('order'))).then((s) => {
      const cs = s.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<ClassDoc, 'id'>) }))
      setClasses(cs)
      if (cs[0]) setClassId((cur) => cur || cs[0].id)
    })
    getDoc(doc(db, 'settings', 'payment'))
      .then((s) => { if (s.exists()) setPay({ ...pay, ...(s.data() as Partial<PaymentSettings>) }) })
      .catch(() => {})
    getDoc(doc(db, 'settings', 'brand'))
      .then((s) => { if (s.exists() && (s.data() as { name?: string }).name) setBrandName((s.data() as { name: string }).name) })
      .catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const load = async (cid: string, per: string) => {
    if (!cid || !per.trim()) return
    const stSnap = await getDocs(query(collection(db, 'students'), where('classId', '==', cid)))
    const sts = stSnap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<StudentDoc, 'id'>) }))
    setStudents(sts)
    // Thông tin phụ huynh (để mở Zalo + điền mẫu tin) — chỉ quản trị đọc được
    const privSnaps = await Promise.all(
      sts.map((st) => getDoc(doc(db, 'student_private', st.id)).catch(() => null)),
    )
    const priv: Record<string, PrivInfo> = {}
    sts.forEach((st, i) => {
      const d = privSnaps[i]?.data() as StudentPrivateDoc | undefined
      if (d) priv[st.id] = { parentName: d.parentName, parentPhone: d.parentPhone }
    })
    setPrivates(priv)
    const recSnap = await getDocs(
      query(collection(db, 'tuition_records'), where('period', '==', per.trim())),
    )
    const ids = new Set(sts.map((s) => s.id))
    const recs = recSnap.docs
      .map((d) => ({ id: d.id, ...(d.data() as Omit<TuitionRecord, 'id'>) }))
      .filter((r) => ids.has(r.studentId))
      .sort((a, b) => a.createdAt - b.createdAt)
    setRecords(recs)
  }

  useEffect(() => { load(classId, period) }, [classId, period])

  const studentName = (id: string) => students.find((s) => s.id === id)?.name || '(đã xóa)'

  const syncQuiet = (studentIds: string[]) => {
    Promise.allSettled(studentIds.map((id) => syncChildPage(id)))
  }

  /** Tạo đợt thu cho cả lớp: bé nào chưa có record kỳ này thì tạo mới (số tiền mặc định 0). */
  const createBatch = async () => {
    if (students.length === 0) {
      onMsg('Lớp này chưa có học sinh.')
      return
    }
    if (!confirm(`Tạo đợt thu kỳ ${period} cho ${students.length} bé?`)) return
    setBusy(true)
    try {
      const existing = new Set(records.map((r) => r.studentId))
      const batch = writeBatch(db)
      let n = 0
      for (const s of students) {
        if (existing.has(s.id)) continue
        const ref = doc(collection(db, 'tuition_records'))
        batch.set(ref, {
          studentId: s.id,
          period: period.trim(),
          amount: 0,
          paid: 0,
          createdAt: Date.now(),
        })
        n++
      }
      await batch.commit()
      await load(classId, period)
      syncQuiet(students.map((s) => s.id))
      onMsg(n > 0 ? `Đã tạo ${n} phiếu thu. Anh bấm "Sửa" để nhập số tiền từng bé nhé.` : 'Cả lớp đã có phiếu thu kỳ này rồi.')
    } catch {
      onMsg('Có lỗi, anh thử lại nhé.')
    }
    setBusy(false)
  }

  const collect = async (r: TuitionRecord) => {
    const v = prompt(`Thu tiền học phí kỳ ${r.period} — bé ${studentName(r.studentId)}\nCòn lại: ${fmtVND(Math.max(0, r.amount - r.paid))}`, '')
    if (v === null) return
    const n = Number(v.replace(/[^\d]/g, ''))
    if (!n || n <= 0) {
      onMsg('Số tiền chưa hợp lệ.')
      return
    }
    await updateDoc(doc(db, 'tuition_records', r.id), {
      paid: r.paid + n,
      paidAt: Date.now(),
    })
    await load(classId, period)
    syncQuiet([r.studentId])
    onMsg(`Đã thu ${fmtVND(n)} ✅`)
  }

  const startEdit = (r: TuitionRecord) => {
    setEditingId(r.id)
    setEditAmount(String(r.amount))
    setEditNote(r.note || '')
  }

  const saveEdit = async (r: TuitionRecord) => {
    const amount = Number(String(editAmount).replace(/[^\d]/g, '')) || 0
    await updateDoc(doc(db, 'tuition_records', r.id), { amount, note: editNote.trim() })
    setEditingId(null)
    await load(classId, period)
    syncQuiet([r.studentId])
    onMsg('Đã lưu! ✅')
  }

  const remove = async (r: TuitionRecord) => {
    if (!confirm(`Xóa phiếu thu kỳ ${r.period} của bé ${studentName(r.studentId)}?`)) return
    await deleteDoc(doc(db, 'tuition_records', r.id))
    await load(classId, period)
    syncQuiet([r.studentId])
    onMsg('Đã xóa.')
  }

  // ---------- Nhắc học phí qua Zalo ----------
  const payConfigured = !!(pay.accountNo.trim() && pay.accountName.trim())

  const transferContent = (r: TuitionRecord) =>
    `HP ${r.period.replace('/', '')} ${noAccent(studentName(r.studentId))}`.slice(0, 50)

  const qrUrl = (r: TuitionRecord) => {
    const remain = Math.max(0, r.amount - r.paid)
    return (
      `https://img.vietqr.io/image/${pay.bankBin}-${pay.accountNo.trim()}-compact2.png` +
      `?amount=${remain}&addInfo=${encodeURIComponent(transferContent(r))}` +
      `&accountName=${encodeURIComponent(noAccent(pay.accountName.trim()))}`
    )
  }

  const buildRemindText = (r: TuitionRecord, level: 1 | 2 | 3) => {
    const priv = privates[r.studentId] || {}
    const hello = priv.parentName ? `Chào anh/chị ${priv.parentName}` : 'Chào anh/chị'
    const remain = fmtVND(Math.max(0, r.amount - r.paid))
    const bankBlock = payConfigured
      ? `\nThông tin chuyển khoản:\n- Số tài khoản: ${pay.accountNo.trim()}\n- Ngân hàng: ${pay.bankName}\n- Chủ tài khoản: ${pay.accountName.trim()}\n- Nội dung: ${transferContent(r)}`
      : ''
    if (level === 1) {
      return `${hello}, em là cô giáo lớp ${brandName}. Em xin nhắc nhẹ: học phí kỳ ${r.period} của bé ${studentName(r.studentId)} còn ${remain}. Khi nào tiện anh/chị chuyển khoản giúp em nhé ạ.${bankBlock}\nEm cảm ơn anh/chị nhiều!`
    }
    if (level === 2) {
      return `${hello}, em xin phép nhắc lại học phí kỳ ${r.period} của bé ${studentName(r.studentId)}: hiện còn ${remain} chưa đóng. Anh/chị sắp xếp chuyển khoản giúp em trong tuần này nhé ạ.${bankBlock}\nEm cảm ơn anh/chị!`
    }
    return `${hello}, học phí kỳ ${r.period} của bé ${studentName(r.studentId)} hiện còn nợ ${remain}. Để lớp duy trì hoạt động ổn định, mong anh/chị hoàn tất giúp em sớm nhất có thể ạ.${bankBlock}\nEm cảm ơn anh/chị đã đồng hành cùng lớp!`
  }

  const openRemind = (r: TuitionRecord) => {
    if (remindId === r.id) {
      setRemindId(null)
      return
    }
    const level = ((r.remindCount || 0) >= 2 ? 3 : (r.remindCount || 0) === 1 ? 2 : 1) as 1 | 2 | 3
    setRemindId(r.id)
    setRemindLevel(level)
    setRemindText(buildRemindText(r, level))
  }

  const changeLevel = (r: TuitionRecord, level: 1 | 2 | 3) => {
    setRemindLevel(level)
    setRemindText(buildRemindText(r, level))
  }

  const markReminded = async (r: TuitionRecord) => {
    await updateDoc(doc(db, 'tuition_records', r.id), {
      lastRemindedAt: Date.now(),
      remindCount: (r.remindCount || 0) + 1,
    })
    setRemindId(null)
    await load(classId, period)
    onMsg(`Đã đánh dấu đã nhắc bé ${studentName(r.studentId)}.`)
  }

  const copyText = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      onMsg('Đã chép tin nhắn! Anh dán vào Zalo gửi phụ huynh nhé.')
    } catch {
      prompt('Chép nội dung tin nhắn này:', text)
    }
  }

  const savePay = async () => {
    const bank = BANKS.find((b) => b.bin === pay.bankBin)
    const data: PaymentSettings = {
      bankBin: pay.bankBin,
      bankName: bank ? bank.name : pay.bankName,
      accountNo: pay.accountNo.trim(),
      accountName: pay.accountName.trim(),
    }
    await setDoc(doc(db, 'settings', 'payment'), data)
    setPay(data)
    onMsg('Đã lưu thông tin ngân hàng! ✅')
  }

  const stats = useMemo(() => {
    const total = records.reduce((s, r) => s + r.amount, 0)
    const paid = records.reduce((s, r) => s + r.paid, 0)
    return { total, paid, remain: Math.max(0, total - paid) }
  }, [records])

  return (
    <>
      <div className="admin-box">
        <h2>💰 Quản lý học phí</h2>
        <div className="form-inline" style={{ marginTop: 0 }}>
          <div className="field" style={{ flex: 1, minWidth: 140, marginBottom: 0 }}>
            <label>Kỳ thu (MM/YYYY)</label>
            <input value={period} onChange={(e) => setPeriod(e.target.value)} placeholder="10/2026" />
          </div>
          <div className="field" style={{ flex: 2, minWidth: 180, marginBottom: 0 }}>
            <label>Lớp</label>
            <select value={classId} onChange={(e) => setClassId(e.target.value)}>
              {classes.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
        </div>
        <div style={{ marginTop: 14 }}>
          <button className="btn-primary" disabled={busy} onClick={createBatch}>
            {busy ? 'Đang tạo…' : '🧾 Tạo đợt thu cho cả lớp'}
          </button>
        </div>
      </div>

      <div className="admin-box">
        <h2>🏦 Ngân hàng nhận học phí (cho mã QR + tin nhắc)</h2>
        <div className="form-inline" style={{ marginTop: 0 }}>
          <div className="field" style={{ flex: 1, minWidth: 160, marginBottom: 0 }}>
            <label>Ngân hàng</label>
            <select value={pay.bankBin} onChange={(e) => setPay({ ...pay, bankBin: e.target.value })}>
              {BANKS.map((b) => (
                <option key={b.bin} value={b.bin}>{b.name}</option>
              ))}
            </select>
          </div>
          <div className="field" style={{ flex: 1, minWidth: 150, marginBottom: 0 }}>
            <label>Số tài khoản</label>
            <input value={pay.accountNo} onChange={(e) => setPay({ ...pay, accountNo: e.target.value })} inputMode="numeric" placeholder="VD: 0123456789" />
          </div>
          <div className="field" style={{ flex: 1, minWidth: 150, marginBottom: 0 }}>
            <label>Chủ tài khoản</label>
            <input value={pay.accountName} onChange={(e) => setPay({ ...pay, accountName: e.target.value })} placeholder="VD: NGUYEN VAN A" />
          </div>
        </div>
        <div style={{ marginTop: 12 }}>
          <button className="btn-primary" onClick={savePay}>Lưu thông tin ngân hàng</button>
          {payConfigured
            ? <span style={{ marginLeft: 12, color: '#15803d', fontWeight: 800 }}>✅ Đã có STK — mã QR sẽ tự hiện trong panel nhắc</span>
            : <span style={{ marginLeft: 12, color: '#b45309', fontWeight: 700 }}>Chưa nhập STK thì tin nhắc sẽ không có mã QR</span>}
        </div>
      </div>

      <div className="admin-box">
        <h2>📋 Phiếu thu — kỳ {period} ({records.length})</h2>
        <div className="admin-row" style={{ fontWeight: 800 }}>
          <div>Tổng phải thu: <b style={{ color: '#1d3a5f' }}>{fmtVND(stats.total)}</b></div>
          <div>Đã thu: <b style={{ color: '#15803d' }}>{fmtVND(stats.paid)}</b></div>
          <div>Còn lại: <b style={{ color: '#b91c1c' }}>{fmtVND(stats.remain)}</b></div>
        </div>
        {records.length === 0 && (
          <div className="empty">Chưa có phiếu thu nào. Anh bấm "Tạo đợt thu cho cả lớp" nhé.</div>
        )}
        {records.map((r) => {
          const st = statusOf(r)
          const remain = Math.max(0, r.amount - r.paid)
          const priv = privates[r.studentId] || {}
          const phone = (priv.parentPhone || '').replace(/[^\d]/g, '')
          return (
            <div key={r.id}>
              <div className="admin-row">
                <div style={{ flex: 1 }}>
                  <b>{studentName(r.studentId)}</b>{' '}
                  <span style={{ fontWeight: 800, color: st.color, fontSize: 13 }}>{st.label}</span>
                  {(r.remindCount || 0) > 0 && (
                    <span style={{ fontSize: 12, color: '#7c3aed', fontWeight: 700 }}>
                      {' '}· 📩 Đã nhắc {r.remindCount} lần{r.lastRemindedAt ? ` (gần nhất ${fmtDay(r.lastRemindedAt)})` : ''}
                    </span>
                  )}
                  <div style={{ fontSize: 13, color: '#5d7590', marginTop: 4 }}>
                    Phải đóng: <b>{fmtVND(r.amount)}</b> · Đã đóng: <b>{fmtVND(r.paid)}</b> · Còn lại: <b>{fmtVND(remain)}</b>
                    {r.note && <span> · 📝 {r.note}</span>}
                  </div>
                  {editingId === r.id && (
                    <div className="form-inline">
                      <input
                        value={editAmount}
                        onChange={(e) => setEditAmount(e.target.value)}
                        placeholder="Số tiền phải đóng"
                        inputMode="numeric"
                        style={{ maxWidth: 160 }}
                      />
                      <input
                        value={editNote}
                        onChange={(e) => setEditNote(e.target.value)}
                        placeholder="Ghi chú"
                        style={{ maxWidth: 220 }}
                      />
                      <button className="btn-small" onClick={() => saveEdit(r)}>Lưu</button>
                      <button className="btn-small" onClick={() => setEditingId(null)}>Hủy</button>
                    </div>
                  )}
                </div>
                {editingId !== r.id && (
                  <div style={{ display: 'flex', gap: 8, flexShrink: 0, flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                    {remain > 0 && (
                      <button className="btn-small" onClick={() => openRemind(r)}>📩 Nhắc</button>
                    )}
                    <button className="btn-small" onClick={() => collect(r)}>💵 Thu tiền</button>
                    <button className="btn-small" onClick={() => startEdit(r)}>Sửa</button>
                    <button className="btn-danger" onClick={() => remove(r)}>Xóa</button>
                  </div>
                )}
              </div>
              {remindId === r.id && (
                <div style={{ border: '1.5px dashed #c9b48a', borderRadius: 14, padding: 12, margin: '4px 0 12px', background: '#fffaf0' }}>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center', marginBottom: 8 }}>
                    <b style={{ fontSize: 13 }}>Mức nhắc:</b>
                    {([1, 2, 3] as const).map((lv) => (
                      <button
                        key={lv}
                        className="btn-small"
                        style={{
                          background: remindLevel === lv ? '#dbeafe' : undefined,
                          borderColor: remindLevel === lv ? '#3b82f6' : undefined,
                          color: remindLevel === lv ? '#1d4ed8' : undefined,
                        }}
                        onClick={() => changeLevel(r, lv)}
                      >
                        {lv === 1 ? '1 · Nhẹ nhàng' : lv === 2 ? '2 · Nhắc lại' : '3 · Trực tiếp'}
                      </button>
                    ))}
                  </div>
                  <textarea
                    value={remindText}
                    onChange={(e) => setRemindText(e.target.value)}
                    rows={8}
                    style={{ width: '100%', borderRadius: 10, border: '1.5px solid #ead9bd', padding: 10, fontSize: 14, fontFamily: 'inherit' }}
                  />
                  {payConfigured ? (
                    <div style={{ marginTop: 10 }}>
                      <img src={qrUrl(r)} alt="Mã QR chuyển khoản học phí" style={{ width: 180, borderRadius: 12, border: '1px solid #ead9bd' }} />
                      <div style={{ fontSize: 12, color: '#5d7590' }}>
                        Mã QR đã gồm sẵn số tiền còn lại ({fmtVND(remain)}) và nội dung chuyển khoản. Anh lưu ảnh QR này gửi kèm tin nhắn nhé.
                      </div>
                    </div>
                  ) : (
                    <div className="notice" style={{ marginTop: 10 }}>
                      Chưa có mã QR vì anh chưa nhập số tài khoản ở mục "Ngân hàng nhận học phí" phía trên.
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 12 }}>
                    <button className="btn-small" onClick={() => copyText(remindText)}>📋 Chép tin nhắn</button>
                    {phone ? (
                      <a href={`https://zalo.me/${phone}`} target="_blank" rel="noreferrer">
                        <button className="btn-small">💬 Mở Zalo của phụ huynh</button>
                      </a>
                    ) : (
                      <span style={{ fontSize: 12, color: '#b45309', fontWeight: 700, alignSelf: 'center' }}>
                        Chưa có SĐT phụ huynh (nhập ở tab Học sinh)
                      </span>
                    )}
                    <button className="btn-small" style={{ background: '#ede9fe', borderColor: '#8b5cf6', color: '#6d28d9' }} onClick={() => markReminded(r)}>
                      ✓ Đã gửi nhắc
                    </button>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </>
  )
}
