import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import ClassDetail from './pages/ClassDetail'
import LessonDetail from './pages/LessonDetail'
import Games from './pages/Games'
import Resources from './pages/Resources'
import Admin from './pages/Admin'
import ParentPortal from './pages/ParentPortal'
import ChildPage from './pages/ChildPage'
import Albums from './pages/Albums'
import AlbumDetail from './pages/AlbumDetail'
import ListenPick from './games/ListenPick'
import Flashcards from './games/Flashcards'
import FirstLetter from './games/FirstLetter'
import TraceLetter from './games/TraceLetter'
import Memory from './games/Memory'
import SpellWord from './games/SpellWord'

export default function App() {
  return (
    <BrowserRouter>
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/lop/:id" element={<ClassDetail />} />
          <Route path="/bai-hoc/:id" element={<LessonDetail />} />
          <Route path="/tro-choi" element={<Games />} />
          <Route path="/tro-choi/nghe-va-chon" element={<ListenPick />} />
          <Route path="/tro-choi/the-tu" element={<Flashcards />} />
          <Route path="/tro-choi/chu-cai-dau" element={<FirstLetter />} />
          <Route path="/tro-choi/tap-viet" element={<TraceLetter />} />
          <Route path="/tro-choi/tri-nho" element={<Memory />} />
          <Route path="/tro-choi/xep-chu" element={<SpellWord />} />
          <Route path="/tai-lieu" element={<Resources />} />
          <Route path="/thu-vien-anh" element={<Albums />} />
          <Route path="/thu-vien-anh/:id" element={<AlbumDetail />} />
          <Route path="/phu-huynh" element={<ParentPortal />} />
          <Route path="/con/:token" element={<ChildPage />} />
          <Route path="/quan-tri" element={<Admin />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>
      <Footer />
    </BrowserRouter>
  )
}
