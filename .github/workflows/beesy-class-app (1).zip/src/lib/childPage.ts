import {
  collection, doc, documentId, getDoc, getDocs, limit, orderBy, query, setDoc, where,
} from 'firebase/firestore'
import { db } from '../firebase'
import { ChildPageDoc, StudentPrivateDoc } from '../types'

const TOKEN_ALPHABET = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'

export function genChildToken(len = 18): string {
  const arr = new Uint32Array(len)
  crypto.getRandomValues(arr)
  return Array.from(arr, (n) => TOKEN_ALPHABET[n % TOKEN_ALPHABET.length]).join('')
}

/** Lấy token trang của con; chưa có thì tạo mới và lưu vào student_private. */
export async function ensureChildToken(studentId: string): Promise<string> {
  const ref = doc(db, 'student_private', studentId)
  const snap = await getDoc(ref)
  const cur = snap.exists() ? (snap.data() as StudentPrivateDoc).childToken : undefined
  if (cur) return cur
  const token = genChildToken()
  await setDoc(ref, { childToken: token }, { merge: true })
  return token
}

/**
 * Đồng bộ bản tóm tắt của bé (điểm danh 30 buổi gần nhất, học phí, tiến trình)
 * sang `child_pages/{token}` để phụ huynh mở link xem không cần đăng nhập.
 * Chỉ chạy phía quản trị (đủ quyền đọc). Trả về token, hoặc null nếu bé chưa có token.
 * Bản tóm tắt KHÔNG chứa ngày sinh / SĐT phụ huynh.
 */
export async function syncChildPage(studentId: string): Promise<string | null> {
  const privSnap = await getDoc(doc(db, 'student_private', studentId))
  const token = privSnap.exists() ? (privSnap.data() as StudentPrivateDoc).childToken : undefined
  if (!token) return null

  const sSnap = await getDoc(doc(db, 'students', studentId))
  if (!sSnap.exists()) return null
  const student = sSnap.data() as { name: string; classId: string }

  let className = ''
  const cSnap = await getDoc(doc(db, 'classes', student.classId))
  if (cSnap.exists()) className = (cSnap.data() as { name?: string }).name || ''

  const prefix = `${student.classId}_`
  const attSnap = await getDocs(
    query(
      collection(db, 'attendance'),
      where(documentId(), '>=', prefix),
      where(documentId(), '<=', prefix + '\uf8ff'),
      orderBy(documentId(), 'desc'),
      limit(30),
    ),
  )
  const attendance: ChildPageDoc['attendance'] = []
  attSnap.forEach((d) => {
    const data = d.data() as {
      date?: string
      records?: Record<string, string>
      reasons?: Record<string, string>
    }
    const st = data.records?.[studentId]
    if (st === 'present' || st === 'absent') {
      attendance.push({
        date: data.date || d.id.slice(prefix.length),
        status: st,
        ...(st === 'absent' && data.reasons?.[studentId] ? { reason: data.reasons[studentId] } : {}),
      })
    }
  })

  const tSnap = await getDocs(query(collection(db, 'tuition_records'), where('studentId', '==', studentId)))
  const tuition = tSnap.docs
    .map((d) => d.data() as { period: string; amount: number; paid: number; createdAt: number })
    .sort((a, b) => b.createdAt - a.createdAt)
    .map(({ period, amount, paid }) => ({ period, amount, paid }))

  const pSnap = await getDocs(query(collection(db, 'progress'), where('studentId', '==', studentId)))
  const progress = pSnap.docs
    .map((d) => d.data() as { label: string; score?: number; total?: number; createdAt: number })
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 5)
    .map((p) => ({
      label: p.label,
      ...(p.score !== undefined ? { score: p.score } : {}),
      ...(p.total !== undefined ? { total: p.total } : {}),
      at: p.createdAt,
    }))

  const page: ChildPageDoc = {
    studentName: student.name,
    className,
    attendance,
    tuition,
    progress,
    updatedAt: Date.now(),
  }
  await setDoc(doc(db, 'child_pages', token), page)
  return token
}

/** Đảm bảo bé có token, đồng bộ dữ liệu mới nhất rồi trả về link đầy đủ để gửi phụ huynh. */
export async function getChildLink(studentId: string): Promise<string> {
  const token = await ensureChildToken(studentId)
  await syncChildPage(studentId)
  return `${window.location.origin}/con/${token}`
}
